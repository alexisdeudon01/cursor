#!/usr/bin/env bash
set -euo pipefail

PROJECT_PATH="${UNITY_PROJECT_PATH:-.}"
LOG_DIR="${UNITY_LOG_DIR:-.ci_logs}"
GRAPH_DIR=".ci_graph"
MAX_AI_ITERS="${MAX_AI_ITERS:-5}"
UNITY_IMAGE="${UNITY_EDITOR_IMAGE:-ghcr.io/game-ci/unity-editor:ubuntu-6000.3.0f1-linux-il2cpp-3}"

UNITY_CMD=(
  /opt/unity/Editor/Unity
  -batchmode -nographics -quit
  -projectPath /project
)

mkdir -p "$LOG_DIR" "$GRAPH_DIR"

ts() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
log() { echo "[$(ts)] $*"; }

docker_env_flags() {
  local vars=(
    UNITY_LICENSE UNITY_EMAIL UNITY_PASSWORD UNITY_SERIAL
    ANTHROPIC_API_KEY ANTHROPIC_MODEL
    GITHUB_TOKEN
  )
  for v in "${vars[@]}"; do
    if [[ -n "${!v:-}" ]]; then
      printf -- "-e %s " "$v"
    fi
  done
}

run_unity() {
  local mode="$1"  # compile | tests
  local iter="$2"
  local logfile="$LOG_DIR/${mode}_iter${iter}.log"

  if ! docker image inspect "$UNITY_IMAGE" >/dev/null 2>&1; then
    log "Image not found locally: $UNITY_IMAGE"
    log "Trying to pull $UNITY_IMAGE ..."
    docker pull "$UNITY_IMAGE" || true
  fi

  log "Running Unity ($mode) iter=$iter -> $logfile"
  set +e
  docker run --rm     -v "$PWD:/project"     -w /project     $(docker_env_flags)     "$UNITY_IMAGE"     "${UNITY_CMD[@]}"     -logFile "/project/$logfile"     $( [[ "$mode" == "tests" ]] && echo "-runTests -testPlatform EditMode -testResults /project/$LOG_DIR/testResults_iter${iter}.xml" )     >/dev/null 2>&1
  local code=$?
  set -e

  echo "$code" > "$LOG_DIR/${mode}_iter${iter}.exitcode"
  return "$code"
}

extract_error_tail() {
  local file="$1"
  tail -n 250 "$file" | sed -e 's/\r$//'
}

ensure_tools() {
  python3 -V >/dev/null
  command -v git >/dev/null
}

git_setup() {
  git config user.name "github-actions[bot]"
  git config user.email "github-actions[bot]@users.noreply.github.com"
}

maybe_push_changes() {
  if git diff --quiet; then
    log "No changes to push."
    return 0
  fi

  if [[ -z "${GITHUB_TOKEN:-}" ]]; then
    log "No GITHUB_TOKEN provided -> can't push."
    return 0
  fi

  git_setup
  git add -A
  git commit -m "ci: Claude autofix (iter checkpoint)" || true

  local remote_url
  remote_url="$(git remote get-url origin)"
  if [[ "$remote_url" != https://* ]]; then
    remote_url="https://github.com/${GITHUB_REPOSITORY}.git"
  fi
  git remote set-url origin "https://x-access-token:${GITHUB_TOKEN}@github.com/${GITHUB_REPOSITORY}.git"

  log "Pushing checkpoint commit to ${GITHUB_REF_NAME}"
  git push origin "HEAD:${GITHUB_REF_NAME}"
}

call_claude_for_patch() {
  local context_title="$1"
  local log_file="$2"
  local iter="$3"

  if [[ -z "${ANTHROPIC_API_KEY:-}" ]]; then
    log "ANTHROPIC_API_KEY missing -> can't run AI fix."
    return 2
  fi

  python3 scripts/claude_autofix.py     --title "$context_title"     --log-file "$log_file"     --out "$LOG_DIR/claude_patch_iter${iter}.diff"
}

apply_patch() {
  local diff="$1"
  if [[ ! -s "$diff" ]]; then
    log "Empty patch: $diff"
    return 2
  fi

  log "Applying patch: $diff"
  set +e
  git apply --whitespace=fix "$diff"
  local code=$?
  set -e
  return "$code"
}

write_mermaid_graph() {
  local max_iter="$1"
  local status="$2"
  local mmd="$GRAPH_DIR/runner_graph.mmd"

  cat > "$mmd" <<EOF
flowchart TD
  A[Checkout + LFS] --> B[Preflight]
  B --> C[Docker warm pull (GHCR)]
  C --> D{Iter loop 1..$max_iter}
  D --> E[Unity compile startup]
  E -->|OK| F[Unity EditMode tests]
  E -->|Fail| G[Capture logs]
  F -->|OK| H[Success ✅]
  F -->|Fail| G
  G --> I[Send log tail to Claude]
  I --> J[Claude returns git diff]
  J --> K[Apply patch + commit checkpoint]
  K --> L[Push to main]
  L --> D
  H --> M[Upload artifacts + graph]
  G -->|Max iters hit| N[Fail ❌]
  N --> M
EOF

  echo "$status" > "$GRAPH_DIR/final_status.txt"
}

ensure_tools

log "Starting AI loop (max iters=$MAX_AI_ITERS)"
log "Using Unity image: $UNITY_IMAGE"

for ((iter=1; iter<=MAX_AI_ITERS; iter++)); do
  log "==== Iteration $iter/$MAX_AI_ITERS: COMPILE CHECK ===="
  if run_unity "compile" "$iter"; then
    log "✅ Compile OK (iter=$iter)"
    break
  fi

  log "❌ Compile failed (iter=$iter)"
  local_compile_log="$LOG_DIR/compile_iter${iter}.log"
  extract_error_tail "$local_compile_log" > "$LOG_DIR/compile_iter${iter}_tail.txt"

  call_claude_for_patch "Unity compile errors" "$local_compile_log" "$iter" || true
  apply_patch "$LOG_DIR/claude_patch_iter${iter}.diff" || true
  maybe_push_changes || true

  if [[ "$iter" -eq "$MAX_AI_ITERS" ]]; then
    log "Max iterations reached during compile stage."
    write_mermaid_graph "$MAX_AI_ITERS" "FAILED_AT_COMPILE"
    exit 1
  fi
done

for ((iter=1; iter<=MAX_AI_ITERS; iter++)); do
  log "==== Iteration $iter/$MAX_AI_ITERS: TESTS ===="
  if run_unity "tests" "$iter"; then
    log "✅ Tests OK (iter=$iter)"
    write_mermaid_graph "$MAX_AI_ITERS" "SUCCESS"
    exit 0
  fi

  log "❌ Tests failed (iter=$iter)"
  local_test_log="$LOG_DIR/tests_iter${iter}.log"
  extract_error_tail "$local_test_log" > "$LOG_DIR/tests_iter${iter}_tail.txt"

  call_claude_for_patch "Unity tests/compilation errors" "$local_test_log" "$iter" || true
  apply_patch "$LOG_DIR/claude_patch_iter${iter}.diff" || true
  maybe_push_changes || true

  if [[ "$iter" -eq "$MAX_AI_ITERS" ]]; then
    log "Max iterations reached during tests stage."
    write_mermaid_graph "$MAX_AI_ITERS" "FAILED_AT_TESTS"
    exit 1
  fi
done
