using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Canvas))]
public class GameCanvasRoot : MonoBehaviour
{
    // Ce script sert juste à identifier le GameCanvas dans la scène/préfab
}
