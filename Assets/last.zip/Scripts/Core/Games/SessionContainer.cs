using System;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

namespace Core.Games
{
    /// <summary>
    /// Isolated container for a single game session.
    /// Ensures complete data isolation between sessions.
    /// Each session has its own player registry, game state, and world offset.
    /// </summary>
    public class SessionContainer : IDisposable
    {
        // ============================================
        //   IDENTIFICATION
        // ============================================

        public string SessionName { get; }
        public string SessionId { get; }
        public Vector3 WorldOffset { get; }
        public DateTime CreatedAt { get; }

	        // ============================================
	        //   PLAYER MANAGEMENT (Isolated)
	        // ============================================

	        private readonly Dictionary<ulong, SessionPlayer> players = new Dictionary<ulong, SessionPlayer>();
	        private readonly object playerLock = new object();

        public ulong HostClientId { get; private set; }
        public int PlayerCount => players.Count;
        public int MaxPlayers { get; set; } = 8;

        // ============================================
        //   GAME STATE (Isolated)
        // ============================================

        public enum SessionState { Lobby, Starting, InGame, Ended }
        public SessionState State { get; private set; } = SessionState.Lobby;

        public string GameId { get; private set; }
        public IGameDefinition GameDefinition { get; private set; }

        private readonly Dictionary<ulong, NetworkObject> playerPawns = new Dictionary<ulong, NetworkObject>();
        private readonly object pawnLock = new object();

        // ============================================
        //   GAME CONTAINER (Encapsulated Game Instance)
        // ============================================

        /// <summary>
        /// Game container encapsulates the actual game instance.
        /// Created when game starts and loads Game scene.
        /// </summary>
        private GameContainer gameContainer;
        public GameContainer Game => gameContainer;

        // ============================================
        //   EVENTS
        // ============================================

        public event Action<SessionContainer, ulong> OnPlayerJoined;
        public event Action<SessionContainer, ulong> OnPlayerLeft;
        public event Action<SessionContainer, SessionState> OnStateChanged;
        public event Action<SessionContainer, string> OnError;

        // ============================================
        //   CONSTRUCTOR
        // ============================================

	        public SessionContainer(string sessionName, ulong hostClientId, Vector3 worldOffset)
	        {
	            SessionName = sessionName;
	            SessionId = Guid.NewGuid().ToString("N").Substring(0, 8);
	            HostClientId = hostClientId;
	            WorldOffset = worldOffset;
	            CreatedAt = DateTime.UtcNow;

	            Debug.Log($"[SessionContainer:{SessionId}] Created session '{sessionName}' with host {hostClientId} at offset {worldOffset}");
	        }

	        // ============================================
	        //   ACCESS (membership-based)
	        // ============================================

	        /// <summary>
	        /// Check if a client is a member of this session.
	        /// </summary>
	        private bool HasPlayer(ulong clientId)
	        {
	            lock (playerLock)
	            {
	                return players.ContainsKey(clientId);
	            }
	        }

	        /// <summary>
	        /// Validate that a request comes from a session member.
	        /// Returns false and logs error if client is not in the session.
	        /// </summary>
	        public bool ValidateAccess(ulong clientId, string operation)
	        {
	            if (!HasPlayer(clientId))
	            {
	                string error = $"Client {clientId} not in session '{SessionName}' for '{operation}'";
	                Debug.LogError($"[SessionContainer:{SessionId}] {error}");
	                OnError?.Invoke(this, error);
	                return false;
	            }
	            return true;
	        }

	        /// <summary>
	        /// Simple access validation (without logging).
	        /// </summary>
	        public bool ValidateAccess(ulong clientId)
	        {
	            return HasPlayer(clientId);
	        }

        // ============================================
        //   PLAYER MANAGEMENT
        // ============================================

        public bool AddPlayer(ulong clientId, string playerName)
        {
            lock (playerLock)
            {
                if (players.ContainsKey(clientId))
                {
                    Debug.LogWarning($"[SessionContainer:{SessionId}] Player {clientId} already in session");
                    return true;
                }

                if (players.Count >= MaxPlayers)
                {
                    OnError?.Invoke(this, $"Session full (max {MaxPlayers})");
                    return false;
                }

                if (State == SessionState.InGame)
                {
                    // Late joiner - allowed but flagged
                    Debug.Log($"[SessionContainer:{SessionId}] Late joiner {playerName} ({clientId})");
                }

                var player = new SessionPlayer
                {
                    ClientId = clientId,
                    PlayerName = playerName,
                    JoinedAt = DateTime.UtcNow,
                    IsReady = false,
                    IsHost = clientId == HostClientId
                };

	                players[clientId] = player;

	                Debug.Log($"[SessionContainer:{SessionId}] Player '{playerName}' ({clientId}) joined. Total: {players.Count}");
	                OnPlayerJoined?.Invoke(this, clientId);

                return true;
            }
        }

        public bool RemovePlayer(ulong clientId)
        {
	            lock (playerLock)
	            {
	                if (!players.Remove(clientId))
	                    return false;

	                // Remove pawn if exists
	                lock (pawnLock)
	                {
                    if (playerPawns.TryGetValue(clientId, out var pawn))
                    {
                        if (pawn != null && pawn.IsSpawned)
                            pawn.Despawn();
                        playerPawns.Remove(clientId);
                    }
                }

                Debug.Log($"[SessionContainer:{SessionId}] Player {clientId} left. Total: {players.Count}");
                OnPlayerLeft?.Invoke(this, clientId);

                // If host left, assign new host or end session
                if (clientId == HostClientId && players.Count > 0)
                {
                    foreach (var remaining in players.Values)
                    {
                        HostClientId = remaining.ClientId;
                        remaining.IsHost = true;
                        Debug.Log($"[SessionContainer:{SessionId}] New host: {HostClientId}");
                        break;
                    }
                }

                return true;
            }
        }

        public SessionPlayer GetPlayer(ulong clientId)
        {
            lock (playerLock)
            {
                return players.TryGetValue(clientId, out var player) ? player : null;
            }
        }

        public List<SessionPlayer> GetAllPlayers()
        {
            lock (playerLock)
            {
                return new List<SessionPlayer>(players.Values);
            }
        }

        public List<ulong> GetPlayerIds()
        {
            lock (playerLock)
            {
                return new List<ulong>(players.Keys);
            }
        }

        public bool SetPlayerReady(ulong clientId, bool ready)
        {
            lock (playerLock)
            {
                if (players.TryGetValue(clientId, out var player))
                {
                    player.IsReady = ready;
                    return true;
                }
                return false;
            }
        }

        public int GetReadyCount()
        {
            lock (playerLock)
            {
                int count = 0;
                foreach (var p in players.Values)
                    if (p.IsReady) count++;
                return count;
            }
        }

        public bool AllPlayersReady()
        {
            lock (playerLock)
            {
                foreach (var p in players.Values)
                    if (!p.IsReady) return false;
                return players.Count > 0;
            }
        }

        // ============================================
        //   GAME LIFECYCLE
        // ============================================

        public bool StartGame(string gameId, ulong requestingClient)
        {
            if (!ValidateAccess(requestingClient, "StartGame"))
                return false;

            if (requestingClient != HostClientId)
            {
                OnError?.Invoke(this, "Only host can start game");
                return false;
            }

            if (State != SessionState.Lobby)
            {
                OnError?.Invoke(this, $"Cannot start game in state {State}");
                return false;
            }

            var gameDef = GameRegistry.GetGame(gameId);
            if (gameDef == null)
            {
                OnError?.Invoke(this, $"Game '{gameId}' not found");
                return false;
            }

            GameId = gameId;
            GameDefinition = gameDef;

            // Initialize GameContainer (encapsulates the actual game instance)
            gameContainer = new GameContainer(SessionName, gameId, WorldOffset);

            SetState(SessionState.Starting);

            Debug.Log($"[SessionContainer:{SessionId}] Starting game '{gameId}' with GameContainer");
            return true;
        }

        public void SetGameRunning()
        {
            SetState(SessionState.InGame);
        }

        public void EndGame()
        {
            SetState(SessionState.Ended);

            lock (pawnLock)
            {
                foreach (var pawn in playerPawns.Values)
                {
                    if (pawn != null && pawn.IsSpawned)
                        pawn.Despawn();
                }
                playerPawns.Clear();
            }

            // Cleanup GameContainer
            if (gameContainer != null)
            {
                Debug.Log($"[SessionContainer:{SessionId}] Cleaning up GameContainer");
                gameContainer = null;
            }

            Debug.Log($"[SessionContainer:{SessionId}] Game ended");
        }

        private void SetState(SessionState newState)
        {
            var oldState = State;
            State = newState;
            Debug.Log($"[SessionContainer:{SessionId}] State: {oldState} -> {newState}");
            OnStateChanged?.Invoke(this, newState);
        }

        // ============================================
        //   PAWN MANAGEMENT
        // ============================================

        public void RegisterPawn(ulong clientId, NetworkObject pawn, string playerName = "")
        {
            if (!ValidateAccess(clientId, "RegisterPawn"))
                return;

            lock (pawnLock)
            {
                playerPawns[clientId] = pawn;
                Debug.Log($"[SessionContainer:{SessionId}] Registered pawn {pawn.NetworkObjectId} for client {clientId}");
            }

            // Also register with GameContainer if it exists
            if (gameContainer != null)
            {
                gameContainer.RegisterPawn(clientId, pawn, playerName);
            }
        }

        public NetworkObject GetPawn(ulong clientId)
        {
            lock (pawnLock)
            {
                return playerPawns.TryGetValue(clientId, out var pawn) ? pawn : null;
            }
        }

        public bool HandleMovement(ulong clientId, Vector2 direction, out ulong pawnNetworkId, out Vector3 newPosition)
        {
            pawnNetworkId = 0;
            newPosition = Vector3.zero;

            if (!ValidateAccess(clientId, "HandleMovement"))
                return false;

            if (State != SessionState.InGame)
                return false;

            lock (pawnLock)
            {
                if (!playerPawns.TryGetValue(clientId, out var pawn) || pawn == null)
                    return false;

                GameDefinition?.HandleMovement(pawn, direction);
                pawnNetworkId = pawn.NetworkObjectId;
                newPosition = pawn.transform.position;
                return true;
            }
        }

        // ============================================
        //   VALIDATION HELPERS
        // ============================================

        /// <summary>
        /// Check if position is within this session's world bounds.
        /// </summary>
        public bool IsPositionInBounds(Vector3 position)
        {
            // Sessions are spaced 50 units apart on X axis
            float halfSpace = 25f;
            return Mathf.Abs(position.x - WorldOffset.x) < halfSpace;
        }

        /// <summary>
        /// Alias for IsPositionInBounds for API consistency.
        /// </summary>
        public bool ValidatePositionInBounds(Vector3 position) => IsPositionInBounds(position);

        /// <summary>
        /// Validate that a NetworkObject belongs to this session.
        /// </summary>
        public bool IsObjectInSession(NetworkObject obj)
        {
            if (obj == null) return false;
            return IsPositionInBounds(obj.transform.position);
        }

        // ============================================
        //   STATS & DEBUG
        // ============================================

        public SessionStats GetStats()
        {
            lock (playerLock)
            {
                return new SessionStats
                {
                    SessionId = SessionId,
                    SessionName = SessionName,
                    State = State,
                    PlayerCount = players.Count,
                    ReadyCount = GetReadyCount(),
                    GameId = GameId,
                    CreatedAt = CreatedAt,
                    UptimeSeconds = (DateTime.UtcNow - CreatedAt).TotalSeconds
                };
            }
        }

        // ============================================
        //   CLEANUP
        // ============================================

        public void Dispose()
        {
            Debug.Log($"[SessionContainer:{SessionId}] Disposing session '{SessionName}'");

            EndGame();

	            lock (playerLock)
	            {
	                players.Clear();
	            }

            GameDefinition?.CleanupGame();
        }
    }

    /// <summary>
    /// Player data within a session.
    /// </summary>
    public class SessionPlayer
    {
        public ulong ClientId;
        public string PlayerName;
        public DateTime JoinedAt;
        public bool IsReady;
        public bool IsHost;
    }

    /// <summary>
    /// Session statistics for monitoring/testing.
    /// </summary>
    public struct SessionStats
    {
        public string SessionId;
        public string SessionName;
        public SessionContainer.SessionState State;
        public int PlayerCount;
        public int ReadyCount;
        public string GameId;
        public DateTime CreatedAt;
        public double UptimeSeconds;
    }

} // namespace Core.Games
