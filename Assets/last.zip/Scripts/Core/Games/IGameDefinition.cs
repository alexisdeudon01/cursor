using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Interface for pluggable game types.
/// Implement this to create a new game mode (e.g., SquareGame, CircleGame, RacingGame).
/// 
/// <para><b>How to add a new game:</b></para>
/// <list type="number">
///   <item>Create a new class implementing IGameDefinition</item>
///   <item>Create a ScriptableObject inheriting from GameDefinitionAsset</item>
///   <item>Register it in GameRegistry</item>
/// </list>
/// </summary>
/// <example>
/// <code>
/// public class MyCustomGame : IGameDefinition
/// {
///     public string GameId => "my-custom-game";
///     public string DisplayName => "My Custom Game";
///     // ... implement other members
/// }
/// </code>
/// </example>
public interface IGameDefinition
{
    /// <summary>
    /// Unique identifier for this game type (e.g., "square-game", "circle-game").
    /// </summary>
    string GameId { get; }

    /// <summary>
    /// Human-readable name shown in UI.
    /// </summary>
    string DisplayName { get; }

    /// <summary>
    /// Description of the game for players.
    /// </summary>
    string Description { get; }

    /// <summary>
    /// Minimum players required to start.
    /// </summary>
    int MinPlayers { get; }

    /// <summary>
    /// Maximum players allowed.
    /// </summary>
    int MaxPlayers { get; }

    /// <summary>
    /// The prefab to spawn for each player's pawn.
    /// Must have NetworkObject component.
    /// </summary>
    NetworkObject PawnPrefab { get; }

    /// <summary>
    /// [SERVER] Called when the game starts to set up the play area.
    /// </summary>
    /// <param name="worldOffset">Offset for this game instance (for multi-session support)</param>
    void SetupGame(Vector3 worldOffset);

    /// <summary>
    /// [SERVER] Get spawn position for a player.
    /// </summary>
    /// <param name="playerIndex">Index of the player (0 to playerCount-1)</param>
    /// <param name="totalPlayers">Total number of players in the game</param>
    /// <param name="worldOffset">World offset for this session</param>
    Vector3 GetSpawnPosition(int playerIndex, int totalPlayers, Vector3 worldOffset);

    /// <summary>
    /// [SERVER] Initialize a spawned pawn with game-specific settings.
    /// </summary>
    /// <param name="pawn">The spawned pawn NetworkObject</param>
    /// <param name="playerName">The player's display name</param>
    /// <param name="playerIndex">Index for color/position assignment</param>
    /// <param name="worldOffset">World offset for boundaries</param>
    void InitializePawn(NetworkObject pawn, string playerName, int playerIndex, Vector3 worldOffset);

    /// <summary>
    /// [CLIENT] Set up client-side visuals (camera, local effects).
    /// </summary>
    void SetupClientVisuals();

    /// <summary>
    /// Provide the world offset for client-side visuals so maps/cameras line up with spawned pawns.
    /// </summary>
    /// <param name="worldOffset">Offset of the session's world space.</param>
    void SetClientWorldOffset(Vector3 worldOffset);

    /// <summary>
    /// [SERVER] Handle player movement input.
    /// </summary>
    /// <param name="pawn">The player's pawn</param>
    /// <param name="direction">Movement direction from input</param>
    void HandleMovement(NetworkObject pawn, Vector2 direction);

    /// <summary>
    /// [SERVER] Called when game ends.
    /// </summary>
    void CleanupGame();
}

/// <summary>
/// Base ScriptableObject for game definitions.
/// Create assets to register games in the editor.
/// </summary>
public abstract class GameDefinitionAsset : ScriptableObject, IGameDefinition
{
    [Header("Game Info")]
    [SerializeField] protected string gameId;
    [SerializeField] protected string displayName;
    [SerializeField, TextArea] protected string description;

    [Header("Player Settings")]
    [SerializeField] protected int minPlayers = 1;
    [SerializeField] protected int maxPlayers = 10;

    [Header("Prefabs")]
    [SerializeField] protected NetworkObject pawnPrefab;

    public virtual string GameId => gameId;
    public virtual string DisplayName => displayName;
    public virtual string Description => description;
    public virtual int MinPlayers => minPlayers;
    public virtual int MaxPlayers => maxPlayers;
    public virtual NetworkObject PawnPrefab => pawnPrefab;
    protected Vector3 clientWorldOffset;

    public abstract void SetupGame(Vector3 worldOffset);
    public abstract Vector3 GetSpawnPosition(int playerIndex, int totalPlayers, Vector3 worldOffset);
    public abstract void InitializePawn(NetworkObject pawn, string playerName, int playerIndex, Vector3 worldOffset);
    public abstract void SetupClientVisuals();

    public virtual void SetClientWorldOffset(Vector3 worldOffset)
    {
        clientWorldOffset = worldOffset;
    }

    public abstract void HandleMovement(NetworkObject pawn, Vector2 direction);
    public abstract void CleanupGame();
}
