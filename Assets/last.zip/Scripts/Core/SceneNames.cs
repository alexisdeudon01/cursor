public static class SceneNames
{
    public const string Menu = "Menu";
    public const string Client = "Client";
    public const string Server = "Server";
    public const string Game = "Game";
}
