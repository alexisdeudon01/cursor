using UnityEngine;
using Core.Games;
using Core.Utilities;

namespace Core.Utilities
{
    /// <summary>
    /// Validation result containing session container and validation status
    /// </summary>
    public readonly struct SessionValidationResult
    {
        public readonly bool IsValid;
        public readonly SessionContainer Session;
        public readonly string ErrorMessage;

        public SessionValidationResult(bool isValid, SessionContainer session, string errorMessage = "")
        {
            IsValid = isValid;
            Session = session;
            ErrorMessage = errorMessage;
        }

        public static SessionValidationResult Success(SessionContainer session) =>
            new SessionValidationResult(true, session, "");

        public static SessionValidationResult Failure(string errorMessage) =>
            new SessionValidationResult(false, null, errorMessage);
    }

    /// <summary>
    /// Centralized session validation utility to eliminate redundant validation logic.
    /// Provides consistent error handling, logging, and validation patterns.
    /// 
    /// Usage:
    ///   var result = SessionValidator.ValidateSessionAccess(sessionName, clientId, "Move");
    ///   if (!result.IsValid) return;
    ///   // Use result.Session
    /// </summary>
    public static class SessionValidator
    {
        #region Core Validation

        /// <summary>
        /// Validate that a client has access to a session for a specific operation.
        /// Performs basic checks: manager exists, session exists.
        /// </summary>
        public static SessionValidationResult ValidateSessionAccess(
            string sessionName,
            ulong clientId,
            string operation)
        {
            // Check GameSessionManager exists
            var manager = GetSessionManager();
            if (manager == null)
            {
                string error = $"GameSessionManager not available for '{operation}'";
                NetworkLogger.Error("SessionValidator", error);
                return SessionValidationResult.Failure(error);
            }

            // Get session
            var session = manager.GetSecureContainer(sessionName);
            if (session == null)
            {
                string error = $"Session '{sessionName}' not found for '{operation}'";
                NetworkLogger.Warning("SessionValidator", error);
                return SessionValidationResult.Failure(error);
            }

            NetworkLogger.DebugLog("SessionValidator", $"Client {clientId} validated for '{operation}' in '{sessionName}'");
            return SessionValidationResult.Success(session);
        }

        /// <summary>
        /// Validate session exists without checking client authorization.
        /// Useful for read-only operations or system-level checks.
        /// </summary>
        public static SessionValidationResult ValidateSessionExists(string sessionName)
        {
            var manager = GetSessionManager();
            if (manager == null)
            {
                string error = "GameSessionManager not available";
                NetworkLogger.Error("SessionValidator", error);
                return SessionValidationResult.Failure(error);
            }

            var session = manager.GetSecureContainer(sessionName);
            if (session == null)
            {
                string error = $"Session '{sessionName}' not found";
                NetworkLogger.Warning("SessionValidator", error);
                return SessionValidationResult.Failure(error);
            }

            return SessionValidationResult.Success(session);
        }

        /// <summary>
        /// Validate that session is in a specific state
        /// </summary>
        public static bool ValidateSessionState(
            SessionContainer session,
            SessionContainer.SessionState expectedState,
            string operation)
        {
            if (session == null)
            {
                NetworkLogger.Error("SessionValidator", $"Cannot validate state for null session during '{operation}'");
                return false;
            }

            if (session.State != expectedState)
            {
                NetworkLogger.Warning("SessionValidator",
                    $"Session '{session.SessionName}' in wrong state for '{operation}': " +
                    $"Expected {expectedState}, got {session.State}");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validate session is in one of the allowed states
        /// </summary>
        public static bool ValidateSessionStateAny(
            SessionContainer session,
            SessionContainer.SessionState[] allowedStates,
            string operation)
        {
            if (session == null)
            {
                NetworkLogger.Error("SessionValidator", $"Cannot validate state for null session during '{operation}'");
                return false;
            }

            foreach (var state in allowedStates)
            {
                if (session.State == state)
                    return true;
            }

            string allowedStatesStr = string.Join(", ", allowedStates);
            NetworkLogger.Warning("SessionValidator",
                $"Session '{session.SessionName}' in wrong state for '{operation}': " +
                $"Expected one of [{allowedStatesStr}], got {session.State}");
            return false;
        }

        #endregion

        #region Client Validation

        /// <summary>
        /// Validate that a client is the host of a session
        /// </summary>
        public static bool ValidateIsHost(SessionContainer session, ulong clientId, string operation)
        {
            if (session == null)
            {
                NetworkLogger.Error("SessionValidator", $"Cannot validate host for null session during '{operation}'");
                return false;
            }

            if (session.HostClientId != clientId)
            {
                NetworkLogger.Warning("SessionValidator",
                    $"Client {clientId} is not host of session '{session.SessionName}' for '{operation}'");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validate that a client is a member of a session
        /// </summary>
        public static bool ValidateIsMember(SessionContainer session, ulong clientId, string operation)
        {
            if (session == null)
            {
                NetworkLogger.Error("SessionValidator", $"Cannot validate membership for null session during '{operation}'");
                return false;
            }

            if (session.GetPlayer(clientId) == null)
            {
                NetworkLogger.Warning("SessionValidator",
                    $"Client {clientId} is not member of session '{session.SessionName}' for '{operation}'");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validate minimum number of players in session
        /// </summary>
        public static bool ValidateMinimumPlayers(SessionContainer session, int minimumPlayers, string operation)
        {
            if (session == null)
            {
                NetworkLogger.Error("SessionValidator", $"Cannot validate player count for null session during '{operation}'");
                return false;
            }

            int playerCount = session.PlayerCount;
            if (playerCount < minimumPlayers)
            {
                NetworkLogger.Warning("SessionValidator",
                    $"Session '{session.SessionName}' has insufficient players for '{operation}': " +
                    $"Required {minimumPlayers}, got {playerCount}");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validate maximum number of players not exceeded
        /// </summary>
        public static bool ValidateMaximumPlayers(SessionContainer session, int maximumPlayers, string operation)
        {
            if (session == null)
            {
                NetworkLogger.Error("SessionValidator", $"Cannot validate player count for null session during '{operation}'");
                return false;
            }

            int playerCount = session.PlayerCount;
            if (playerCount > maximumPlayers)
            {
                NetworkLogger.Warning("SessionValidator",
                    $"Session '{session.SessionName}' has too many players for '{operation}': " +
                    $"Maximum {maximumPlayers}, got {playerCount}");
                return false;
            }

            return true;
        }

        #endregion

        #region Composite Validations

        /// <summary>
        /// Validate host access: client is host and has access to session
        /// </summary>
        public static SessionValidationResult ValidateHostAccess(
            string sessionName,
            ulong clientId,
            string operation)
        {
            var result = ValidateSessionAccess(sessionName, clientId, operation);
            if (!result.IsValid)
                return result;

            if (!ValidateIsHost(result.Session, clientId, operation))
                return SessionValidationResult.Failure($"Client {clientId} is not host");

            return result;
        }

        /// <summary>
        /// Validate game start requirements: host access, minimum players, lobby state
        /// </summary>
        public static SessionValidationResult ValidateGameStartRequirements(
            string sessionName,
            ulong hostClientId,
            int minimumPlayers = 2)
        {
            // Validate host access
            var result = ValidateHostAccess(sessionName, hostClientId, "StartGame");
            if (!result.IsValid)
                return result;

            var session = result.Session;

            // Validate state
            if (!ValidateSessionState(session, SessionContainer.SessionState.Lobby, "StartGame"))
                return SessionValidationResult.Failure("Session not in Lobby state");

            // Validate minimum players
            if (!ValidateMinimumPlayers(session, minimumPlayers, "StartGame"))
                return SessionValidationResult.Failure($"Insufficient players (need {minimumPlayers})");

            return SessionValidationResult.Success(session);
        }

        /// <summary>
        /// Validate player action during game: member access, InGame state
        /// </summary>
        public static SessionValidationResult ValidatePlayerAction(
            string sessionName,
            ulong clientId,
            string actionName)
        {
            var result = ValidateSessionAccess(sessionName, clientId, actionName);
            if (!result.IsValid)
                return result;

            var session = result.Session;

            // Validate state
            if (!ValidateSessionState(session, SessionContainer.SessionState.InGame, actionName))
                return SessionValidationResult.Failure("Game not running");

            return SessionValidationResult.Success(session);
        }

        #endregion

        #region Helper Methods

        private static GameSessionManager GetSessionManager()
        {
            // Check if singleton pattern is used
            if (GameSessionManager.Instance != null)
                return GameSessionManager.Instance;

            // Fallback: try to find in scene (legacy support)
            return Object.FindFirstObjectByType<GameSessionManager>();
        }

        #endregion

        #region Statistics and Diagnostics

        private static int _validationAttempts = 0;
        private static int _validationFailures = 0;

        /// <summary>
        /// Get total number of validation attempts
        /// </summary>
        public static int GetValidationAttempts() => _validationAttempts;

        /// <summary>
        /// Get number of validation failures
        /// </summary>
        public static int GetValidationFailures() => _validationFailures;

        /// <summary>
        /// Get validation success rate (0-1)
        /// </summary>
        public static float GetSuccessRate()
        {
            if (_validationAttempts == 0) return 1f;
            return 1f - ((float)_validationFailures / _validationAttempts);
        }

        #endregion
    }
}
