// Ajout pour détection prefab asset dans l'éditeur
#if UNITY_EDITOR
using UnityEditor;
#endif
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;
using TMPro;

/// <summary>
/// Circle pawn for the Circle Game.
/// Players are represented as colored circles with names.
/// </summary>
// Permet d'exécuter du code dans l'éditeur pour voir le rendu
[ExecuteInEditMode]
public class CirclePawn : NetworkBehaviour, IServerMovablePawn
{
    [Header("Visual Settings")]
    [SerializeField] private Color[] playerColors = new Color[]
    {
        new Color(1f, 0.3f, 0.3f),    // Red
        new Color(0.3f, 0.5f, 1f),    // Blue
        new Color(0.3f, 1f, 0.3f),    // Green
        new Color(1f, 1f, 0.3f),      // Yellow
        new Color(1f, 0.3f, 1f),      // Magenta
        new Color(0.3f, 1f, 1f),      // Cyan
        new Color(1f, 0.6f, 0.3f),    // Orange
        new Color(0.7f, 0.3f, 1f)     // Purple
    };

    [Header("Circle Settings")]
    [SerializeField] private int circleSegments = 32;
    [SerializeField] private float circleRadius = 0.5f;

    [Header("Name Display")]
    [SerializeField] private Vector3 nameOffset = new Vector3(0, 1.2f, 0);
    [SerializeField] private float nameFontSize = 3f;

    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;
    [SerializeField] private float mapBoundary = 12f;

    // Networked state
    public NetworkVariable<FixedString64Bytes> PlayerName = new NetworkVariable<FixedString64Bytes>(
        default,
        NetworkVariableReadPermission.Everyone,
        NetworkVariableWritePermission.Server
    );

    public NetworkVariable<int> ColorIndex = new NetworkVariable<int>(
        0,
        NetworkVariableReadPermission.Everyone,
        NetworkVariableWritePermission.Server
    );

    private TextMeshPro nameLabel;
    private MeshRenderer meshRenderer;
    private Vector3 sessionOffset;

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();

        PlayerName.OnValueChanged += OnNameChanged;
        ColorIndex.OnValueChanged += OnColorChanged;

        CreateCircleVisual();
        SetupNameLabel();
        ApplyColor();
        UpdateNameDisplay();

        Debug.Log($"[CirclePawn] Spawned for client {OwnerClientId}");
    }

    // Permet de générer le rendu dans l'éditeur dès qu'une propriété change ou à la sauvegarde
    private void OnValidate()
    {
#if UNITY_EDITOR
        // Ne pas modifier les prefab assets directement
        if (!Application.isPlaying && !PrefabUtility.IsPartOfPrefabAsset(gameObject))
        {
            CreateCircleVisual();
            SetupNameLabel();
            ApplyColor();
            UpdateNameDisplay();
        }
#endif
    }

    public override void OnNetworkDespawn()
    {
        PlayerName.OnValueChanged -= OnNameChanged;
        ColorIndex.OnValueChanged -= OnColorChanged;
        base.OnNetworkDespawn();
    }

    private void CreateCircleVisual()
    {
#if UNITY_EDITOR
        if (PrefabUtility.IsPartOfPrefabAsset(gameObject))
            return;
#endif
        // Create circle mesh
        var meshFilter = GetComponent<MeshFilter>();
        if (meshFilter == null)
            meshFilter = gameObject.AddComponent<MeshFilter>();

        meshRenderer = GetComponent<MeshRenderer>();
        if (meshRenderer == null)
            meshRenderer = gameObject.AddComponent<MeshRenderer>();

        meshFilter.mesh = CreateCircleMesh();

        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = Color.white;
#if UNITY_EDITOR
        if (!Application.isPlaying)
            meshRenderer.sharedMaterial = mat;
        else
            meshRenderer.material = mat;
#else
        meshRenderer.material = mat;
#endif

        // Mesh is generated in the XZ plane, so no root rotation is required.
    }

    private Mesh CreateCircleMesh()
    {
        var mesh = new Mesh();

        var vertices = new Vector3[circleSegments + 1];
        var triangles = new int[circleSegments * 3];

        // Center vertex
        vertices[0] = Vector3.zero;

        // Circle vertices
        for (int i = 0; i < circleSegments; i++)
        {
            float angle = (i / (float)circleSegments) * Mathf.PI * 2f;
            // Build circle in XZ plane so that "up" remains +Y for name offsets/labels.
            vertices[i + 1] = new Vector3(
                Mathf.Cos(angle) * circleRadius,
                0f,
                Mathf.Sin(angle) * circleRadius
            );
        }

        // Triangles (fan from center)
        for (int i = 0; i < circleSegments; i++)
        {
            triangles[i * 3] = 0;
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = (i + 1) % circleSegments + 1;
        }

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();

        return mesh;
    }

    private void SetupNameLabel()
    {
#if UNITY_EDITOR
        if (PrefabUtility.IsPartOfPrefabAsset(gameObject))
            return;
#endif
        var existing = transform.Find("NameLabel");
        if (existing != null)
        {
            nameLabel = existing.GetComponent<TextMeshPro>();
            return;
        }

        var labelGO = new GameObject("NameLabel");
        labelGO.transform.SetParent(transform);
        labelGO.transform.localPosition = nameOffset;

        nameLabel = labelGO.AddComponent<TextMeshPro>();
        nameLabel.alignment = TextAlignmentOptions.Center;
        nameLabel.fontSize = nameFontSize;
        nameLabel.color = Color.white;
        nameLabel.sortingOrder = 10;
    }

    private void OnNameChanged(FixedString64Bytes old, FixedString64Bytes newVal) => UpdateNameDisplay();
    private void OnColorChanged(int old, int newVal) => ApplyColor();

    private void UpdateNameDisplay()
    {
        if (nameLabel != null)
        {
            string name = PlayerName.Value.ToString();
            nameLabel.text = string.IsNullOrEmpty(name) ? $"Player {OwnerClientId}" : name;
        }
    }

    private void ApplyColor()
    {
        if (meshRenderer != null)
        {
            int idx = ColorIndex.Value % playerColors.Length;
#if UNITY_EDITOR
            if (!Application.isPlaying && meshRenderer.sharedMaterial != null)
                meshRenderer.sharedMaterial.color = playerColors[idx];
            else if (meshRenderer.material != null)
                meshRenderer.material.color = playerColors[idx];
#else
            if (meshRenderer.material != null)
                meshRenderer.material.color = playerColors[idx];
#endif
        }
    }

    /// <summary>
    /// [Server] Initialize the circle pawn.
    /// </summary>
    public void Initialize(string playerName, int colorIndex, Vector3 worldOffset)
    {
        if (!IsServer) return;

        PlayerName.Value = new FixedString64Bytes(playerName);
        ColorIndex.Value = colorIndex;
        sessionOffset = worldOffset;

        Debug.Log($"[CirclePawn] Initialized: {playerName}, color {colorIndex}");
    }

    /// <summary>
    /// [Server] Move the pawn.
    /// </summary>
    public void Move(Vector2 direction)
    {
        if (!IsServer) return;

        Vector3 movement = new Vector3(direction.x, 0, direction.y) * moveSpeed * Time.deltaTime;
        Vector3 newPos = transform.position + movement;

        // Clamp to boundaries
        float minX = sessionOffset.x - mapBoundary;
        float maxX = sessionOffset.x + mapBoundary;
        float minZ = sessionOffset.z - mapBoundary;
        float maxZ = sessionOffset.z + mapBoundary;

        newPos.x = Mathf.Clamp(newPos.x, minX, maxX);
        newPos.z = Mathf.Clamp(newPos.z, minZ, maxZ);

        transform.position = newPos;
    }


    /// <summary>
    /// [Server] Configure movement speed (used by game definitions).
    /// </summary>
    public void SetMoveSpeed(float speed)
    {
        if (!IsServer) return;
        moveSpeed = Mathf.Max(0f, speed);
    }

    private void LateUpdate()
    {
        // Keep name facing camera
        if (nameLabel != null && Camera.main != null)
        {
            nameLabel.transform.rotation = Quaternion.LookRotation(
                nameLabel.transform.position - Camera.main.transform.position
            );
        }
    }
}
