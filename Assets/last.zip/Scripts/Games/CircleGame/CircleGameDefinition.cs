 // Ajout pour détection prefab asset dans l'éditeur
#if UNITY_EDITOR
using UnityEditor;
#endif
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Circle Game - Players are represented as colored circles with names.
/// Features an arena-style map with a different visual theme.
/// </summary>
[CreateAssetMenu(fileName = "CircleGame", menuName = "Games/Circle Game")]
public class CircleGameDefinition : GameDefinitionAsset
{
    private enum ClientVisualState
    {
        Idle,
        Configured,
        VisualsCreated
    }

    private StateMachine<ClientVisualState> clientStateMachine;

    // Override to provide defaults even if asset isn't configured
    public override string GameId => string.IsNullOrEmpty(gameId) ? "circle-game" : gameId;
    public override string DisplayName => string.IsNullOrEmpty(displayName) ? "Circle Game" : displayName;

    [Header("Arena Settings")]
    [SerializeField] private float arenaRadius = 12f;
    [SerializeField] private Color floorColor = new Color(0.15f, 0.15f, 0.25f); // Dark blue
    [SerializeField] private Color ringColor = new Color(0.4f, 0.2f, 0.5f);     // Purple ring
    [SerializeField] private int floorSegments = 64;

    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Visual")]
    [SerializeField] private float cameraHeight = 18f;

    private GameObject sceneRoot;

    private void EnsureClientStateMachine()
    {
        if (clientStateMachine != null)
        {
            return;
        }

        clientStateMachine = new StateMachine<ClientVisualState>(ClientVisualState.Idle);
    }

    public override void SetClientWorldOffset(Vector3 worldOffset)
    {
        base.SetClientWorldOffset(worldOffset);
        EnsureClientStateMachine();
        clientStateMachine.TransitionTo(ClientVisualState.Configured);
    }

    public override void SetupGame(Vector3 worldOffset)
    {
        // SERVER ONLY
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsServer)
            return;

        Debug.Log($"[CircleGame] Setting up game at offset {worldOffset}");
    }

    public override Vector3 GetSpawnPosition(int playerIndex, int totalPlayers, Vector3 worldOffset)
    {
        // Spawn players in a circle around the center
        float angle = (playerIndex / (float)totalPlayers) * Mathf.PI * 2f;
        float spawnRadius = arenaRadius * 0.6f;

        return worldOffset + new Vector3(
            Mathf.Cos(angle) * spawnRadius,
            0,
            Mathf.Sin(angle) * spawnRadius
        );
    }

    public override void InitializePawn(NetworkObject pawn, string playerName, int playerIndex, Vector3 worldOffset)
    {
        if (!NetworkManager.Singleton.IsServer) return;

        var circlePawn = pawn.GetComponent<CirclePawn>();
        if (circlePawn != null)
        {
            circlePawn.Initialize(playerName, playerIndex, worldOffset);
            circlePawn.SetMoveSpeed(moveSpeed);
        }

        Debug.Log($"[CircleGame] Initialized pawn for {playerName}");
    }

    public override void SetupClientVisuals()
    {
#if UNITY_EDITOR
        if (PrefabUtility.IsPartOfPrefabAsset(this)) return;
#endif
        if (NetworkManager.Singleton != null && !NetworkManager.Singleton.IsClient)
            return;

        EnsureClientStateMachine();
        if (sceneRoot != null) return;

        sceneRoot = new GameObject("CircleGame_Visuals");
        sceneRoot.transform.position = clientWorldOffset;

        SetupCamera();
        CreateArenaFloor();
        CreateArenaRings();

        clientStateMachine.TransitionTo(ClientVisualState.VisualsCreated);

        Debug.Log("[CircleGame] Client visuals created");
    }

    private void SetupCamera()
    {
        Camera mainCam = Camera.main;
        if (mainCam == null)
        {
            var camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            mainCam = camGO.AddComponent<Camera>();
            camGO.AddComponent<AudioListener>();
        }

        mainCam.transform.position = new Vector3(clientWorldOffset.x, cameraHeight, clientWorldOffset.z);
        mainCam.transform.rotation = Quaternion.Euler(90, 0, 0);
        mainCam.orthographic = true;
        mainCam.orthographicSize = arenaRadius + 2f;
        mainCam.backgroundColor = new Color(0.05f, 0.05f, 0.1f);
        mainCam.clearFlags = CameraClearFlags.SolidColor;

        if (mainCam.GetComponent<CameraFollowPawn>() == null)
        {
            mainCam.gameObject.AddComponent<CameraFollowPawn>();
        }
    }

    private void CreateArenaFloor()
    {
#if UNITY_EDITOR
        if (PrefabUtility.IsPartOfPrefabAsset(this)) return;
#endif
        var floorGO = new GameObject("ArenaFloor");
        floorGO.transform.SetParent(sceneRoot.transform, false);
        floorGO.transform.localPosition = new Vector3(0, -0.1f, 0);
        floorGO.transform.localRotation = Quaternion.Euler(90, 0, 0);

        var meshFilter = floorGO.AddComponent<MeshFilter>();
        var meshRenderer = floorGO.AddComponent<MeshRenderer>();

        meshFilter.mesh = CreateCircleMesh(arenaRadius, floorSegments);

        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = floorColor;
        meshRenderer.material = mat;
    }

    private void CreateArenaRings()
    {
#if UNITY_EDITOR
        if (PrefabUtility.IsPartOfPrefabAsset(this)) return;
#endif
        // Inner ring
        CreateRing("InnerRing", arenaRadius * 0.3f, 0.2f, ringColor * 0.7f);
        // Middle ring
        CreateRing("MiddleRing", arenaRadius * 0.6f, 0.15f, ringColor * 0.85f);
        // Outer ring (border)
        CreateRing("OuterRing", arenaRadius, 0.3f, ringColor);
    }

    private void CreateRing(string name, float radius, float thickness, Color color)
    {
#if UNITY_EDITOR
        if (PrefabUtility.IsPartOfPrefabAsset(this)) return;
#endif
        var ringGO = new GameObject(name);
        ringGO.transform.SetParent(sceneRoot.transform, false);
        ringGO.transform.localPosition = Vector3.zero;
        ringGO.transform.localRotation = Quaternion.Euler(90, 0, 0);

        var meshFilter = ringGO.AddComponent<MeshFilter>();
        var meshRenderer = ringGO.AddComponent<MeshRenderer>();

        meshFilter.mesh = CreateRingMesh(radius, thickness, 64);

        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = color;
        meshRenderer.material = mat;
    }

    private Mesh CreateCircleMesh(float radius, int segments)
    {
        var mesh = new Mesh();
        var vertices = new Vector3[segments + 1];
        var triangles = new int[segments * 3];

        vertices[0] = Vector3.zero;

        for (int i = 0; i < segments; i++)
        {
            float angle = (i / (float)segments) * Mathf.PI * 2f;
            vertices[i + 1] = new Vector3(
                Mathf.Cos(angle) * radius,
                Mathf.Sin(angle) * radius,
                0
            );
        }

        for (int i = 0; i < segments; i++)
        {
            triangles[i * 3] = 0;
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = (i + 1) % segments + 1;
        }

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();
        return mesh;
    }

    private Mesh CreateRingMesh(float radius, float thickness, int segments)
    {
        var mesh = new Mesh();
        var vertices = new Vector3[segments * 2];
        var triangles = new int[segments * 6];

        float innerRadius = radius - thickness / 2f;
        float outerRadius = radius + thickness / 2f;

        for (int i = 0; i < segments; i++)
        {
            float angle = (i / (float)segments) * Mathf.PI * 2f;
            float cos = Mathf.Cos(angle);
            float sin = Mathf.Sin(angle);

            vertices[i * 2] = new Vector3(cos * innerRadius, sin * innerRadius, 0);
            vertices[i * 2 + 1] = new Vector3(cos * outerRadius, sin * outerRadius, 0);
        }

        for (int i = 0; i < segments; i++)
        {
            int current = i * 2;
            int next = ((i + 1) % segments) * 2;

            triangles[i * 6] = current;
            triangles[i * 6 + 1] = current + 1;
            triangles[i * 6 + 2] = next;

            triangles[i * 6 + 3] = next;
            triangles[i * 6 + 4] = current + 1;
            triangles[i * 6 + 5] = next + 1;
        }

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();
        return mesh;
    }

    public override void HandleMovement(NetworkObject pawn, Vector2 direction)
    {
        if (!NetworkManager.Singleton.IsServer) return;

        var circlePawn = pawn.GetComponent<CirclePawn>();
        if (circlePawn != null)
        {
            circlePawn.Move(direction);
        }
    }

    public override void CleanupGame()
    {
        if (sceneRoot != null)
        {
            Object.Destroy(sceneRoot);
            sceneRoot = null;
        }

        if (clientStateMachine != null)
        {
            clientStateMachine.TransitionTo(ClientVisualState.Idle);
        }
        Debug.Log("[CircleGame] Cleaned up");
    }
}
