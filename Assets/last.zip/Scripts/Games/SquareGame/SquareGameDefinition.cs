using Unity.Netcode;
using UnityEngine;
using TMPro;

/// <summary>
/// Square Game - Players are represented as colored squares with names.
/// Top-down 2D game with random obstacles.
/// </summary>
[CreateAssetMenu(fileName = "SquareGame", menuName = "Games/Square Game")]
public class SquareGameDefinition : GameDefinitionAsset
{
    private enum ClientVisualState
    {
        Idle,
        Configured,
        VisualsCreated
    }

    private StateMachine<ClientVisualState> clientStateMachine;

    // Override to provide defaults even if asset isn't configured
    public override string GameId => string.IsNullOrEmpty(gameId) ? "square-game" : gameId;
    public override string DisplayName => string.IsNullOrEmpty(displayName) ? "Square Game" : displayName;

    [Header("Map Settings")]
    [SerializeField] private Vector2 mapSize = new Vector2(20f, 15f);
    [SerializeField] private Color backgroundColor = new Color(0.2f, 0.5f, 0.2f); // Green grass
    [SerializeField] private Color borderColor = new Color(0.3f, 0.3f, 0.3f);
    [SerializeField] private float borderWidth = 0.5f;

    [Header("Obstacles")]
    [SerializeField] private bool generateObstacles = true;
    [SerializeField] private int obstacleCount = 8;
    [SerializeField] private Color obstacleColor = new Color(0.5f, 0.35f, 0.2f); // Brown

    [Header("Movement")]
    [SerializeField] private float moveSpeed = 5f;

    [Header("Visual")]
    [SerializeField] private float cameraHeight = 15f;
    [SerializeField] private bool followLocalPawn = false;

    private GameObject sceneRoot;
    private Vector3 currentWorldOffset;

    private void EnsureClientStateMachine()
    {
        if (clientStateMachine != null)
        {
            return;
        }

        clientStateMachine = new StateMachine<ClientVisualState>(ClientVisualState.Idle);
    }

    public override void SetClientWorldOffset(Vector3 worldOffset)
    {
        base.SetClientWorldOffset(worldOffset);
        EnsureClientStateMachine();
        clientStateMachine.TransitionTo(ClientVisualState.Configured);
    }

    public override void SetupGame(Vector3 worldOffset)
    {
        // SERVER ONLY
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsServer)
            return;

        currentWorldOffset = worldOffset;
        Debug.Log($"[SquareGame] Setting up game at offset {worldOffset}");

        // Server doesn't need to create visuals, clients do that
    }

    public override Vector3 GetSpawnPosition(int playerIndex, int totalPlayers, Vector3 worldOffset)
    {
        float halfW = (mapSize.x / 2f) - 1f;
        float halfH = (mapSize.y / 2f) - 1f;

        if (totalPlayers <= 1)
        {
            return worldOffset;
        }

        if (totalPlayers <= 4)
        {
            // Corners for small games
            switch (playerIndex % 4)
            {
                case 0: return worldOffset + new Vector3(-halfW, 0, -halfH);
                case 1: return worldOffset + new Vector3(halfW, 0, -halfH);
                case 2: return worldOffset + new Vector3(-halfW, 0, halfH);
                case 3: return worldOffset + new Vector3(halfW, 0, halfH);
            }
        }

        // Circle distribution for larger games
        float angle = (playerIndex / (float)totalPlayers) * Mathf.PI * 2f;
        float radius = Mathf.Min(halfW, halfH) * 0.7f;
        return worldOffset + new Vector3(
            Mathf.Cos(angle) * radius,
            0,
            Mathf.Sin(angle) * radius
        );
    }

    public override void InitializePawn(NetworkObject pawn, string playerName, int playerIndex, Vector3 worldOffset)
    {
        // SERVER ONLY
        if (!NetworkManager.Singleton.IsServer) return;

        var playerPawn = pawn.GetComponent<PlayerPawn>();
        if (playerPawn != null)
        {
            // Pass the map boundary based on map size
            float boundary = Mathf.Max(mapSize.x / 2f, mapSize.y / 2f);
            playerPawn.Initialize(playerName, playerIndex, worldOffset, boundary);
            playerPawn.SetMoveSpeed(moveSpeed);
        }

        Debug.Log($"[SquareGame] Initialized pawn for {playerName} with color index {playerIndex}");
    }

    public override void SetupClientVisuals()
    {
        // CLIENT ONLY - Create local scene visuals
        if (NetworkManager.Singleton != null && !NetworkManager.Singleton.IsClient)
            return;

        EnsureClientStateMachine();

        if (sceneRoot != null) return;

        sceneRoot = new GameObject("SquareGame_Visuals");
        sceneRoot.transform.position = clientWorldOffset;

        // Setup camera
        SetupCamera();

        // Create background
        CreateBackground();

        // Create borders
        CreateBorders();

        // Random obstacles
        if (generateObstacles)
        {
            GenerateObstacles();
        }

        clientStateMachine.TransitionTo(ClientVisualState.VisualsCreated);

        Debug.Log("[SquareGame] Client visuals created");
    }

    private void SetupCamera()
    {
        Camera mainCam = Camera.main;
        if (mainCam == null)
        {
            var camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            mainCam = camGO.AddComponent<Camera>();
            if (Object.FindFirstObjectByType<AudioListener>() == null)
            {
                camGO.AddComponent<AudioListener>();
            }
        }
        else if (Object.FindFirstObjectByType<AudioListener>() == null)
        {
            mainCam.gameObject.AddComponent<AudioListener>();
        }

        mainCam.transform.position = new Vector3(clientWorldOffset.x, cameraHeight, clientWorldOffset.z);
        mainCam.transform.rotation = Quaternion.Euler(90, 0, 0);
        mainCam.orthographic = true;
        mainCam.orthographicSize = mapSize.y / 2f;
        mainCam.backgroundColor = backgroundColor;
        mainCam.clearFlags = CameraClearFlags.SolidColor;

        // Add camera follow only if requested (keeps shared centered view otherwise)
        var follow = mainCam.GetComponent<CameraFollowPawn>();
        if (followLocalPawn)
        {
            if (follow == null)
            {
                mainCam.gameObject.AddComponent<CameraFollowPawn>();
            }
            else
            {
                follow.enabled = true;
            }
        }
        else if (follow != null)
        {
            follow.enabled = false;
        }
    }

    private void CreateBackground()
    {
        var bgGO = new GameObject("Background");
        bgGO.transform.SetParent(sceneRoot.transform, false);
        bgGO.transform.localPosition = new Vector3(0, -0.1f, 0);
        bgGO.transform.localRotation = Quaternion.Euler(90, 0, 0);

        var meshFilter = bgGO.AddComponent<MeshFilter>();
        var meshRenderer = bgGO.AddComponent<MeshRenderer>();

        meshFilter.mesh = CreateQuadMesh(mapSize.x, mapSize.y);

        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = backgroundColor;
        meshRenderer.material = mat;
    }

    private void CreateBorders()
    {
        float halfW = mapSize.x / 2f;
        float halfH = mapSize.y / 2f;

        CreateBorder("Top", new Vector3(0, 0, halfH + borderWidth / 2f), new Vector2(mapSize.x + borderWidth * 2, borderWidth));
        CreateBorder("Bottom", new Vector3(0, 0, -halfH - borderWidth / 2f), new Vector2(mapSize.x + borderWidth * 2, borderWidth));
        CreateBorder("Left", new Vector3(-halfW - borderWidth / 2f, 0, 0), new Vector2(borderWidth, mapSize.y));
        CreateBorder("Right", new Vector3(halfW + borderWidth / 2f, 0, 0), new Vector2(borderWidth, mapSize.y));
    }

    private void CreateBorder(string name, Vector3 position, Vector2 size)
    {
        var go = new GameObject($"Border_{name}");
        go.transform.SetParent(sceneRoot.transform, false);
        go.transform.localPosition = position;
        go.transform.localRotation = Quaternion.Euler(90, 0, 0);

        var meshFilter = go.AddComponent<MeshFilter>();
        var meshRenderer = go.AddComponent<MeshRenderer>();

        meshFilter.mesh = CreateQuadMesh(size.x, size.y);

        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = borderColor;
        meshRenderer.material = mat;
    }

    private void GenerateObstacles()
    {
        // Deterministic seed so all clients see the same obstacle layout for a session.
        var previousState = Random.state;
        Random.InitState(GetDeterministicObstacleSeed());

        float halfW = (mapSize.x / 2f) - 2f;
        float halfH = (mapSize.y / 2f) - 2f;

        for (int i = 0; i < obstacleCount; i++)
        {
            float x = Random.Range(-halfW, halfW);
            float z = Random.Range(-halfH, halfH);
            float w = Random.Range(1f, 3f);
            float h = Random.Range(1f, 3f);

            var go = new GameObject($"Obstacle_{i}");
            go.transform.SetParent(sceneRoot.transform, false);
            go.transform.localPosition = new Vector3(x, 0.05f, z);
            go.transform.localRotation = Quaternion.Euler(90, 0, 0);

            var meshFilter = go.AddComponent<MeshFilter>();
            var meshRenderer = go.AddComponent<MeshRenderer>();

            meshFilter.mesh = CreateQuadMesh(w, h);

            var mat = new Material(Shader.Find("Sprites/Default"));
            mat.color = obstacleColor;
            meshRenderer.material = mat;
        }

        Random.state = previousState;
    }

    private int GetDeterministicObstacleSeed()
    {
        unchecked
        {
            int seed = 17;
            seed = seed * 31 + Mathf.RoundToInt(clientWorldOffset.x * 1000f);
            seed = seed * 31 + Mathf.RoundToInt(clientWorldOffset.z * 1000f);
            seed = seed * 31 + obstacleCount;
            seed = seed * 31 + Mathf.RoundToInt(mapSize.x * 100f);
            seed = seed * 31 + Mathf.RoundToInt(mapSize.y * 100f);
            seed = seed * 31 + GameId.GetHashCode();
            return seed;
        }
    }

    private Mesh CreateQuadMesh(float width, float height)
    {
        var mesh = new Mesh();
        float halfW = width / 2f;
        float halfH = height / 2f;

        mesh.vertices = new Vector3[]
        {
            new Vector3(-halfW, -halfH, 0),
            new Vector3(halfW, -halfH, 0),
            new Vector3(halfW, halfH, 0),
            new Vector3(-halfW, halfH, 0)
        };

        mesh.triangles = new int[] { 0, 2, 1, 0, 3, 2 };
        mesh.normals = new Vector3[] { Vector3.back, Vector3.back, Vector3.back, Vector3.back };
        mesh.uv = new Vector2[] { Vector2.zero, Vector2.right, Vector2.one, Vector2.up };

        return mesh;
    }

    public override void HandleMovement(NetworkObject pawn, Vector2 direction)
    {
        // SERVER ONLY
        if (!NetworkManager.Singleton.IsServer) return;

        var playerPawn = pawn.GetComponent<PlayerPawn>();
        if (playerPawn != null)
        {
            playerPawn.Move(direction);
        }
    }

    public override void CleanupGame()
    {
        if (sceneRoot != null)
        {
            Object.Destroy(sceneRoot);
            sceneRoot = null;
        }

        if (clientStateMachine != null)
        {
            clientStateMachine.TransitionTo(ClientVisualState.Idle);
        }
        Debug.Log("[SquareGame] Cleaned up");
    }
}
