using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// ScriptableObject holding references to network prefabs used throughout the game.
/// Create an instance via Assets > Create > Data > Prefab References.
/// </summary>
[CreateAssetMenu(fileName = "PrefabReferences", menuName = "Data/Prefab References")]
public class PrefabReferences : ScriptableObject
{
    [Header("Player Pawns")]
    [Tooltip("The default pawn prefab spawned for players when a game starts (Square).")]
    [SerializeField] private NetworkObject squarePrefab;

    [Header("Player Connection")]
    [Tooltip("The default player prefab assigned to NetworkManager for client connections.")]
    [SerializeField] private NetworkObject defaultPlayerPrefab;

    [Header("Network Services")]
    [Tooltip("The SessionRpcHub prefab spawned once on server start for session management.")]
    [SerializeField] private NetworkObject sessionRpcHubPrefab;

    [Header("Additional Network Prefabs")]
    [Tooltip("Optional extra network prefabs (new pawns/games/etc.) to sync into the NetworkPrefabList.")]
    [SerializeField] private NetworkObject[] additionalNetworkPrefabs;

    // -------------------------------------------------------------------------
    // Prefabs NOT included here (and why):
    // - NetworkManagerRoot: Scene-placed singleton, never spawned dynamically
    // - NetworkBootstrapUI: UI-only prefab, not a networked object
    // -------------------------------------------------------------------------

    /// <summary>
    /// The default pawn prefab for players (Square).
    /// </summary>
    public NetworkObject SquarePrefab => squarePrefab;

    /// <summary>
    /// The default player prefab for NetworkManager client connections.
    /// </summary>
    public NetworkObject DefaultPlayerPrefab => defaultPlayerPrefab;

    /// <summary>
    /// The SessionRpcHub prefab for session management RPCs.
    /// </summary>
    public NetworkObject SessionRpcHubPrefab => sessionRpcHubPrefab;

    /// <summary>
    /// Additional network prefabs to register (new pawns/games/services).
    /// </summary>
    public IReadOnlyList<NetworkObject> AdditionalNetworkPrefabs => additionalNetworkPrefabs;

    /// <summary>
    /// Returns all non-null network prefabs as an array.
    /// Useful for batch registration with NetworkManager.
    /// </summary>
    public NetworkObject[] GetAllPrefabs()
    {
        var list = new System.Collections.Generic.List<NetworkObject>();

        if (squarePrefab != null) list.Add(squarePrefab);
        if (defaultPlayerPrefab != null) list.Add(defaultPlayerPrefab);
        if (sessionRpcHubPrefab != null) list.Add(sessionRpcHubPrefab);
        if (additionalNetworkPrefabs != null)
        {
            foreach (var extra in additionalNetworkPrefabs)
            {
                if (extra != null) list.Add(extra);
            }
        }

        return list.ToArray();
    }
}
