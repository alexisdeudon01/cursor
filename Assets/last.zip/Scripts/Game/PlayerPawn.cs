using Unity.Collections;
using Unity.Netcode;
using UnityEngine;
using TMPro;
using Core.Utilities;

/// <summary>
/// Controller for player pawns (squares) in the game.
/// Displays player name above the pawn and handles visual appearance.
/// Attach to the Square prefab.
/// </summary>
public class PlayerPawn : NetworkBehaviour, IServerMovablePawn
{
    [Header("Visual Settings")]
    [SerializeField] private Color[] playerColors = new Color[]
    {
        new Color(0.2f, 0.6f, 1f),    // Blue
        new Color(1f, 0.4f, 0.4f),    // Red
        new Color(0.4f, 1f, 0.4f),    // Green
        new Color(1f, 1f, 0.4f),      // Yellow
        new Color(1f, 0.4f, 1f),      // Magenta
        new Color(0.4f, 1f, 1f),      // Cyan
        new Color(1f, 0.6f, 0.2f),    // Orange
        new Color(0.6f, 0.4f, 1f)     // Purple
    };

    [Header("Name Display")]
    [SerializeField] private Vector3 nameOffset = new Vector3(0, 1.5f, 0);
    [SerializeField] private float nameFontSize = 3f;

    [Header("Movement")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float mapBoundary = 9f; // Match GameSceneSetup map size

    // Session world offset (for isolating multiple concurrent games)
    private Vector3 sessionOffset = Vector3.zero;

    // Synced player name
    public NetworkVariable<FixedString64Bytes> PlayerName = new NetworkVariable<FixedString64Bytes>(
        default,
        NetworkVariableReadPermission.Everyone,
        NetworkVariableWritePermission.Server
    );

    // Synced color index
    public NetworkVariable<int> ColorIndex = new NetworkVariable<int>(
        0,
        NetworkVariableReadPermission.Everyone,
        NetworkVariableWritePermission.Server
    );

    private TextMeshPro nameLabel;
    private SpriteRenderer spriteRenderer;
    private MeshRenderer meshRenderer;
    private float lastClientPosLogTime;
    private const float ClientPosLogInterval = 0.5f;

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();

        // Subscribe to name changes
        PlayerName.OnValueChanged += OnPlayerNameChanged;
        ColorIndex.OnValueChanged += OnColorIndexChanged;

        // Setup visuals
        EnsureRenderers();
        SetupNameLabel();
        ApplyColor();
        UpdateNameDisplay();

        Debug.Log($"[PlayerPawn] Spawned for client {OwnerClientId}, name: {PlayerName.Value}");
    }

    public override void OnNetworkDespawn()
    {
        PlayerName.OnValueChanged -= OnPlayerNameChanged;
        ColorIndex.OnValueChanged -= OnColorIndexChanged;
        base.OnNetworkDespawn();
    }

    private void SetupNameLabel()
    {
        // Check if we already have a name label
        var existing = transform.Find("NameLabel");
        if (existing != null)
        {
            nameLabel = existing.GetComponent<TextMeshPro>();
            return;
        }

        // Create name label GameObject
        var labelGO = new GameObject("NameLabel");
        labelGO.transform.SetParent(transform);
        labelGO.transform.localPosition = nameOffset;
        labelGO.transform.localRotation = Quaternion.identity;

        // Add TextMeshPro component
        nameLabel = labelGO.AddComponent<TextMeshPro>();
        nameLabel.alignment = TextAlignmentOptions.Center;
        nameLabel.fontSize = nameFontSize;
        nameLabel.color = Color.white;
        nameLabel.sortingOrder = 10;

        // Make it face the camera (for 2D top-down view)
        labelGO.transform.rotation = Quaternion.Euler(90, 0, 0);
    }

    private void OnPlayerNameChanged(FixedString64Bytes oldValue, FixedString64Bytes newValue)
    {
        UpdateNameDisplay();
    }

    private void OnColorIndexChanged(int oldValue, int newValue)
    {
        ApplyColor();
    }

    private void UpdateNameDisplay()
    {
        if (nameLabel != null)
        {
            string displayName = PlayerName.Value.ToString();
            if (string.IsNullOrEmpty(displayName))
            {
                displayName = $"Player {OwnerClientId}";
            }
            nameLabel.text = displayName;
        }
    }

    private void ApplyColor()
    {
        Color color = GetColorForIndex(ColorIndex.Value);

        // Try SpriteRenderer first (2D)
        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();

        if (spriteRenderer != null)
        {
            spriteRenderer.color = color;
            return;
        }

        // Try MeshRenderer (3D)
        if (meshRenderer == null)
            meshRenderer = GetComponent<MeshRenderer>();

        if (meshRenderer != null && meshRenderer.material != null)
        {
            meshRenderer.material.color = color;
        }
    }

    private void EnsureRenderers()
    {
        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
            return;

        if (meshRenderer == null)
            meshRenderer = GetComponent<MeshRenderer>();
        if (meshRenderer != null)
            return;

        var visual = new GameObject("PawnVisual");
        visual.transform.SetParent(transform, false);
        visual.transform.localPosition = Vector3.zero;
        visual.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
        visual.transform.localScale = Vector3.one;

        var meshFilter = visual.AddComponent<MeshFilter>();
        meshRenderer = visual.AddComponent<MeshRenderer>();
        meshFilter.mesh = CreateQuadMesh(1f, 1f);

        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = Color.white;
        meshRenderer.material = mat;
    }

    private Color GetColorForIndex(int index)
    {
        if (playerColors == null || playerColors.Length == 0)
            return Color.white;

        return playerColors[index % playerColors.Length];
    }

    /// <summary>
    /// [Server] Set the player name and color.
    /// </summary>
    public void Initialize(string playerName, int colorIndex, Vector3 worldOffset = default, float boundary = 9f)
    {
        if (!IsServer)
        {
            Debug.LogWarning("[PlayerPawn] Initialize should only be called on server");
            return;
        }

        PlayerName.Value = new FixedString64Bytes(playerName);
        ColorIndex.Value = colorIndex;
        sessionOffset = worldOffset;
        mapBoundary = boundary;

        Debug.Log($"[PlayerPawn] Initialized: name={playerName}, color={colorIndex}, offset={worldOffset}, boundary={boundary}");
    }

    /// <summary>
    /// [Server] Configure movement speed (used by game definitions).
    /// </summary>
    public void SetMoveSpeed(float speed)
    {
        if (!IsServer) return;
        moveSpeed = Mathf.Max(0f, speed);
    }

    /// <summary>
    /// [Server] Move the pawn in the specified direction.
    /// Called by GameManager/GameRuntime when processing input.
    /// </summary>
    public void Move(Vector2 direction)
    {
        if (!IsServer) return;

        try
        {
            // Convert to 3D movement on XZ plane
            Vector3 movement = new Vector3(direction.x, 0, direction.y) * moveSpeed * Time.deltaTime;
            Vector3 newPosition = transform.position + movement;

            // Clamp to map boundaries relative to session offset
            float minX = sessionOffset.x - mapBoundary;
            float maxX = sessionOffset.x + mapBoundary;
            float minZ = sessionOffset.z - mapBoundary;
            float maxZ = sessionOffset.z + mapBoundary;

            newPosition.x = Mathf.Clamp(newPosition.x, minX, maxX);
            newPosition.z = Mathf.Clamp(newPosition.z, minZ, maxZ);

            transform.position = newPosition;

            if (direction.sqrMagnitude > 0.001f)
            {
                var look = new Vector3(direction.x, 0f, direction.y);
                if (look.sqrMagnitude > 0.001f)
                {
                    transform.rotation = Quaternion.LookRotation(look);
                }
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogWarning($"[PlayerPawn] Move failed: {ex.Message}");
        }
    }

    /// <summary>
    /// [Client] Request movement from owner client.
    /// </summary>
    [ServerRpc]
    public void RequestMoveServerRpc(Vector2 direction)
    {
        Move(direction);
    }

    private void LateUpdate()
    {
        // Keep name label facing camera
        if (nameLabel != null && Camera.main != null)
        {
            nameLabel.transform.rotation = Quaternion.LookRotation(
                nameLabel.transform.position - Camera.main.transform.position
            );
        }

        if (IsClient && IsOwner)
        {
            float now = Time.time;
            if (now - lastClientPosLogTime >= ClientPosLogInterval)
            {
                lastClientPosLogTime = now;
                NetworkLogger.DebugLog(
                    "PlayerPawn",
                    $"Client pos client={OwnerClientId} pawn={NetworkObjectId} pos={transform.position}"
                );
            }
        }
    }

    private static Mesh CreateQuadMesh(float width, float height)
    {
        var mesh = new Mesh();
        float halfW = width / 2f;
        float halfH = height / 2f;

        mesh.vertices = new Vector3[]
        {
            new Vector3(-halfW, -halfH, 0),
            new Vector3(halfW, -halfH, 0),
            new Vector3(halfW, halfH, 0),
            new Vector3(-halfW, halfH, 0)
        };

        mesh.triangles = new int[] { 0, 2, 1, 0, 3, 2 };
        mesh.normals = new Vector3[] { Vector3.back, Vector3.back, Vector3.back, Vector3.back };
        mesh.uv = new Vector2[] { Vector2.zero, Vector2.right, Vector2.one, Vector2.up };

        return mesh;
    }
}
