using Unity.Netcode;
using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Manages visibility of pawns based on session membership.
/// Only shows pawns from the same session as the local player.
/// Attach to a persistent GameObject on the client.
/// </summary>
public class SessionPawnVisibility : MonoBehaviour
{
    public static SessionPawnVisibility Instance { get; private set; }
    
    // The session name the local player belongs to
    private string localSessionName;
    
    // Track all pawns and their sessions
    private readonly Dictionary<ulong, string> pawnSessions = new Dictionary<ulong, string>();
    
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }
    
    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }
    
    /// <summary>
    /// Set the session name for the local player.
    /// Call this when joining a session/game.
    /// </summary>
    public void SetLocalSession(string sessionName)
    {
        localSessionName = sessionName;
        Debug.Log($"[SessionPawnVisibility] Local session set to: {sessionName}");
        UpdateAllPawnVisibility();
    }
    
    /// <summary>
    /// Clear the local session (when leaving).
    /// </summary>
    public void ClearLocalSession()
    {
        localSessionName = null;
        Debug.Log("[SessionPawnVisibility] Local session cleared");
        // Show all pawns when not in a session
        ShowAllPawns();
    }
    
    /// <summary>
    /// Register a pawn with its session.
    /// Call this when a pawn is spawned on the server.
    /// </summary>
    public void RegisterPawn(ulong networkObjectId, string sessionName)
    {
        pawnSessions[networkObjectId] = sessionName;
        Debug.Log($"[SessionPawnVisibility] Registered pawn {networkObjectId} for session '{sessionName}'");
        UpdateAllPawnVisibility();
    }
    
    /// <summary>
    /// Unregister a pawn.
    /// Call this when a pawn is despawned.
    /// </summary>
    public void UnregisterPawn(ulong networkObjectId)
    {
        pawnSessions.Remove(networkObjectId);
    }
    
    /// <summary>
    /// Update visibility for all pawns.
    /// </summary>
    public void UpdateAllPawnVisibility()
    {
        if (string.IsNullOrEmpty(localSessionName))
        {
            ShowAllPawns();
            return;
        }
        
        // Find all PlayerPawns
        UpdateVisibilityForPawns(FindObjectsByType<PlayerPawn>(FindObjectsSortMode.None));
        UpdateVisibilityForPawns(FindObjectsByType<CirclePawn>(FindObjectsSortMode.None));
    }
    
    private bool ShouldPawnBeVisible(ulong networkObjectId)
    {
        // If we don't know the pawn's session, assume it's visible
        if (!pawnSessions.TryGetValue(networkObjectId, out string pawnSession))
            return true;
        
        // Only visible if same session
        return pawnSession == localSessionName;
    }
    
    private void UpdateVisibilityForPawns<T>(T[] pawns) where T : NetworkBehaviour
    {
        foreach (var pawn in pawns)
        {
            if (pawn == null || pawn.NetworkObject == null) continue;

            ulong networkId = pawn.NetworkObject.NetworkObjectId;
            bool shouldBeVisible = ShouldPawnBeVisible(networkId);
            SetPawnVisible(pawn.gameObject, shouldBeVisible);
        }
    }

    private void SetPawnVisible(GameObject pawnRoot, bool visible)
    {
        if (pawnRoot == null) return;

        // Disable/enable the entire GameObject's renderers
        var renderers = pawnRoot.GetComponentsInChildren<Renderer>(true);
        foreach (var renderer in renderers)
        {
            renderer.enabled = visible;
        }

        // Also handle TextMeshPro for names
        var tmps = pawnRoot.GetComponentsInChildren<TMPro.TextMeshPro>(true);
        foreach (var tmp in tmps)
        {
            tmp.enabled = visible;
        }
    }
    
    private void ShowAllPawns()
    {
        ShowAllForType(FindObjectsByType<PlayerPawn>(FindObjectsSortMode.None));
        ShowAllForType(FindObjectsByType<CirclePawn>(FindObjectsSortMode.None));
    }

    private void ShowAllForType<T>(T[] pawns) where T : NetworkBehaviour
    {
        foreach (var pawn in pawns)
        {
            if (pawn == null) continue;
            SetPawnVisible(pawn.gameObject, true);
        }
    }
    
    /// <summary>
    /// Get session name for a pawn.
    /// </summary>
    public string GetPawnSession(ulong networkObjectId)
    {
        return pawnSessions.TryGetValue(networkObjectId, out string session) ? session : null;
    }
}
