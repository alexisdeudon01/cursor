using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using System.IO;
using Unity.Netcode;
using System.Collections.Generic;

/// <summary>
/// Build Tool - Creates separate Client and Server builds.
/// 
/// CLIENT (Windows): Menu + Client + Game scenes
/// SERVER (Linux): Server scene only
/// </summary>
public class UnifiedBuildTool : EditorWindow
{
    // ============================================
    //   BUILD COMMANDS
    // ============================================

    [MenuItem("Tools/Build/Build Client (Windows)", priority = 0)]
    public static void BuildClient()
    {
        Debug.Log("========================================");
        Debug.Log("  BUILDING CLIENT (Windows)");
        Debug.Log("========================================");

        SetupAssets();

        string outputPath = "Build/Client/Game.exe";
        var scenes = new List<string>();
        
        AddSceneIfExists(scenes, SceneNames.Menu);
        AddSceneIfExists(scenes, SceneNames.Client);
        AddSceneIfExists(scenes, "Game");

        if (scenes.Count == 0)
        {
            Debug.LogError("No client scenes found!");
            return;
        }

        Debug.Log($"Scenes: {string.Join(", ", scenes)}");

        var options = new BuildPlayerOptions
        {
            scenes = scenes.ToArray(),
            locationPathName = outputPath,
            target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.None
        };

        var report = BuildPipeline.BuildPlayer(options);

        if (report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
        {
            Debug.Log($"✅ Client build: {outputPath} ({report.summary.totalSize / 1024 / 1024} MB)");
            EditorUtility.RevealInFinder(outputPath);
        }
        else
        {
            Debug.LogError($"❌ Client build failed: {report.summary.result}");
        }
    }

    [MenuItem("Tools/Build/Build Server (Linux)", priority = 1)]
    public static void BuildServerLinux()
    {
        Debug.Log("========================================");
        Debug.Log("  BUILDING SERVER (Linux)");
        Debug.Log("========================================");

        SetupAssets();

        string outputPath = "Build/Server/GameServer";
        var scenes = new List<string>();
        
        AddSceneIfExists(scenes, SceneNames.Server);
        AddSceneIfExists(scenes, "Game"); // Server also needs Game scene

        if (scenes.Count == 0)
        {
            Debug.LogError("Server scene not found!");
            return;
        }

        Debug.Log($"Scenes: {string.Join(", ", scenes)}");

        var options = new BuildPlayerOptions
        {
            scenes = scenes.ToArray(),
            locationPathName = outputPath,
            target = BuildTarget.StandaloneLinux64,
            subtarget = (int)StandaloneBuildSubtarget.Server,
            options = BuildOptions.None
        };

        var report = BuildPipeline.BuildPlayer(options);

        if (report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
        {
            Debug.Log($"✅ Server build: {outputPath} ({report.summary.totalSize / 1024 / 1024} MB)");
            CreateServerRunScript();
            EditorUtility.RevealInFinder(outputPath);
        }
        else
        {
            Debug.LogError($"❌ Server build failed: {report.summary.result}");
        }
    }

    [MenuItem("Tools/Build/Build Server (Windows - for testing)", priority = 2)]
    public static void BuildServerWindows()
    {
        Debug.Log("========================================");
        Debug.Log("  BUILDING SERVER (Windows)");
        Debug.Log("========================================");

        SetupAssets();

        string outputPath = "Build/ServerWin/GameServer.exe";
        var scenes = new List<string>();
        
        AddSceneIfExists(scenes, SceneNames.Server);
        AddSceneIfExists(scenes, "Game");

        if (scenes.Count == 0)
        {
            Debug.LogError("Server scene not found!");
            return;
        }

        var options = new BuildPlayerOptions
        {
            scenes = scenes.ToArray(),
            locationPathName = outputPath,
            target = BuildTarget.StandaloneWindows64,
            subtarget = (int)StandaloneBuildSubtarget.Server,
            options = BuildOptions.None
        };

        var report = BuildPipeline.BuildPlayer(options);

        if (report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
        {
            Debug.Log($"✅ Server build: {outputPath}");
            EditorUtility.RevealInFinder(outputPath);
        }
        else
        {
            Debug.LogError($"❌ Server build failed: {report.summary.result}");
        }
    }

    [MenuItem("Tools/Build/Build Both", priority = 10)]
    public static void BuildBoth()
    {
        BuildClient();
        BuildServerLinux();
    }

    [MenuItem("Tools/Build/Build All (Client + Servers)", priority = 11)]
    public static void BuildAll()
    {
        SetupAssets();
        BuildServerLinux();
        BuildServerWindows();
        BuildClient();
    }

    // ============================================
    //   ASSET SETUP
    // ============================================

    [MenuItem("Tools/Setup Assets", priority = 20)]
    public static void SetupAssets()
    {
        CreateFolders();
        CreateGameAssets();
        CreatePrefabs();
        RegisterNetworkPrefabs();
        SyncNetworkPrefabsWithReferences();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("✅ Assets ready");
    }

    private static void CreateFolders()
    {
        CreateFolderIfNeeded("Assets/Resources");
        CreateFolderIfNeeded("Assets/Resources/Games");
        CreateFolderIfNeeded("Assets/Prefabs");
        CreateFolderIfNeeded("Assets/Prefabs/Pawns");
    }

    private static void CreateFolderIfNeeded(string path)
    {
        string[] parts = path.Split('/');
        string current = parts[0];
        
        for (int i = 1; i < parts.Length; i++)
        {
            string next = current + "/" + parts[i];
            if (!AssetDatabase.IsValidFolder(next))
                AssetDatabase.CreateFolder(current, parts[i]);
            current = next;
        }
    }

    private static void CreateGameAssets()
    {
        // SquareGame
        string squarePath = "Assets/Resources/Games/SquareGame.asset";
        if (AssetDatabase.LoadAssetAtPath<ScriptableObject>(squarePath) == null)
        {
            var asset = ScriptableObject.CreateInstance<SquareGameDefinition>();
            var pawn = FindPrefabWithComponent<PlayerPawn>() ?? FindPrefabByName("Square");
            if (pawn != null) AssignPawn(asset, pawn);
            AssetDatabase.CreateAsset(asset, squarePath);
        }

        // CircleGame
        string circlePath = "Assets/Resources/Games/CircleGame.asset";
        if (AssetDatabase.LoadAssetAtPath<ScriptableObject>(circlePath) == null)
        {
            var asset = ScriptableObject.CreateInstance<CircleGameDefinition>();
            AssetDatabase.CreateAsset(asset, circlePath);
        }
    }

    private static void CreatePrefabs()
    {
        string path = "Assets/Prefabs/Pawns/CirclePawn.prefab";
        if (AssetDatabase.LoadAssetAtPath<GameObject>(path) != null)
        {
            AssignCirclePawn(path);
            return;
        }

        var go = new GameObject("CirclePawn");
        go.AddComponent<NetworkObject>();
        go.AddComponent<CirclePawn>();
        PrefabUtility.SaveAsPrefabAsset(go, path);
        Object.DestroyImmediate(go);
        AssignCirclePawn(path);
    }

    private static void AssignCirclePawn(string prefabPath)
    {
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
        var netObj = prefab?.GetComponent<NetworkObject>();
        if (netObj == null) return;

        var game = AssetDatabase.LoadAssetAtPath<CircleGameDefinition>("Assets/Resources/Games/CircleGame.asset");
        if (game != null)
        {
            AssignPawn(game, netObj);
            EditorUtility.SetDirty(game);
        }
    }

    private static void AssignPawn(ScriptableObject asset, NetworkObject pawn)
    {
        var so = new SerializedObject(asset);
        var prop = so.FindProperty("pawnPrefab");
        if (prop != null)
        {
            prop.objectReferenceValue = pawn;
            so.ApplyModifiedPropertiesWithoutUndo();
        }
    }

    private static void RegisterNetworkPrefabs()
    {
        var list = FindOrCreateNetworkPrefabsList();
        if (list == null) return;

        var prefabs = FindAllNetworkPrefabs();
        var so = new SerializedObject(list);
        var listProp = so.FindProperty("m_PrefabList") ?? so.FindProperty("PrefabList");
        if (listProp == null) return;

        foreach (var prefab in prefabs)
        {
            if (!IsPrefabInList(listProp, prefab))
            {
                listProp.InsertArrayElementAtIndex(listProp.arraySize);
                var element = listProp.GetArrayElementAtIndex(listProp.arraySize - 1);
                var prop = element.FindPropertyRelative("m_Prefab") ?? element.FindPropertyRelative("Prefab");
                if (prop != null) prop.objectReferenceValue = prefab.gameObject;
            }
        }

        so.ApplyModifiedProperties();
        EditorUtility.SetDirty(list);
    }

    [MenuItem("Tools/Network/Sync Network Prefabs", priority = 50)]
    public static void SyncNetworkPrefabsWithReferences()
    {
        var references = LoadPrefabReferences();
        if (references == null)
        {
            Debug.LogWarning("PrefabReferences.asset not found. Create it via Assets > Create > Data > Prefab References.");
            return;
        }

        var prefabs = references.GetAllPrefabs();
        if (prefabs == null || prefabs.Length == 0)
        {
            Debug.LogWarning("PrefabReferences contains no prefabs to sync.");
            return;
        }

        var list = FindOrCreateNetworkPrefabsList();
        if (list == null)
        {
            Debug.LogError("Could not find or create a NetworkPrefabsList asset.");
            return;
        }

        var so = new SerializedObject(list);
        var listProp = so.FindProperty("m_PrefabList") ?? so.FindProperty("PrefabList");
        if (listProp == null)
        {
            Debug.LogError("NetworkPrefabsList does not expose a prefab list property.");
            return;
        }

        int added = 0;
        foreach (var prefab in prefabs)
        {
            if (prefab == null || IsPrefabInList(listProp, prefab)) continue;

            listProp.InsertArrayElementAtIndex(listProp.arraySize);
            var element = listProp.GetArrayElementAtIndex(listProp.arraySize - 1);
            var prop = element.FindPropertyRelative("m_Prefab") ?? element.FindPropertyRelative("Prefab");
            if (prop != null)
            {
                prop.objectReferenceValue = prefab.gameObject;
                added++;
            }
        }

        so.ApplyModifiedProperties();
        EditorUtility.SetDirty(list);

        Debug.Log(added == 0
            ? "NetworkPrefabsList already in sync with PrefabReferences."
            : $"Added {added} prefab(s) from PrefabReferences to NetworkPrefabsList.");
    }

    private static PrefabReferences LoadPrefabReferences()
    {
        const string defaultPath = "Assets/Resources/PrefabReferences.asset";
        var direct = AssetDatabase.LoadAssetAtPath<PrefabReferences>(defaultPath);
        if (direct != null) return direct;

        foreach (var guid in AssetDatabase.FindAssets("t:PrefabReferences"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            var asset = AssetDatabase.LoadAssetAtPath<PrefabReferences>(path);
            if (asset != null) return asset;
        }

        return Resources.Load<PrefabReferences>("PrefabReferences");
    }

    private static NetworkPrefabsList FindOrCreateNetworkPrefabsList()
    {
        string[] guids = AssetDatabase.FindAssets("t:NetworkPrefabsList");
        if (guids.Length > 0)
            return AssetDatabase.LoadAssetAtPath<NetworkPrefabsList>(AssetDatabase.GUIDToAssetPath(guids[0]));

        var list = ScriptableObject.CreateInstance<NetworkPrefabsList>();
        AssetDatabase.CreateAsset(list, "Assets/Resources/NetworkPrefabs.asset");
        return list;
    }

    private static List<NetworkObject> FindAllNetworkPrefabs()
    {
        var result = new List<NetworkObject>();
        foreach (string guid in AssetDatabase.FindAssets("t:Prefab"))
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(guid));
            var netObj = prefab?.GetComponent<NetworkObject>();
            if (netObj != null) result.Add(netObj);
        }
        return result;
    }

    private static bool IsPrefabInList(SerializedProperty listProp, NetworkObject prefab)
    {
        for (int i = 0; i < listProp.arraySize; i++)
        {
            var element = listProp.GetArrayElementAtIndex(i);
            var prop = element.FindPropertyRelative("m_Prefab") ?? element.FindPropertyRelative("Prefab");
            if (prop?.objectReferenceValue == prefab.gameObject) return true;
        }
        return false;
    }

    private static NetworkObject FindPrefabWithComponent<T>() where T : Component
    {
        foreach (string guid in AssetDatabase.FindAssets("t:Prefab"))
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(guid));
            if (prefab?.GetComponent<T>() != null)
                return prefab.GetComponent<NetworkObject>();
        }
        return null;
    }

    private static NetworkObject FindPrefabByName(string name)
    {
        foreach (string guid in AssetDatabase.FindAssets($"t:Prefab {name}"))
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(guid));
            if (prefab?.name.Contains(name) == true)
                return prefab.GetComponent<NetworkObject>();
        }
        return null;
    }

    private static void AddSceneIfExists(List<string> scenes, string sceneName)
    {
        string path = $"Assets/Scenes/{sceneName}.unity";
        if (File.Exists(path)) scenes.Add(path);
    }

    private static void CreateServerRunScript()
    {
        string script = @"#!/bin/bash
PORT=${1:-7777}
echo ""Starting server on port $PORT...""
./GameServer -port $PORT -logFile server.log
";
        File.WriteAllText("Build/Server/run.sh", script);
        Debug.Log("Created Build/Server/run.sh");
    }

    // ============================================
    //   EDITOR TESTING
    // ============================================

    [MenuItem("Tools/Test/Run Server Scene", priority = 100)]
    public static void TestServer()
    {
        if (!EditorApplication.isPlaying)
            EditorSceneManager.OpenScene($"Assets/Scenes/{SceneNames.Server}.unity");
        EditorApplication.isPlaying = true;
    }

    [MenuItem("Tools/Test/Run Client Scene", priority = 101)]
    public static void TestClient()
    {
        if (!EditorApplication.isPlaying)
            EditorSceneManager.OpenScene($"Assets/Scenes/{SceneNames.Menu}.unity");
        EditorApplication.isPlaying = true;
    }
}
