using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Check for duplicate NetworkManagerRoot in Server scene
/// </summary>
public class CheckServerDuplicates : Editor
{
    [MenuItem("Tools/Check Server Scene for Duplicates")]
    public static void CheckServer()
    {
        string serverScenePath = "Assets/Scenes/Server.unity";
        
        // Save current scene
        Scene currentScene = SceneManager.GetActiveScene();
        bool wasCurrentScene = currentScene.path == serverScenePath;
        
        if (!wasCurrentScene)
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
        }
        
        // Open Server scene
        Scene serverScene = EditorSceneManager.OpenScene(serverScenePath, OpenSceneMode.Single);
        
        // Find all NetworkManagerRoot GameObjects
        int count = 0;
        foreach (GameObject go in serverScene.GetRootGameObjects())
        {
            if (go.name.Contains("NetworkManagerRoot") || go.name.Contains("NETWORK_MANAGER_ROOT"))
            {
                count++;
                Debug.Log($"[CheckServerDuplicates] Found: {go.name} (InstanceID: {go.GetInstanceID()})");
                
                // List all components
                Component[] components = go.GetComponents<Component>();
                foreach (Component comp in components)
                {
                    Debug.Log($"  - {comp.GetType().Name}");
                }
            }
        }
        
        if (count == 0)
        {
            Debug.LogWarning("[CheckServerDuplicates] ❌ No NetworkManagerRoot found in Server scene!");
        }
        else if (count == 1)
        {
            Debug.Log($"[CheckServerDuplicates] ✅ Exactly 1 NetworkManagerRoot found (correct)");
        }
        else
        {
            Debug.LogError($"[CheckServerDuplicates] ❌ Found {count} NetworkManagerRoot instances (should be 1)!");
        }
        
        // Check for duplicate ServerBootstrap
        ServerBootstrap[] bootstraps = FindObjectsOfType<ServerBootstrap>();
        Debug.Log($"[CheckServerDuplicates] ServerBootstrap instances: {bootstraps.Length}");
        foreach (ServerBootstrap bootstrap in bootstraps)
        {
            Debug.Log($"  - {bootstrap.gameObject.name} (Scene: {bootstrap.gameObject.scene.name})");
        }
        
        // Restore original scene if needed
        if (!wasCurrentScene && !string.IsNullOrEmpty(currentScene.path))
        {
            EditorSceneManager.OpenScene(currentScene.path, OpenSceneMode.Single);
        }
        
        Debug.Log("[CheckServerDuplicates] === DONE ===");
    }
}
