using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using System.IO;

/// <summary>
/// Build both Server and Client to ensure they have matching NetworkConfig.
/// Menu: Tools > Build > Build All
/// </summary>
public static class BuildAll
{
    private static readonly string BuildFolder = "Builds";

    [MenuItem("Tools/Build/Build All (Server + Client)", priority = 100)]
    public static void BuildServerAndClient()
    {
        BuildServer();
        BuildClient();
        
        Debug.Log("===========================================");
        Debug.Log("  BUILD COMPLETE");
        Debug.Log("===========================================");
        Debug.Log($"Server: {BuildFolder}/Server/");
        Debug.Log($"Client: {BuildFolder}/Client/");
        Debug.Log("===========================================");
        
        EditorUtility.DisplayDialog("Build Complete", 
            $"Server and Client built successfully!\n\n" +
            $"Server: {BuildFolder}/Server/\n" +
            $"Client: {BuildFolder}/Client/", "OK");
    }

    [MenuItem("Tools/Build/Build Server Only", priority = 101)]
    public static void BuildServer()
    {
        string path = $"{BuildFolder}/Server";
        Directory.CreateDirectory(path);

        var options = new BuildPlayerOptions
        {
            scenes = GetScenes(),
            locationPathName = $"{path}/Server.exe",
            target = BuildTarget.StandaloneWindows64,
            subtarget = (int)StandaloneBuildSubtarget.Server,
            options = BuildOptions.None
        };

        Debug.Log("Building Server...");
        var report = BuildPipeline.BuildPlayer(options);
        
        if (report.summary.result == BuildResult.Succeeded)
        {
            Debug.Log($"✅ Server build succeeded: {report.summary.totalSize / 1024 / 1024} MB");
        }
        else
        {
            Debug.LogError($"❌ Server build failed: {report.summary.result}");
        }
    }

    [MenuItem("Tools/Build/Build Client Only", priority = 102)]
    public static void BuildClient()
    {
        string path = $"{BuildFolder}/Client";
        Directory.CreateDirectory(path);

        var options = new BuildPlayerOptions
        {
            scenes = GetScenes(),
            locationPathName = $"{path}/Client.exe",
            target = BuildTarget.StandaloneWindows64,
            subtarget = (int)StandaloneBuildSubtarget.Player,
            options = BuildOptions.None
        };

        Debug.Log("Building Client...");
        var report = BuildPipeline.BuildPlayer(options);
        
        if (report.summary.result == BuildResult.Succeeded)
        {
            Debug.Log($"✅ Client build succeeded: {report.summary.totalSize / 1024 / 1024} MB");
        }
        else
        {
            Debug.LogError($"❌ Client build failed: {report.summary.result}");
        }
    }

    [MenuItem("Tools/Build/Build Linux Server", priority = 110)]
    public static void BuildLinuxServer()
    {
        string path = $"{BuildFolder}/LinuxServer";
        Directory.CreateDirectory(path);

        var options = new BuildPlayerOptions
        {
            scenes = GetScenes(),
            locationPathName = $"{path}/Server.x86_64",
            target = BuildTarget.StandaloneLinux64,
            subtarget = (int)StandaloneBuildSubtarget.Server,
            options = BuildOptions.None
        };

        Debug.Log("Building Linux Server...");
        var report = BuildPipeline.BuildPlayer(options);
        
        if (report.summary.result == BuildResult.Succeeded)
        {
            Debug.Log($"✅ Linux Server build succeeded: {report.summary.totalSize / 1024 / 1024} MB");
        }
        else
        {
            Debug.LogError($"❌ Linux Server build failed: {report.summary.result}");
        }
    }

    [MenuItem("Tools/Build/Open Build Folder", priority = 200)]
    public static void OpenBuildFolder()
    {
        string fullPath = Path.GetFullPath(BuildFolder);
        Directory.CreateDirectory(fullPath);
        EditorUtility.RevealInFinder(fullPath);
    }

    private static string[] GetScenes()
    {
        return new string[]
        {
            "Assets/Scenes/Server.unity",
            "Assets/Scenes/Menu.unity",
            "Assets/Scenes/Client.unity",
            "Assets/Scenes/Game.unity"
        };
    }
}
