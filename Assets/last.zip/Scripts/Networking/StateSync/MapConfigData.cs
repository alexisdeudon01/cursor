using System;
using UnityEngine;

namespace Networking.StateSync
{
    [Serializable]
    public sealed class MapConfigData
    {
        public string mapName;
        public Vector3 mapSize;
        public Vector3 worldOffset;
    }
}
