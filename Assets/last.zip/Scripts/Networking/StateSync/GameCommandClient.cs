using System;
using Unity.Netcode.Components;
using Unity.Netcode;
using UnityEngine;

namespace Networking.StateSync
{
    public sealed class GameCommandClient : MonoBehaviour
    {
        public static GameCommandClient Instance { get; private set; }

        public string CurrentSessionUid { get; private set; }
        public MapConfigData CurrentConfig { get; private set; }
        public int LastAppliedVersion { get; private set; }

        public event Action<MapConfigData> OnMapConfigApplied;

        private float lastResyncRequestTime;
        private const float ResyncCooldownSeconds = 1f;

        public static GameCommandClient EnsureInstance()
        {
            if (Instance != null)
            {
                return Instance;
            }

            var go = new GameObject("GameCommandClient");
            return go.AddComponent<GameCommandClient>();
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        public void ApplyCommand(GameCommandDto command)
        {
            switch (command.Type)
            {
                case GameCommandType.MapConfig:
                    ApplyMapConfig(command);
                    break;
                case GameCommandType.SpawnEntity:
                    if (ShouldApplySnapshot(command.Version))
                    {
                        ApplyEntityUpdate(command);
                    }
                    break;
                case GameCommandType.UpdateEntity:
                    if (ShouldApplyUpdate(command.Version))
                    {
                        ApplyEntityUpdate(command);
                    }
                    break;
                case GameCommandType.RemoveEntity:
                    if (ShouldApplyUpdate(command.Version))
                    {
                        ApplyEntityRemoval(command);
                    }
                    break;
            }
        }

        public void RequestResyncNow()
        {
            RequestResync();
        }

        private void ApplyMapConfig(GameCommandDto command)
        {
            CurrentSessionUid = command.SessionUid.ToString();
            CurrentConfig = new MapConfigData
            {
                mapName = command.MapName.ToString(),
                mapSize = command.MapSize,
                worldOffset = command.WorldOffset
            };
            LastAppliedVersion = 0;

            OnMapConfigApplied?.Invoke(CurrentConfig);
        }

        private bool ShouldApplySnapshot(int version)
        {
            if (version <= 0)
            {
                return true;
            }

            if (LastAppliedVersion > version)
            {
                return false;
            }

            LastAppliedVersion = version;
            return true;
        }

        private bool ShouldApplyUpdate(int version)
        {
            if (version <= 0)
            {
                return true;
            }

            if (LastAppliedVersion == 0 && version > 1)
            {
                RequestResync();
                return false;
            }

            if (LastAppliedVersion > 0 && version > LastAppliedVersion + 1)
            {
                RequestResync();
                return false;
            }

            if (version < LastAppliedVersion)
            {
                return false;
            }

            if (version > LastAppliedVersion)
            {
                LastAppliedVersion = version;
            }

            return true;
        }

        private void RequestResync()
        {
            if (Time.time - lastResyncRequestTime < ResyncCooldownSeconds)
            {
                return;
            }

            if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsClient)
            {
                return;
            }

            if (SessionRpcHub.Instance == null)
            {
                return;
            }

            lastResyncRequestTime = Time.time;
            var command = GameCommandFactory.CreateResyncRequest(CurrentSessionUid, LastAppliedVersion);
            SessionRpcHub.Instance.SendGameCommandServerRpc(command);
        }

        private void ApplyEntityUpdate(GameCommandDto command)
        {
            if (!TryGetNetworkObject(command.EntityId.ToString(), out var netObj))
            {
                return;
            }

            // If a NetworkTransform is present, it already synchronizes server->client transforms.
            // Avoid fighting with its interpolation by applying state-sync transform updates.
            if (netObj.TryGetComponent<NetworkTransform>(out _))
            {
                return;
            }

            netObj.transform.position = command.Position;
            netObj.transform.rotation = command.Rotation;
        }

        private void ApplyEntityRemoval(GameCommandDto command)
        {
            if (!TryGetNetworkObject(command.EntityId.ToString(), out var netObj))
            {
                return;
            }

            if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsServer)
            {
                if (netObj.IsSpawned)
                {
                    netObj.Despawn();
                }
                return;
            }

            netObj.gameObject.SetActive(false);
        }

        private bool TryGetNetworkObject(string entityId, out NetworkObject netObj)
        {
            netObj = null;
            if (NetworkManager.Singleton == null || NetworkManager.Singleton.SpawnManager == null)
            {
                return false;
            }

            if (!ulong.TryParse(entityId, out var netId))
            {
                return false;
            }

            return NetworkManager.Singleton.SpawnManager.SpawnedObjects.TryGetValue(netId, out netObj);
        }
    }
}
