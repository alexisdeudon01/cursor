using UnityEngine;

namespace Networking.StateSync
{
    public sealed class MapConfigSceneBuilder : MonoBehaviour
    {
        public static MapConfigSceneBuilder Instance { get; private set; }

        [Header("Map Visuals")]
        [SerializeField] private Color backgroundColor = new Color(0.15f, 0.15f, 0.2f);
        [SerializeField] private Color borderColor = new Color(0.3f, 0.3f, 0.4f);
        [SerializeField] private float borderWidth = 0.5f;

        [Header("Camera")]
        [SerializeField] private float cameraHeight = 15f;
        [SerializeField] private bool configureCameraIfMissing = true;

        private GameObject sceneRoot;

        public static MapConfigSceneBuilder EnsureInstance()
        {
            if (Instance != null)
            {
                return Instance;
            }

            var go = new GameObject("MapConfigSceneBuilder");
            return go.AddComponent<MapConfigSceneBuilder>();
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private void OnEnable()
        {
            GameCommandClient.EnsureInstance();
            if (GameCommandClient.Instance != null)
            {
                GameCommandClient.Instance.OnMapConfigApplied += HandleMapConfigApplied;
                if (GameCommandClient.Instance.CurrentConfig != null)
                {
                    HandleMapConfigApplied(GameCommandClient.Instance.CurrentConfig);
                }
            }
        }

        private void OnDisable()
        {
            if (GameCommandClient.Instance != null)
            {
                GameCommandClient.Instance.OnMapConfigApplied -= HandleMapConfigApplied;
            }
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        private void HandleMapConfigApplied(MapConfigData config)
        {
            if (config == null)
            {
                return;
            }

            BuildScene(config);
        }

        private void BuildScene(MapConfigData config)
        {
            if (sceneRoot != null)
            {
                Destroy(sceneRoot);
            }

            sceneRoot = new GameObject("MapConfigSceneRoot");
            sceneRoot.transform.position = config.worldOffset;

            var mapSize = ResolveMapSize(config.mapSize);
            SetupCamera(config.worldOffset, mapSize);
            CreateBackground(mapSize);
            CreateBorders(mapSize);
        }

        private void SetupCamera(Vector3 worldOffset, Vector2 mapSize)
        {
            if (!configureCameraIfMissing)
            {
                return;
            }

            var mainCam = Camera.main;
            if (mainCam != null)
            {
                return;
            }

            var camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            mainCam = camGO.AddComponent<Camera>();
            if (Object.FindFirstObjectByType<AudioListener>() == null)
            {
                camGO.AddComponent<AudioListener>();
            }

            mainCam.transform.position = new Vector3(worldOffset.x, cameraHeight, worldOffset.z);
            mainCam.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            mainCam.orthographic = true;
            mainCam.orthographicSize = Mathf.Max(1f, mapSize.y / 2f);
            mainCam.backgroundColor = backgroundColor;
            mainCam.clearFlags = CameraClearFlags.SolidColor;

            if (mainCam.GetComponent<CameraFollowPawn>() == null)
            {
                mainCam.gameObject.AddComponent<CameraFollowPawn>();
            }
        }

        private void CreateBackground(Vector2 mapSize)
        {
            var bgGO = new GameObject("Background");
            bgGO.transform.SetParent(sceneRoot.transform, false);
            bgGO.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            bgGO.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);

            var meshFilter = bgGO.AddComponent<MeshFilter>();
            var meshRenderer = bgGO.AddComponent<MeshRenderer>();

            meshFilter.mesh = CreateQuadMesh(mapSize.x, mapSize.y);

            var mat = new Material(Shader.Find("Sprites/Default"));
            mat.color = backgroundColor;
            meshRenderer.material = mat;
        }

        private void CreateBorders(Vector2 mapSize)
        {
            float halfW = mapSize.x / 2f;
            float halfH = mapSize.y / 2f;

            CreateBorder("BorderTop", new Vector3(0f, 0f, halfH + borderWidth / 2f), new Vector2(mapSize.x + borderWidth * 2f, borderWidth));
            CreateBorder("BorderBottom", new Vector3(0f, 0f, -halfH - borderWidth / 2f), new Vector2(mapSize.x + borderWidth * 2f, borderWidth));
            CreateBorder("BorderLeft", new Vector3(-halfW - borderWidth / 2f, 0f, 0f), new Vector2(borderWidth, mapSize.y));
            CreateBorder("BorderRight", new Vector3(halfW + borderWidth / 2f, 0f, 0f), new Vector2(borderWidth, mapSize.y));
        }

        private void CreateBorder(string name, Vector3 position, Vector2 size)
        {
            var borderGO = new GameObject(name);
            borderGO.transform.SetParent(sceneRoot.transform, false);
            borderGO.transform.localPosition = position;
            borderGO.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);

            var meshFilter = borderGO.AddComponent<MeshFilter>();
            var meshRenderer = borderGO.AddComponent<MeshRenderer>();

            meshFilter.mesh = CreateQuadMesh(size.x, size.y);

            var mat = new Material(Shader.Find("Sprites/Default"));
            mat.color = borderColor;
            meshRenderer.material = mat;
        }

        private Vector2 ResolveMapSize(Vector3 rawSize)
        {
            float width = Mathf.Abs(rawSize.x);
            float height = Mathf.Abs(rawSize.z);

            if (Mathf.Approximately(height, 0f))
            {
                height = Mathf.Abs(rawSize.y);
            }

            if (Mathf.Approximately(width, 0f))
            {
                width = 20f;
            }

            if (Mathf.Approximately(height, 0f))
            {
                height = 15f;
            }

            return new Vector2(width, height);
        }

        private Mesh CreateQuadMesh(float width, float height)
        {
            var mesh = new Mesh();
            float halfW = width / 2f;
            float halfH = height / 2f;

            mesh.vertices = new[]
            {
                new Vector3(-halfW, -halfH, 0f),
                new Vector3(halfW, -halfH, 0f),
                new Vector3(halfW, halfH, 0f),
                new Vector3(-halfW, halfH, 0f)
            };

            mesh.triangles = new[] { 0, 2, 1, 0, 3, 2 };
            mesh.normals = new[] { Vector3.back, Vector3.back, Vector3.back, Vector3.back };
            mesh.uv = new[] { Vector2.zero, Vector2.right, Vector2.one, Vector2.up };

            return mesh;
        }
    }
}
