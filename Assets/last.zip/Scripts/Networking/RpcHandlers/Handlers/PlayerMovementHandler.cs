using System.Collections.Generic;
using Core.Utilities;
using Unity.Netcode;
using Unity.Netcode.Components;
using UnityEngine;
using Networking.StateSync;

namespace Networking.RpcHandlers
{
    /// <summary>
    /// Handles player movement requests with rate limiting and validation.
    /// Extracted from SessionRpcHub to reduce complexity.
    /// </summary>
    public class PlayerMovementHandler : BaseRpcHandler, ICommandHandler
    {
        // Simple server-side throttle for movement RPCs
        private readonly Dictionary<ulong, float> lastMoveTimes = new Dictionary<ulong, float>();
        private const float MOVE_RPC_COOLDOWN = 0.05f; // 20 req/s max

        public override string GetHandlerName() => "PlayerMovementHandler";

        protected override void OnCleanup()
        {
            lastMoveTimes.Clear();
        }

        // ============================================================
        // REQUEST MOVE
        // ============================================================

        public void HandleRequestMove(string sessionName, Vector2 direction, ulong clientId)
        {
            if (!CheckInitialized())
                return;

            NetworkLogger.LogRpc("RequestMove", clientId, $"session='{sessionName}', dir={direction}");

            // Simple server-side move rate limit
            float now = Time.time;
            if (lastMoveTimes.TryGetValue(clientId, out var last) && now - last < MOVE_RPC_COOLDOWN)
            {
                return;
            }
            lastMoveTimes[clientId] = now;

            // Clamp input magnitude to avoid speed hacks
            if (direction.sqrMagnitude > 1f)
                direction = direction.normalized;

            // Validate session access using new validator
            var validation = SessionValidator.ValidatePlayerAction(sessionName, clientId, "Move");
            if (!validation.IsValid)
            {
                return; // Validation already logged error
            }

            var session = validation.Session;

            // Execute command via GameContainer
            try
            {
	            if (session.Game != null)
	            {
	                // Create and execute move command on server
	                var moveCommand = new MovePlayerCommand(session.Game, clientId, direction, 5f);
	                session.Game.ExecutePlayerCommand(moveCommand);
	                NetworkLogger.DebugLog("PlayerMovement", $"Command executed for client {clientId}");

	                var pawn = session.GetPawn(clientId);
	                if (pawn != null)
	                {
	                    var newPos = pawn.transform.position;
	                    var sessionManager = GameSessionManager.Instance;
	                    if (sessionManager != null && !sessionManager.ValidateMovement(clientId, sessionName, newPos))
	                    {
	                        LogWarning($"Movement rejected (out of bounds) for client {clientId} in session '{sessionName}'");
	                        return;
	                    }

	                    NetworkLogger.DebugLog(
	                        "PlayerMovement",
	                        $"Server pos client={clientId} pawn={pawn.NetworkObjectId} pos={newPos}"
	                    );

	                    var targets = session.GetPlayerIds();
	                    TrySendStateDiff(
	                        sessionName,
	                        pawn.NetworkObjectId,
	                        newPos,
	                        targets,
	                        sendClientCommands: ShouldSendTransformUpdates(pawn)
	                    );
	                }
	            }
	            else
	            {
	                // Fallback to old system if GameContainer not available
	                HandleMovementFallback(sessionName, clientId, direction);
	            }
            }
            catch (System.Exception ex)
            {
                LogError($"HandleRequestMove failed for client {clientId}: {ex.Message}");
            }
        }

        // ============================================================
        // COMMAND PATTERN SUPPORT
        // ============================================================

        public bool ExecuteCommand(IPlayerCommand command)
        {
            if (command == null)
            {
                LogWarning("Null command received");
                return false;
            }

            try
            {
                command.Execute();
                Log($"Command executed: {command.GetType().Name} for client {command.ClientId}");
                return true;
            }
            catch (System.Exception ex)
            {
                LogError($"Command execution failed: {ex.Message}");
                return false;
            }
        }

        public bool CanHandleCommand(System.Type commandType)
        {
            return commandType == typeof(MovePlayerCommand) ||
                   commandType == typeof(PlayerActionCommand);
        }

        // ============================================================
        // PRIVATE METHODS
        // ============================================================

        private void HandleMovementFallback(string sessionName, ulong clientId, Vector2 direction)
        {
            if (GameInstanceManager.Instance == null)
            {
                LogWarning("GameInstanceManager is null!");
                return;
            }

            if (!GameInstanceManager.Instance.HasActiveGame(sessionName))
            {
                LogWarning($"No active game for session '{sessionName}'");
                return;
            }

	            if (GameInstanceManager.Instance.HandleMovement(sessionName, clientId, direction, out var pawnId, out var newPos))
	            {
	                Log($"Movement handled: pawn={pawnId}, newPos={newPos}");

                // Validate movement bounds
                var sessionManager = GameSessionManager.Instance;
                if (sessionManager != null && !sessionManager.ValidateMovement(clientId, sessionName, newPos))
                {
                    LogWarning($"Movement rejected (out of bounds) for client {clientId} in session '{sessionName}'");
                    return;
                }

                NetworkLogger.DebugLog(
                    "PlayerMovement",
                    $"Server pos client={clientId} pawn={pawnId} pos={newPos}"
                );

	                var targets = GameInstanceManager.Instance.GetPlayerIds(sessionName);
	                TrySendStateDiff(
	                    sessionName,
	                    pawnId,
	                    newPos,
	                    targets,
	                    sendClientCommands: ShouldSendTransformUpdates(pawnId)
	                );
	            }
            else
            {
                LogWarning($"HandleMovement returned false for client {clientId}");
            }
        }

        public void HandleCommand(GameCommandDto command, ulong clientId)
        {
            switch (command.Type)
            {
                case GameCommandType.MoveInput:
                {
                    var sessionName = ResolveSessionName(command.SessionUid.ToString());
                    if (string.IsNullOrEmpty(sessionName))
                    {
                        return;
                    }

                    HandleRequestMove(sessionName, command.Direction, clientId);
                    break;
                }
                case GameCommandType.ResyncRequest:
                {
                    HandleResyncRequest(command, clientId);
                    break;
                }
            }
        }

	        private void TrySendStateDiff(
	            string sessionName,
	            ulong pawnId,
	            Vector3 newPos,
	            IReadOnlyList<ulong> targets,
	            bool sendClientCommands = true)
	        {
	            var registryHub = GlobalRegistryHub.Instance;
	            if (registryHub == null)
	            {
                return;
            }

            var sessionEntry = registryHub.SessionRegistry.GetByName(sessionName);
            if (sessionEntry == null)
            {
                return;
            }

            var instanceEntry = registryHub.GameInstanceRegister.GetBySessionUid(sessionEntry.SessionUid);
            if (instanceEntry == null || instanceEntry.runtimeState == null)
            {
                return;
            }

	            var diff = instanceEntry.runtimeState.ApplyMove(pawnId.ToString(), newPos);
	            if (diff == null)
	            {
	                return;
	            }

	            if (!sendClientCommands)
	            {
	                return;
	            }

	            var commands = instanceEntry.runtimeState.BuildUpdateCommands(sessionEntry.SessionUid, diff);
	            var clientParams = BuildClientRpcParams(new List<ulong>(targets));
	            for (int i = 0; i < commands.Count; i++)
	            {
	                Hub.SendGameCommandClientRpc(commands[i], clientParams);
	            }
	        }

	        private static bool ShouldSendTransformUpdates(NetworkObject netObj)
	        {
	            if (netObj == null)
	            {
	                return true;
	            }

	            if (!netObj.TryGetComponent<NetworkTransform>(out var networkTransform))
	            {
	                return true;
	            }

	            // Server-authoritative NetworkTransform already synchronizes transforms.
	            return networkTransform.AuthorityMode != NetworkTransform.AuthorityModes.Server;
	        }

	        private static bool ShouldSendTransformUpdates(ulong networkObjectId)
	        {
	            if (NetworkManager.Singleton == null || NetworkManager.Singleton.SpawnManager == null)
	            {
	                return true;
	            }

	            if (!NetworkManager.Singleton.SpawnManager.SpawnedObjects.TryGetValue(networkObjectId, out var netObj) || netObj == null)
	            {
	                return true;
	            }

	            return ShouldSendTransformUpdates(netObj);
	        }

        private string ResolveSessionName(string sessionKey)
        {
            if (string.IsNullOrEmpty(sessionKey))
            {
                return null;
            }

            var registryHub = GlobalRegistryHub.Instance;
            if (registryHub == null)
            {
                return sessionKey;
            }

            var entry = registryHub.SessionRegistry.GetByUid(sessionKey);
            if (entry != null)
            {
                return entry.Name;
            }

            return sessionKey;
        }

        private void HandleResyncRequest(GameCommandDto command, ulong clientId)
        {
            var sessionName = ResolveSessionName(command.SessionUid.ToString());
            if (string.IsNullOrEmpty(sessionName))
            {
                sessionName = GameSessionManager.Instance != null
                    ? GameSessionManager.Instance.GetClientSession(clientId)
                    : null;
            }

            if (string.IsNullOrEmpty(sessionName))
            {
                return;
            }

            SendFullStateSnapshot(sessionName, clientId);
        }

        private void SendFullStateSnapshot(string sessionName, ulong clientId)
        {
            var registryHub = GlobalRegistryHub.Instance;
            if (registryHub == null)
            {
                return;
            }

            registryHub.GameRegisterTemplate.EnsureLoadedFromGameRegistry();
            var sessionEntry = registryHub.SessionRegistry.GetByName(sessionName);
            if (sessionEntry == null)
            {
                return;
            }

            var instanceEntry = registryHub.GameInstanceRegister.GetBySessionUid(sessionEntry.SessionUid);
            if (instanceEntry == null || instanceEntry.runtimeState == null)
            {
                return;
            }

            var worldOffset = Vector3.zero;
            if (GameInstanceManager.Instance != null)
            {
                GameInstanceManager.Instance.TryGetWorldOffset(sessionName, out worldOffset);
            }

            var representation = registryHub.GameRegisterTemplate.GetByGameTypeUid(sessionEntry.GameTypeUid);
            if (representation == null && GameInstanceManager.Instance != null)
            {
                var gameId = GameInstanceManager.Instance.GetGameId(sessionName);
                representation = registryHub.GameRegisterTemplate.GetByGameId(gameId);
            }

            var clientParams = BuildClientRpcParams(clientId);
            if (representation != null)
            {
                var configCommand = representation.BuildConfigCommand(sessionEntry.SessionUid, worldOffset);
                Hub.SendGameCommandClientRpc(configCommand, clientParams);
            }

            var spawnCommands = instanceEntry.runtimeState.BuildSpawnCommands(sessionEntry.SessionUid);
            for (int i = 0; i < spawnCommands.Count; i++)
            {
                Hub.SendGameCommandClientRpc(spawnCommands[i], clientParams);
            }
        }
    }
}
