using Networking.StateSync;
using UnityEngine;

/// <summary>
/// Square Game (data-oriented, Option 1).
/// 
/// - Server runs an authoritative simulation in a rectangular arena.
/// - Player pawns are NOT NetworkObjects.
/// - Client renders a square pawn view for each entity.
/// </summary>
[CreateAssetMenu(fileName = "SquareGame", menuName = "Games/Square Game")]
public class SquareGameDefinition : GameDefinitionAsset
{
    [Header("Map Settings")]
    [SerializeField] private Vector2 mapSize = new Vector2(20f, 15f);

    // Provide defaults even if asset isn't configured.
    public override string GameId => string.IsNullOrEmpty(gameId) ? "square-game" : gameId;
    public override string DisplayName => string.IsNullOrEmpty(displayName) ? "Square Game" : displayName;

    public override MapConfigData CreateMapConfig(Vector3 worldOffset, int seed)
    {
        return new MapConfigData
        {
            mapName = GameId,
            shape = MapShape.Rect,
            mapSize = new Vector3(mapSize.x, 0f, mapSize.y),
            circleRadius = 0f,
            seed = seed,
            worldOffset = worldOffset
        };
    }

    public override Vector3 GetSpawnPosition(int playerIndex, int totalPlayers, MapConfigData config)
    {
        var offset = config != null ? config.worldOffset : Vector3.zero;
        var size = config != null ? config.mapSize : new Vector3(mapSize.x, 0f, mapSize.y);

        float width = Mathf.Abs(size.x);
        float height = Mathf.Abs(size.z);
        if (Mathf.Approximately(height, 0f))
            height = Mathf.Abs(size.y);

        if (Mathf.Approximately(width, 0f))
            width = mapSize.x;
        if (Mathf.Approximately(height, 0f))
            height = mapSize.y;

        float halfW = (width / 2f) - 1f;
        float halfH = (height / 2f) - 1f;

        if (totalPlayers <= 4)
        {
            switch (playerIndex % 4)
            {
                case 0: return offset + new Vector3(-halfW, 0f, -halfH);
                case 1: return offset + new Vector3(halfW, 0f, -halfH);
                case 2: return offset + new Vector3(-halfW, 0f, halfH);
                default: return offset + new Vector3(halfW, 0f, halfH);
            }
        }

        float safeTotal = Mathf.Max(1, totalPlayers);
        float angle = (playerIndex / safeTotal) * Mathf.PI * 2f;
        float radius = Mathf.Min(halfW, halfH) * 0.7f;
        return offset + new Vector3(Mathf.Cos(angle) * radius, 0f, Mathf.Sin(angle) * radius);
    }

    public override void SetupClientVisuals(MapConfigData config)
    {
        // Map visuals are built by MapConfigSceneBuilder via the replicated MapConfig command.
        // Extra per-mode visuals could be added here.
    }

    public override void CleanupGame()
    {
        // Nothing to clean up for this mode (map & pawn views are managed by their own systems).
    }
}
