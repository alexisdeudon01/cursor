using Unity.Netcode;
using UnityEngine;
using Networking.StateSync;
using Unity.Collections;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Handles player input and sends movement requests to the server.
/// Client-only component, created automatically when a game starts.
/// </summary>
public class PlayerInputHandler : MonoBehaviour
{
    public static PlayerInputHandler Instance { get; private set; }

    private string _sessionName;

    [Header("Networking")]
    [SerializeField, Min(1f)] private float sendRateHz = 20f;
    [SerializeField] private float changeThresholdSqr = 0.0001f;

    private Vector2 _lastSentDir = Vector2.zero;
    private float _nextSendTime = 0f;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    /// <summary>
    /// Set the session name for this player's input.
    /// </summary>
    public void SetSession(string sessionName)
    {
        _sessionName = sessionName;
        Debug.Log($"[PlayerInputHandler] Session set: {sessionName}");
    }

    /// <summary>
    /// Ensure the input handler exists.
    /// </summary>
    public static void EnsureInstance()
    {
        if (Instance == null)
        {
            var go = new GameObject("PlayerInputHandler");
            go.AddComponent<PlayerInputHandler>();
        }
    }

    private float _lastLogTime = 0f;

private void Update()
{
    // Client-only
    if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsClient)
        return;

    if (string.IsNullOrEmpty(_sessionName))
    {
        // Log once per second if session not set
        if (Time.time - _lastLogTime > 2f)
        {
            Debug.LogWarning("[PlayerInputHandler] No session set - waiting for game start");
            _lastLogTime = Time.time;
        }
        return;
    }

    if (SessionRpcHub.Instance == null)
        return;

    var dir = ReadInput(); // normalized (or zero)
    float now = Time.unscaledTime;

    bool changed = (dir - _lastSentDir).sqrMagnitude > changeThresholdSqr;
    bool heartbeat = dir.sqrMagnitude > 0f && now >= _nextSendTime;

    // IMPORTANT: we must send "stop" (Vector2.zero) when input is released, otherwise
    // the server-authoritative sim will keep the last direction forever.
    if (!changed && !heartbeat)
        return;

    FixedString64Bytes sessionUid = default;
    if (GameCommandClient.Instance != null && !GameCommandClient.Instance.CurrentSessionUid.IsEmpty)
    {
        sessionUid = GameCommandClient.Instance.CurrentSessionUid;
    }
    else
    {
        sessionUid = _sessionName;
    }

    var clientVersion = GameCommandClient.Instance != null ? GameCommandClient.Instance.LastAppliedVersion : 0;
    var command = GameCommandFactory.CreateMoveInput(sessionUid, dir, clientVersion);
    SessionRpcHub.Instance.SendGameCommandServerRpc(command);

    _lastSentDir = dir;
    _nextSendTime = now + (1f / Mathf.Max(1f, sendRateHz));
}

    private Vector2 ReadInput()
    {
#if ENABLE_INPUT_SYSTEM
        var kb = Keyboard.current;
        if (kb == null)
            return Vector2.zero;

        Vector2 dir = Vector2.zero;
        // Arrow keys
        if (kb.upArrowKey.isPressed) dir.y += 1;
        if (kb.downArrowKey.isPressed) dir.y -= 1;
        if (kb.leftArrowKey.isPressed) dir.x -= 1;
        if (kb.rightArrowKey.isPressed) dir.x += 1;
        // WASD or ZQSD controls
        if (kb.wKey.isPressed || kb.zKey.isPressed) dir.y += 1;  // Forward (Z+)
        if (kb.sKey.isPressed) dir.y -= 1;                        // Backward (Z-)
        if (kb.aKey.isPressed || kb.qKey.isPressed) dir.x -= 1;  // Left (X-)
        if (kb.dKey.isPressed || kb.eKey.isPressed) dir.x += 1;  // Right (X+)
        return dir.normalized;
#else
        Vector2 dir = Vector2.zero;
        // Arrow keys
        if (Input.GetKey(KeyCode.UpArrow)) dir.y += 1;
        if (Input.GetKey(KeyCode.DownArrow)) dir.y -= 1;
        if (Input.GetKey(KeyCode.LeftArrow)) dir.x -= 1;
        if (Input.GetKey(KeyCode.RightArrow)) dir.x += 1;
        // WASD
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.Z)) dir.y += 1;
        if (Input.GetKey(KeyCode.S)) dir.y -= 1;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.Q)) dir.x -= 1;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.E)) dir.x += 1;
        return dir.normalized;
#endif
    }
}
