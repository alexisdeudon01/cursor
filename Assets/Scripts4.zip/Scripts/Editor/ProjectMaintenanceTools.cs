using UnityEditor;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine;

/// <summary>
/// Quick utilities to flip input handling, close PlasticSCM windows, and optionally remove the collab-proxy package.
/// </summary>
public static class ProjectMaintenanceTools
{
    private static RemoveRequest removeCollabRequest;

    // Unity stores activeInputHandler as an int:
    // 0 = Input Manager (old), 1 = Input System, 2 = Both
    private const int InputManagerOnly = 0;
    private const int InputSystemOnly = 1;
    private const int BothInputSystems = 2;

    [MenuItem("Tools/Project/Input/Set Active Input Handling - Both", priority = 0)]
    public static void SetInputHandlingBoth()
    {
        SetInputHandling(BothInputSystems);
    }

    [MenuItem("Tools/Project/Input/Set Active Input Handling - Input System Only", priority = 1)]
    public static void SetInputHandlingInputSystem()
    {
        SetInputHandling(InputSystemOnly);
    }

    private static void SetInputHandling(int mode)
    {
        if (TrySetActiveInputHandlerProperty(mode))
        {
            Debug.Log($"Set Active Input Handling to {HumanReadable(mode)}.");
            return;
        }

        Debug.LogWarning($"Impossible de changer automatiquement l'Input Handling sur cette version de l'éditeur. " +
                         $"Ouvre Project Settings > Player > Active Input Handling et sélectionne \"{HumanReadable(mode)}\".");
    }

    private static bool TrySetActiveInputHandlerProperty(int mode)
    {
        try
        {
            var prop = typeof(PlayerSettings).GetProperty("activeInputHandler",
                System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
            if (prop != null && prop.CanWrite)
            {
                prop.SetValue(null, mode);
                return true;
            }
        }
        catch { /* ignore and fallback */ }
        return false;
    }

    private static string HumanReadable(int mode)
    {
        return mode switch
        {
            InputManagerOnly => "Input Manager (Old)",
            InputSystemOnly => "Input System Package (New)",
            BothInputSystems => "Both",
            _ => $"Unknown ({mode})"
        };
    }

    [MenuItem("Tools/Project/Windows/Close Unity Version Control Windows", priority = 20)]
    public static void ClosePlasticWindows()
    {
        int closed = 0;
        foreach (var win in Resources.FindObjectsOfTypeAll<EditorWindow>())
        {
            var type = win.GetType();
            if (type != null && type.FullName == "Unity.PlasticSCM.Editor.UVCSWindow")
            {
                win.Close();
                closed++;
            }
        }

        Debug.Log(closed == 0
            ? "No Unity Version Control windows were open."
            : $"Closed {closed} Unity Version Control window(s).");
    }

    [MenuItem("Tools/Project/Packages/Remove Collab Proxy (com.unity.collab-proxy)", priority = 40)]
    public static void RemoveCollabProxy()
    {
        if (removeCollabRequest != null && !removeCollabRequest.IsCompleted)
        {
            Debug.Log("Collab proxy removal already in progress...");
            return;
        }

        removeCollabRequest = Client.Remove("com.unity.collab-proxy");
        EditorApplication.update += TrackCollabRemoval;
        Debug.Log("Removing package com.unity.collab-proxy...");
    }

    private static void TrackCollabRemoval()
    {
        if (removeCollabRequest == null || !removeCollabRequest.IsCompleted)
            return;

        EditorApplication.update -= TrackCollabRemoval;

        if (removeCollabRequest.Status == StatusCode.Success)
            Debug.Log("Removed package com.unity.collab-proxy.");
        else
            Debug.LogError($"Failed to remove com.unity.collab-proxy: {removeCollabRequest.Error?.message}");

        removeCollabRequest = null;
    }
}
