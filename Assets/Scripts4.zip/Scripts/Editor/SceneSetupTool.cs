using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.UIElements;
using System.IO;

/// <summary>
/// Tool to automatically setup Server and Menu scenes with correct components.
/// Menu: Tools > Setup Scenes
/// </summary>
public class SceneSetupTool : EditorWindow
{
    [MenuItem("Tools/Setup Scenes/Setup All Scenes", priority = 0)]
    public static void SetupAllScenes()
    {
        SetupServerScene();
        SetupMenuScene();
        SetupClientScene();
        Debug.Log(" All scenes configured!");
        EditorUtility.DisplayDialog("Setup Complete",
            "Server, Menu and Client scenes have been configured.\n\n" +
            "Server: ServerBootstrap added\n" +
            "Menu: ClientBootstrap added\n" +
            "Client: SessionLobbyUI added", "OK");
    }

    [MenuItem("Tools/Setup Scenes/Setup Server Scene", priority = 1)]
    public static void SetupServerScene()
    {
        string scenePath = "Assets/Scenes/Server.unity";
        if (!File.Exists(scenePath))
        {
            Debug.LogError($"Scene not found: {scenePath}");
            return;
        }

        // Save current scene
        EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();

        // Open Server scene
        var scene = EditorSceneManager.OpenScene(scenePath);
        Debug.Log($"Opened: {scenePath}");

        // Remove PlayerManager if exists
        var playerManager = GameObject.Find("PlayerManager");
        if (playerManager != null)
        {
            Object.DestroyImmediate(playerManager);
            Debug.Log("  Removed: PlayerManager");
        }

        // Find or create ServerBootstrap
        var serverBootstrap = GameObject.Find("ServerBootstrap");
        if (serverBootstrap == null)
        {
            serverBootstrap = new GameObject("ServerBootstrap");
            Debug.Log("  Created: ServerBootstrap GameObject");
        }

        // Add ServerBootstrap component
        var bootstrapComponent = serverBootstrap.GetComponent<ServerBootstrap>();
        if (bootstrapComponent == null)
        {
            bootstrapComponent = serverBootstrap.AddComponent<ServerBootstrap>();
            Debug.Log("  Added: ServerBootstrap component");
        }

        // Try to find SessionRpcHub prefab and assign it
        var sessionHubPrefab = FindPrefab("SessionRpcHub");
        if (sessionHubPrefab != null)
        {
            var netObj = sessionHubPrefab.GetComponent<Unity.Netcode.NetworkObject>();
            if (netObj != null)
            {
                var so = new SerializedObject(bootstrapComponent);
                var prop = so.FindProperty("sessionRpcHubPrefab");
                if (prop != null)
                {
                    prop.objectReferenceValue = netObj;
                    so.ApplyModifiedProperties();
                    Debug.Log("  Assigned: SessionRpcHub prefab");
                }
            }
        }

        // Make sure NetworkManagerRoot prefab is in scene
        EnsureNetworkManagerRoot();

        // Save scene
        EditorSceneManager.SaveScene(scene);
        Debug.Log("✅ Server scene configured!");
    }

    [MenuItem("Tools/Setup Scenes/Setup Menu Scene", priority = 2)]
    public static void SetupMenuScene()
    {
        string scenePath = "Assets/Scenes/Menu.unity";
        if (!File.Exists(scenePath))
        {
            Debug.LogError($"Scene not found: {scenePath}");
            return;
        }

        // Save current scene
        EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();

        // Open Menu scene
        var scene = EditorSceneManager.OpenScene(scenePath);
        Debug.Log($"Opened: {scenePath}");

        // Find or create ClientBootstrap
        var clientBootstrap = GameObject.Find("ClientBootstrap");
        if (clientBootstrap == null)
        {
            clientBootstrap = new GameObject("ClientBootstrap");
            Debug.Log("  Created: ClientBootstrap GameObject");
        }

        // Add ClientBootstrap component
        var bootstrapComponent = clientBootstrap.GetComponent<ClientBootstrap>();
        if (bootstrapComponent == null)
        {
            bootstrapComponent = clientBootstrap.AddComponent<ClientBootstrap>();
            Debug.Log("  Added: ClientBootstrap component");
        }

        // Find or create MenuUI
        var menuUI = GameObject.Find("MenuUI");
        if (menuUI == null)
        {
            menuUI = new GameObject("MenuUI");
            Debug.Log("  Created: MenuUI GameObject");
        }

        // Add UIDocument
        var uiDoc = menuUI.GetComponent<UIDocument>();
        if (uiDoc == null)
        {
            uiDoc = menuUI.AddComponent<UIDocument>();
            Debug.Log("  Added: UIDocument component");
        }

        // Assign ConnectionUI.uxml
        string uxmlPath = "Assets/UI Toolkit/ConnectionUI.uxml";
        var uxmlAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(uxmlPath);
        if (uxmlAsset != null)
        {
            uiDoc.visualTreeAsset = uxmlAsset;
            Debug.Log("  Assigned: ConnectionUI.uxml");
        }
        else
        {
            Debug.LogWarning($"  UXML not found: {uxmlPath}");
        }

        // Find PanelSettings and assign
        var panelSettings = FindPanelSettings();
        if (panelSettings != null)
        {
            uiDoc.panelSettings = panelSettings;
            Debug.Log("  Assigned: PanelSettings");
        }

        // MenuButtons component removed - no longer needed

        // Make sure NetworkManagerRoot prefab is in scene
        EnsureNetworkManagerRoot();

        // Save scene
        EditorSceneManager.SaveScene(scene);
        Debug.Log("✅ Menu scene configured!");
    }

    [MenuItem("Tools/Setup Scenes/Setup Client Scene", priority = 3)]
    public static void SetupClientScene()
    {
        string scenePath = "Assets/Scenes/Client.unity";
        if (!File.Exists(scenePath))
        {
            Debug.LogError($"Scene not found: {scenePath}");
            return;
        }

        // Save current scene
        EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();

        // Open Client scene
        var scene = EditorSceneManager.OpenScene(scenePath);
        Debug.Log($"Opened: {scenePath}");

        // Find or create SessionLobbyUI GameObject
        var lobbyUI = GameObject.Find("SessionLobbyUI");
        if (lobbyUI == null)
        {
            lobbyUI = new GameObject("SessionLobbyUI");
            Debug.Log("  Created: SessionLobbyUI GameObject");
        }

        // Add UIDocument
        var uiDocument = lobbyUI.GetComponent<UIDocument>();
        if (uiDocument == null)
        {
            uiDocument = lobbyUI.AddComponent<UIDocument>();
            Debug.Log("  Added: UIDocument component");
        }

        // Find SessionLobby.uxml and assign
        var lobbyUxml = FindUxml("SessionLobby");
        if (lobbyUxml != null)
        {
            uiDocument.visualTreeAsset = lobbyUxml;
            Debug.Log($"  Assigned: {lobbyUxml.name}.uxml");
        }
        else
        {
            Debug.LogWarning("  ⚠️ SessionLobby.uxml not found!");
        }

        // Find and assign PanelSettings
        var panelSettings = FindPanelSettings();
        if (panelSettings != null)
        {
            uiDocument.panelSettings = panelSettings;
            Debug.Log($"  Assigned: {panelSettings.name} PanelSettings");
        }

        // Add SessionLobbyUI component
        var lobbyComponent = lobbyUI.GetComponent<SessionLobbyUI>();
        if (lobbyComponent == null)
        {
            lobbyComponent = lobbyUI.AddComponent<SessionLobbyUI>();
            Debug.Log("  Added: SessionLobbyUI component");
        }

        // Make sure NetworkManagerRoot prefab is in scene
        EnsureNetworkManagerRoot();

        // Save scene
        EditorSceneManager.SaveScene(scene);
        Debug.Log("✅ Client scene configured!");
    }

    private static VisualTreeAsset FindUxml(string name)
    {
        string[] guids = AssetDatabase.FindAssets($"t:VisualTreeAsset {name}");
        foreach (var guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var uxml = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(path);
            if (uxml != null && uxml.name == name)
                return uxml;
        }
        return null;
    }

    private static void EnsureNetworkManagerRoot()
    {
        // Check if NetworkManager already exists
        if (Unity.Netcode.NetworkManager.Singleton != null)
        {
            Debug.Log("  NetworkManager already exists");
            return;
        }

        // Find by name
        var existing = GameObject.Find("NetworkManagerRoot");
        if (existing != null)
        {
            Debug.Log("  NetworkManagerRoot already in scene");
            return;
        }

        // Try to instantiate prefab
        var prefab = FindPrefab("NetworkManagerRoot");
        if (prefab != null)
        {
            var instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (instance != null)
            {
                instance.name = "NetworkManagerRoot";
                Debug.Log("  Instantiated: NetworkManagerRoot prefab");
            }
        }
        else
        {
            Debug.LogWarning("  NetworkManagerRoot prefab not found!");
        }
    }

    private static GameObject FindPrefab(string name)
    {
        string[] guids = AssetDatabase.FindAssets($"t:Prefab {name}");
        foreach (var guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab != null && prefab.name == name)
                return prefab;
        }
        return null;
    }

    private static PanelSettings FindPanelSettings()
    {
        string[] guids = AssetDatabase.FindAssets("t:PanelSettings");
        if (guids.Length > 0)
        {
            string path = AssetDatabase.GUIDToAssetPath(guids[0]);
            return AssetDatabase.LoadAssetAtPath<PanelSettings>(path);
        }
        return null;
    }

    // ============================================
    //   VALIDATION
    // ============================================

    [MenuItem("Tools/Setup Scenes/Validate Scenes", priority = 10)]
    public static void ValidateScenes()
    {
        Debug.Log("========================================");
        Debug.Log("  SCENE VALIDATION");
        Debug.Log("========================================");

        ValidateServerScene();
        ValidateMenuScene();
        ValidateClientScene();

        Debug.Log("========================================");
    }

    private static void ValidateServerScene()
    {
        Debug.Log("\n[Server Scene]");

        string scenePath = "Assets/Scenes/Server.unity";
        if (!File.Exists(scenePath))
        {
            Debug.LogError("  ❌ Scene not found!");
            return;
        }

        var scene = EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Additive);

        // Check ServerBootstrap
        var bootstrap = Object.FindFirstObjectByType<ServerBootstrap>();
        if (bootstrap != null)
            Debug.Log("  ✅ ServerBootstrap found");
        else
            Debug.LogError("  ❌ ServerBootstrap missing!");

        // Check for PlayerManager (should not exist)
        var playerManager = GameObject.Find("PlayerManager");
        if (playerManager == null)
            Debug.Log("  ✅ No PlayerManager (good)");
        else
            Debug.LogWarning("  ⚠️ PlayerManager should be removed");

        // Check NetworkManager
        var netManager = Object.FindFirstObjectByType<Unity.Netcode.NetworkManager>();
        if (netManager != null)
            Debug.Log("  ✅ NetworkManager found");
        else
            Debug.LogError("  ❌ NetworkManager missing!");

        EditorSceneManager.CloseScene(scene, true);
    }

    private static void ValidateMenuScene()
    {
        Debug.Log("\n[Menu Scene]");

        string scenePath = "Assets/Scenes/Menu.unity";
        if (!File.Exists(scenePath))
        {
            Debug.LogError("  ❌ Scene not found!");
            return;
        }

        var scene = EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Additive);

        // Check ClientBootstrap
        var clientBootstrap = Object.FindFirstObjectByType<ClientBootstrap>();
        if (clientBootstrap != null)
            Debug.Log("  ✅ ClientBootstrap found");
        else
            Debug.LogError("  ❌ ClientBootstrap missing!");

        // Check UIDocument
        var uiDoc = Object.FindFirstObjectByType<UIDocument>();
        if (uiDoc != null)
        {
            Debug.Log("  ✅ UIDocument found");
            if (uiDoc.visualTreeAsset != null)
                Debug.Log($"     UXML: {uiDoc.visualTreeAsset.name}");
            else
                Debug.LogWarning("  ⚠️ UIDocument has no UXML assigned!");
        }
        else
            Debug.LogError("  ❌ UIDocument missing!");

        // Check NetworkManager
        var netManager = Object.FindFirstObjectByType<Unity.Netcode.NetworkManager>();
        if (netManager != null)
            Debug.Log("  ✅ NetworkManager found");
        else
            Debug.LogError("  ❌ NetworkManager missing!");

        EditorSceneManager.CloseScene(scene, true);
    }

    private static void ValidateClientScene()
    {
        Debug.Log("\n[Client Scene]");

        string scenePath = "Assets/Scenes/Client.unity";
        if (!File.Exists(scenePath))
        {
            Debug.LogError("  ❌ Scene not found!");
            return;
        }

        var scene = EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Additive);

        // Check SessionLobbyUI
        var lobbyUI = Object.FindFirstObjectByType<SessionLobbyUI>();
        if (lobbyUI != null)
            Debug.Log("  ✅ SessionLobbyUI found");
        else
            Debug.LogError("  ❌ SessionLobbyUI missing!");

        // Check UIDocument
        var uiDoc = Object.FindFirstObjectByType<UIDocument>();
        if (uiDoc != null)
        {
            Debug.Log("  ✅ UIDocument found");
            if (uiDoc.visualTreeAsset != null)
                Debug.Log($"     UXML: {uiDoc.visualTreeAsset.name}");
            else
                Debug.LogWarning("  ⚠️ UIDocument has no UXML assigned!");
        }
        else
            Debug.LogError("  ❌ UIDocument missing!");

        // Check NetworkManager
        var netManager = Object.FindFirstObjectByType<Unity.Netcode.NetworkManager>();
        if (netManager != null)
            Debug.Log("  ✅ NetworkManager found");
        else
            Debug.LogError("  ❌ NetworkManager missing!");

        EditorSceneManager.CloseScene(scene, true);
    }
}
