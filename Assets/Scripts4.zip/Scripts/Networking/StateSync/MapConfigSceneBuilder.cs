using UnityEngine;

namespace Networking.StateSync
{
    /// <summary>
    /// Client-side scene builder for the replicated arena.
    /// 
    /// The builder listens to MapConfigData (sent by the server) and creates:
    /// - a floor mesh
    /// - a border outline
    /// - an orthographic top-down camera (if one exists in the scene)
    /// </summary>
    public class MapConfigSceneBuilder : MonoBehaviour
    {
        public static MapConfigSceneBuilder Instance { get; private set; }

        [Header("Visual Settings")]
        [SerializeField] private float borderWidth = 0.1f;
        [SerializeField] private int circleBorderSegments = 96;

        private MapConfigData currentConfig;
        private GameObject sceneRoot;

        public static MapConfigSceneBuilder EnsureInstance()
        {
            if (Instance != null) return Instance;
            var go = new GameObject("MapConfigSceneBuilder");
            DontDestroyOnLoad(go);
            Instance = go.AddComponent<MapConfigSceneBuilder>();
            return Instance;
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);

            // Listen to map config replication
            GameCommandClient.OnMapConfigApplied += HandleMapConfigApplied;
        }

        private void OnDestroy()
        {
            if (Instance == this)
                GameCommandClient.OnMapConfigApplied -= HandleMapConfigApplied;
        }

        private void HandleMapConfigApplied(MapConfigData config)
        {
            currentConfig = config;
            BuildScene(config);
        }

        private void BuildScene(MapConfigData config)
        {
            CleanupScene();

            if (config == null)
                return;

            sceneRoot = new GameObject("MapConfigSceneRoot");
            sceneRoot.transform.position = config.worldOffset;

            switch (config.shape)
            {
                case MapShape.Circle:
                    BuildCircleArena(config);
                    break;
                case MapShape.Rect:
                default:
                    BuildRectArena(config);
                    break;
            }

            SetupCamera(config);
        }

        private void BuildRectArena(MapConfigData config)
        {
            float width = Mathf.Abs(config.mapSize.x);
            float height = Mathf.Abs(config.mapSize.z);
            if (Mathf.Approximately(height, 0f))
                height = Mathf.Abs(config.mapSize.y);

            // Floor (Plane is 10x10 in Unity units)
            var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor";
            floor.transform.SetParent(sceneRoot.transform, false);
            floor.transform.localPosition = Vector3.zero;
            floor.transform.localScale = new Vector3(width / 10f, 1f, height / 10f);

            // Remove collider for visuals-only
            var collider = floor.GetComponent<Collider>();
            if (collider != null)
                Destroy(collider);

            // Border (LineRenderer)
            var border = new GameObject("Border");
            border.transform.SetParent(sceneRoot.transform, false);
            var lr = border.AddComponent<LineRenderer>();
            lr.useWorldSpace = false;
            lr.loop = true;
            lr.positionCount = 4;
            lr.startWidth = borderWidth;
            lr.endWidth = borderWidth;
            lr.material = new Material(Shader.Find("Sprites/Default"));

            float halfW = width / 2f;
            float halfH = height / 2f;
            lr.SetPosition(0, new Vector3(-halfW, 0.02f, -halfH));
            lr.SetPosition(1, new Vector3(halfW, 0.02f, -halfH));
            lr.SetPosition(2, new Vector3(halfW, 0.02f, halfH));
            lr.SetPosition(3, new Vector3(-halfW, 0.02f, halfH));
        }

        private void BuildCircleArena(MapConfigData config)
        {
            float radius = Mathf.Max(0.1f, config.circleRadius);

            // Floor disc
            var floor = new GameObject("Floor");
            floor.transform.SetParent(sceneRoot.transform, false);
            floor.transform.localPosition = Vector3.zero;
            var mf = floor.AddComponent<MeshFilter>();
            var mr = floor.AddComponent<MeshRenderer>();
            mr.material = new Material(Shader.Find("Sprites/Default"));
            mf.mesh = CreateDiscMesh(radius, Mathf.Max(32, circleBorderSegments));

            // Border circle (LineRenderer)
            var border = new GameObject("Border");
            border.transform.SetParent(sceneRoot.transform, false);
            var lr = border.AddComponent<LineRenderer>();
            lr.useWorldSpace = false;
            lr.loop = true;
            int segments = Mathf.Max(32, circleBorderSegments);
            lr.positionCount = segments;
            lr.startWidth = borderWidth;
            lr.endWidth = borderWidth;
            lr.material = new Material(Shader.Find("Sprites/Default"));

            for (int i = 0; i < segments; i++)
            {
                float t = (i / (float)segments) * Mathf.PI * 2f;
                lr.SetPosition(i, new Vector3(Mathf.Cos(t) * radius, 0.02f, Mathf.Sin(t) * radius));
            }
        }

        private static Mesh CreateDiscMesh(float radius, int segments)
        {
            var mesh = new Mesh();
            mesh.name = "Disc";

            var vertices = new Vector3[segments + 1];
            var triangles = new int[segments * 3];

            vertices[0] = Vector3.zero;
            for (int i = 0; i < segments; i++)
            {
                float t = (i / (float)segments) * Mathf.PI * 2f;
                vertices[i + 1] = new Vector3(Mathf.Cos(t) * radius, 0f, Mathf.Sin(t) * radius);
            }

            for (int i = 0; i < segments; i++)
            {
                int triIndex = i * 3;
                triangles[triIndex] = 0;
                triangles[triIndex + 1] = i + 1;
                triangles[triIndex + 2] = (i + 1) % segments + 1;
            }

            mesh.vertices = vertices;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private void SetupCamera(MapConfigData config)
        {
            var camera = Camera.main;
            if (camera == null)
                return;

            camera.orthographic = true;
            camera.transform.position = config.worldOffset + new Vector3(0f, 10f, 0f);
            camera.transform.rotation = Quaternion.Euler(90f, 0f, 0f);

            float ortho;
            if (config.shape == MapShape.Circle)
            {
                ortho = Mathf.Max(5f, config.circleRadius * 1.2f);
            }
            else
            {
                float width = Mathf.Abs(config.mapSize.x);
                float height = Mathf.Abs(config.mapSize.z);
                if (Mathf.Approximately(height, 0f))
                    height = Mathf.Abs(config.mapSize.y);
                ortho = Mathf.Max(5f, Mathf.Max(width, height) * 0.6f);
            }

            camera.orthographicSize = ortho;
        }

        public void CleanupScene()
        {
            if (sceneRoot != null)
            {
                Destroy(sceneRoot);
                sceneRoot = null;
            }
        }

        public MapConfigData GetCurrentConfig() => currentConfig;
    }
}
