using System;
using System.Collections;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Client-only bootstrap. Handles connection to server.
/// Place this in the Menu scene or a persistent Client scene.
/// </summary>
public class ClientBootstrap : MonoBehaviour
{
    public static ClientBootstrap Instance { get; private set; }

    [Header("Default Connection")]
    [SerializeField] private string defaultServerIP = "127.0.0.1";
    [SerializeField] private ushort defaultPort = 7777;

    [Header("Scenes")]
    [SerializeField] private string lobbySceneName = "Client";
    [SerializeField] private string gameSceneName = "Game";

    // Current connection settings
    public string ServerIP { get; private set; }
    public ushort ServerPort { get; private set; }
    public bool IsConnected => NetworkManager.Singleton != null && NetworkManager.Singleton.IsConnectedClient;

    // Events
    public event Action OnConnected;
    public event Action OnDisconnected;
    public event Action<string> OnConnectionFailed;

    private NetworkManager networkManager;
    private UnityTransport transport;
    private bool isConnecting;

    private void Awake()
    {
        #if UNITY_SERVER
        Debug.LogWarning("[ClientBootstrap] Disabled: running in Dedicated Server build.");
        enabled = false;
        return;
        #endif

        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        ServerIP = defaultServerIP;
        ServerPort = defaultPort;

        Debug.Log("[ClientBootstrap] Initialized");
    }

    private void Start()
    {
        // Get NetworkManager
        networkManager = NetworkManager.Singleton;
        if (networkManager != null)
        {
            transport = networkManager.GetComponent<UnityTransport>();
            networkManager.OnClientConnectedCallback += HandleClientConnected;
            networkManager.OnClientDisconnectCallback += HandleClientDisconnected;
        }
    }

    private void OnDestroy()
    {
        if (networkManager != null)
        {
            networkManager.OnClientConnectedCallback -= HandleClientConnected;
            networkManager.OnClientDisconnectCallback -= HandleClientDisconnected;
        }

        if (Instance == this)
            Instance = null;
    }

    /// <summary>
    /// Connect to server with specified IP and port.
    /// </summary>
    public void Connect(string ip, ushort port)
    {
        if (isConnecting)
        {
            Debug.LogWarning("[ClientBootstrap] Already connecting...");
            return;
        }

        if (IsConnected)
        {
            Debug.LogWarning("[ClientBootstrap] Already connected!");
            return;
        }

        ServerIP = ip;
        ServerPort = port;

        Debug.Log($"[ClientBootstrap] Connecting to {ip}:{port}...");
        StartCoroutine(ConnectCoroutine());
    }

    /// <summary>
    /// Connect with current settings.
    /// </summary>
    public void Connect()
    {
        Connect(ServerIP, ServerPort);
    }

    /// <summary>
    /// Disconnect from server.
    /// </summary>
    public void Disconnect()
    {
        if (networkManager != null && networkManager.IsClient)
        {
            Debug.Log("[ClientBootstrap] Disconnecting...");
            networkManager.Shutdown();
        }
    }

    private IEnumerator ConnectCoroutine()
    {
        isConnecting = true;

        // Make sure we have NetworkManager
        if (networkManager == null)
        {
            networkManager = NetworkManager.Singleton;
            if (networkManager == null)
            {
                OnConnectionFailed?.Invoke("NetworkManager not found");
                isConnecting = false;
                yield break;
            }
            transport = networkManager.GetComponent<UnityTransport>();
        }

        // Configure transport
        if (transport != null)
        {
            // Force UDP (no WebSockets/TLS) for the game transport.
            transport.UseWebSockets = false;
            transport.UseEncryption = false;

            transport.ConnectionData.Address = ServerIP;
            transport.ConnectionData.Port = ServerPort;
            Debug.Log($"[ClientBootstrap] Transport configured: {ServerIP}:{ServerPort}");
        }

        // Start client
        bool started = networkManager.StartClient();
        if (!started)
        {
            OnConnectionFailed?.Invoke("Failed to start client");
            isConnecting = false;
            yield break;
        }

        // Wait for connection with timeout
        float timeout = 10f;
        float elapsed = 0f;

        while (!networkManager.IsConnectedClient && elapsed < timeout)
        {
            yield return new WaitForSeconds(0.1f);
            elapsed += 0.1f;
        }

        isConnecting = false;

        if (!networkManager.IsConnectedClient)
        {
            networkManager.Shutdown();
            OnConnectionFailed?.Invoke($"Connection timeout after {timeout}s");
        }
    }

    private void HandleClientConnected(ulong clientId)
    {
        if (clientId == networkManager.LocalClientId)
        {
            Debug.Log($"[ClientBootstrap] ✅ Connected to server (ClientId: {clientId})");
            isConnecting = false;
            OnConnected?.Invoke();

            // Load lobby scene if not already there (only if scene is in build settings)
            string currentScene = SceneManager.GetActiveScene().name;
            Debug.Log($"[ClientBootstrap] Current scene: '{currentScene}', Lobby: '{lobbySceneName}', Game: '{gameSceneName}'");
            
            if (currentScene == lobbySceneName)
            {
                Debug.Log($"[ClientBootstrap] Already on lobby scene '{lobbySceneName}', no reload needed");
            }
            else if (currentScene != gameSceneName)
            {
                // Not on lobby or game scene, load lobby
                if (Application.CanStreamedLevelBeLoaded(lobbySceneName))
                {
                    Debug.Log($"[ClientBootstrap] Loading lobby scene '{lobbySceneName}'");
                    SceneManager.LoadScene(lobbySceneName);
                }
                else
                {
                    Debug.LogWarning($"[ClientBootstrap] Scene '{lobbySceneName}' not in build settings, staying on '{currentScene}'");
                }
            }
            else
            {
                Debug.Log($"[ClientBootstrap] On game scene '{gameSceneName}', no scene change");
            }
        }
    }

    private void HandleClientDisconnected(ulong clientId)
    {
        if (networkManager != null && clientId == networkManager.LocalClientId)
        {
            Debug.Log("[ClientBootstrap] Disconnected from server");
            OnDisconnected?.Invoke();
        }
    }

    /// <summary>
    /// Test connection to server (ping-like check).
    /// </summary>
    public void TestConnection(string ip, ushort port, Action<bool, string> callback)
    {
        StartCoroutine(TestConnectionCoroutine(ip, port, callback));
    }

    private IEnumerator TestConnectionCoroutine(string ip, ushort port, Action<bool, string> callback)
    {
        Debug.Log($"[ClientBootstrap] Testing connection to {ip}:{port}...");

        // UDP connection test - send a small packet and wait for response
        bool success = false;
        string message = "Connection timeout";

        System.Net.Sockets.UdpClient udpClient = null;
        
        try
        {
            udpClient = new System.Net.Sockets.UdpClient();
            udpClient.Client.ReceiveTimeout = 2000; // 2 second timeout
            udpClient.Client.SendTimeout = 2000;
            
            var endpoint = new System.Net.IPEndPoint(System.Net.IPAddress.Parse(ip), port);
            
            // Send a simple ping packet
            byte[] pingData = new byte[] { 0x00, 0x01, 0x02, 0x03 };
            udpClient.Send(pingData, pingData.Length, endpoint);
            
            // For UDP, we can't really know if server received it without a response
            // But if Send doesn't throw, the network path exists
            success = true;
            message = "UDP packet sent successfully (server may be reachable)";
        }
        catch (System.Net.Sockets.SocketException ex)
        {
            success = false;
            message = $"Network error: {ex.SocketErrorCode}";
        }
        catch (Exception ex)
        {
            success = false;
            message = ex.Message;
        }
        finally
        {
            udpClient?.Close();
        }

        yield return null;

        Debug.Log($"[ClientBootstrap] Test result: {(success ? "✅" : "❌")} {message}");
        callback?.Invoke(success, message);
    }
}