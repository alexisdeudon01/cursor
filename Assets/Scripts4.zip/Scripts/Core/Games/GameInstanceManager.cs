using System;
using System.Collections.Generic;
using Core.Simulation;
using Networking.StateSync;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Manages active game instances.
/// 
/// Data-oriented refactor (Option 1):
/// - Server runs an authoritative simulation (SimWorld).
/// - Player pawns are NOT NetworkObjects.
/// - The server replicates state via GameCommandDto messages.
/// </summary>
public class GameInstanceManager : MonoBehaviour
{
    public static GameInstanceManager Instance { get; private set; }

    /// <summary>
    /// Event fired when a game instance is created.
    /// </summary>
    public static event Action<string, string> GameCreated; // sessionName, gameId

    /// <summary>
    /// Event fired when a game instance is destroyed.
    /// </summary>
    public static event Action<string> GameDestroyed; // sessionName

    [Header("Server Tick Rates")]
    [SerializeField] private float simulationTickRate = 60f;
    [SerializeField] private float replicationTickRate = 20f;

    // Active games
    private readonly Dictionary<string, GameInstance> activeBySessionName = new Dictionary<string, GameInstance>();
    private readonly Dictionary<string, GameInstance> activeBySessionUid = new Dictionary<string, GameInstance>();

    // Scratch lists to avoid allocations
    private readonly List<int> scratchEntityIds = new List<int>(64);
    private readonly List<GameCommandDto> scratchCommands = new List<GameCommandDto>(256);

    private float simAccumulator;
    private float repAccumulator;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void OnDestroy()
    {
        if (Instance == this)
        {
            Instance = null;
        }
    }

    private void Update()
    {
        // Server only simulation & replication
        if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
        {
            return;
        }

        if (activeBySessionName.Count == 0)
        {
            return;
        }

        var dt = Time.deltaTime;
        if (dt <= 0f)
        {
            return;
        }

        simAccumulator += dt;
        repAccumulator += dt;

        var simStep = simulationTickRate > 0.01f ? (1f / simulationTickRate) : (1f / 60f);
        var repStep = replicationTickRate > 0.01f ? (1f / replicationTickRate) : (1f / 20f);

        while (simAccumulator >= simStep)
        {
            foreach (var kv in activeBySessionName)
            {
                kv.Value.Step(simStep);
            }

            simAccumulator -= simStep;
        }

        while (repAccumulator >= repStep)
        {
            foreach (var kv in activeBySessionName)
            {
                ReplicateDirty(kv.Value);
            }

            repAccumulator -= repStep;
        }
    }

    /// <summary>
    /// [SERVER] Create a new game instance for a session.
    /// </summary>
    public bool CreateGame(
        string sessionName,
        string sessionUid,
        string gameId,
        List<(ulong clientId, string name)> playerData,
        Vector3 worldOffset)
    {
        if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
        {
            Debug.LogError("[GameInstanceManager] CreateGame called on client!");
            return false;
        }

        if (string.IsNullOrEmpty(sessionName) || string.IsNullOrEmpty(sessionUid) || string.IsNullOrEmpty(gameId))
        {
            Debug.LogError("[GameInstanceManager] CreateGame missing required arguments");
            return false;
        }

        if (activeBySessionName.ContainsKey(sessionName) || activeBySessionUid.ContainsKey(sessionUid))
        {
            Debug.LogWarning($"[GameInstanceManager] Session '{sessionName}' already has an active game");
            return false;
        }

        var gameDef = GameRegistry.GetGame(gameId);
        if (gameDef == null)
        {
            Debug.LogError($"[GameInstanceManager] Game '{gameId}' not found in registry");
            return false;
        }

        var seed = ComputeSeed(sessionUid, worldOffset);
        var mapConfig = gameDef.CreateMapConfig(worldOffset, seed);
        if (mapConfig == null)
        {
            Debug.LogError($"[GameInstanceManager] Game '{gameId}' returned null MapConfigData");
            return false;
        }

        var instance = new GameInstance(sessionName, sessionUid, gameId, gameDef, mapConfig);

        // Spawn player entities
        var registryHub = GlobalRegistryHub.Instance;
        var totalPlayers = playerData?.Count ?? 0;
        for (int i = 0; i < totalPlayers; i++)
        {
            var (clientId, playerName) = playerData[i];

            string clientUid = string.Empty;
            if (registryHub?.ClientRegistry != null)
            {
                registryHub.ClientRegistry.TryGetClientUidByNetClientId(clientId, out clientUid);
            }
            var spawnPos = gameDef.GetSpawnPosition(i, totalPlayers, mapConfig);

            instance.AddPlayer(clientId, playerName, clientUid, spawnPos, i);
        }

        activeBySessionName[sessionName] = instance;
        activeBySessionUid[sessionUid] = instance;

        Debug.Log($"[GameInstanceManager] Created game '{gameId}' for session '{sessionName}' with {totalPlayers} players");
        GameCreated?.Invoke(sessionName, gameId);
        return true;
    }

    /// <summary>
    /// [SERVER] Destroy a game instance.
    /// </summary>
    public void DestroyGame(string sessionName)
    {
        if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
        {
            return;
        }

        if (!activeBySessionName.TryGetValue(sessionName, out var instance))
        {
            return;
        }

        activeBySessionName.Remove(sessionName);
        if (!string.IsNullOrEmpty(instance.SessionUid))
        {
            activeBySessionUid.Remove(instance.SessionUid);
        }

        instance.Cleanup();

        Debug.Log($"[GameInstanceManager] Destroyed game for session '{sessionName}'");
        GameDestroyed?.Invoke(sessionName);
    }

    public bool HasActiveGame(string sessionName)
    {
        return activeBySessionName.ContainsKey(sessionName);
    }

    public bool TryGetInstance(string sessionName, out GameInstance instance)
    {
        return activeBySessionName.TryGetValue(sessionName, out instance);
    }

    public bool TryGetInstanceBySessionUid(string sessionUid, out GameInstance instance)
    {
        return activeBySessionUid.TryGetValue(sessionUid, out instance);
    }

    public string GetGameId(string sessionName)
    {
        return activeBySessionName.TryGetValue(sessionName, out var inst) ? inst.GameId : null;
    }

    public List<ulong> GetPlayerIds(string sessionName)
    {
        return activeBySessionName.TryGetValue(sessionName, out var inst)
            ? new List<ulong>(inst.PlayerIds)
            : new List<ulong>();
    }

    public bool TryGetWorldOffset(string sessionName, out Vector3 worldOffset)
    {
        if (activeBySessionName.TryGetValue(sessionName, out var inst) && inst.MapConfig != null)
        {
            worldOffset = inst.MapConfig.worldOffset;
            return true;
        }

        worldOffset = Vector3.zero;
        return false;
    }

    /// <summary>
    /// [SERVER] Set movement input for a player in a given session.
    /// </summary>
    public void SetPlayerInput(string sessionName, ulong clientId, Vector2 direction)
    {
        if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
        {
            return;
        }

        if (!activeBySessionName.TryGetValue(sessionName, out var inst))
        {
            return;
        }

        inst.World.SetInput(clientId, direction);
    }

    /// <summary>
    /// [SERVER] Late joiner support.
    /// Spawns a new entity for the player and sends the current snapshot to the joining client.
    /// </summary>
    public bool AddPlayerToGame(string sessionName, ulong clientId, string playerName)
    {
        if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
        {
            return false;
        }

        if (!activeBySessionName.TryGetValue(sessionName, out var inst))
        {
            return false;
        }

        if (inst.PlayerIds.Contains(clientId))
        {
            Debug.LogWarning($"[GameInstanceManager] Player {clientId} already in game for session '{sessionName}'");
            return false;
        }

        var registryHub = GlobalRegistryHub.Instance;
        string clientUid = string.Empty;
        if (registryHub?.ClientRegistry != null)
        {
            registryHub.ClientRegistry.TryGetClientUidByNetClientId(clientId, out clientUid);
        }

        var totalPlayersAfterJoin = inst.PlayerIds.Count + 1;
        var joinIndex = inst.PlayerIds.Count;
        var spawnPos = inst.GameDefinition.GetSpawnPosition(joinIndex, totalPlayersAfterJoin, inst.MapConfig);

        // Add to world
        inst.BumpVersion();
        var entityId = inst.AddPlayer(clientId, playerName, clientUid, spawnPos, joinIndex);

        // Notify existing players about the new entity
        var existingTargets = new List<ulong>(inst.PlayerIds);
        existingTargets.Remove(clientId);

        if (existingTargets.Count > 0)
        {
            var rpcParams = BuildClientRpcParams(existingTargets);
            var spawnCmd = inst.BuildSpawnCommand(entityId, inst.Version);
            SessionRpcHub.Instance?.SendGameCommandClientRpc(spawnCmd, rpcParams);
        }

        // Send full snapshot to late joiner
        SendFullSnapshotToClient(sessionName, clientId);

        return true;
    }

    /// <summary>
    /// [SERVER] Remove a player entity from an active game.
    /// </summary>
    public bool RemovePlayerFromGame(string sessionName, ulong clientId)
    {
        if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
        {
            return false;
        }

        if (!activeBySessionName.TryGetValue(sessionName, out var inst))
        {
            return false;
        }

        if (!inst.PlayerIds.Contains(clientId))
        {
            return false;
        }

        if (!inst.World.TryGetEntityIdForOwner(clientId, out var entityId))
        {
            inst.PlayerIds.Remove(clientId);
            return true;
        }

        inst.BumpVersion();

        // Remove from sim world first
        inst.World.RemoveEntity(entityId);
        inst.PlayerIds.Remove(clientId);

        // Replicate removal to remaining players
        if (inst.PlayerIds.Count > 0)
        {
            
var rpcParams = BuildClientRpcParams(inst.PlayerIds);

var removeCmd = new GameCommandDto
{
    Type = GameCommandType.RemoveEntity,
    Version = inst.Version,
    SessionUid = inst.SessionUid,
    EntityId = ToFixedString(entityId)
};

scratchCommands.Clear();
scratchCommands.Add(removeCmd);
SessionRpcHub.Instance.SendGameCommandBatchClientRpc(scratchCommands.ToArray(), rpcParams);

}

        return true;
    }

    /// <summary>
    /// [SERVER] Send full game snapshot (map + spawns) to a specific client.
    /// This does not change the authoritative state/version.
    /// </summary>
public void SendFullSnapshotToClient(string sessionName, ulong targetClientId, bool includeMapConfig = true)
{
    if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
    {
        return;
    }

    if (!activeBySessionName.TryGetValue(sessionName, out var inst))
    {
        return;
    }

    var targets = new List<ulong> { targetClientId };
    SendFullSnapshotInternal(inst, targets, includeMapConfig);
}

/// <summary>
/// [SERVER] Send full game snapshot (map + spawns) to multiple clients.
/// Uses a batched client RPC to reduce RPC overhead.
/// </summary>
public void SendFullSnapshotToClients(string sessionName, IReadOnlyList<ulong> targetClientIds, bool includeMapConfig = true)
{
    if (!NetworkManager.Singleton || !NetworkManager.Singleton.IsServer)
    {
        return;
    }

    if (!activeBySessionName.TryGetValue(sessionName, out var inst))
    {
        return;
    }

    if (targetClientIds == null || targetClientIds.Count == 0)
    {
        return;
    }

    var targets = new List<ulong>(targetClientIds);
    SendFullSnapshotInternal(inst, targets, includeMapConfig);
}

private void SendFullSnapshotInternal(GameInstance inst, List<ulong> targets, bool includeMapConfig)
{
    if (inst == null || inst.MapConfig == null || SessionRpcHub.Instance == null)
    {
        return;
    }

    var rpcParams = BuildClientRpcParams(targets);

    scratchCommands.Clear();

    // Map config first (optional)
    if (includeMapConfig)
    {
        scratchCommands.Add(GameCommandFactory.CreateMapConfig(inst.SessionUid, inst.MapConfig));
    }

    // Then spawn all entities (snapshot)
    inst.World.CollectAllEntityIds(scratchEntityIds);
    for (int i = 0; i < scratchEntityIds.Count; i++)
    {
        var entityId = scratchEntityIds[i];
        scratchCommands.Add(inst.BuildSpawnCommand(entityId, inst.Version));
    }

    if (scratchCommands.Count > 0)
    {
        SessionRpcHub.Instance.SendGameCommandBatchClientRpc(scratchCommands.ToArray(), rpcParams);
    }
}


private void ReplicateDirty(GameInstance inst)
{
    if (inst == null || inst.MapConfig == null)
    {
        return;
    }

    if (!inst.World.IsDirty)
    {
        return;
    }

    if (SessionRpcHub.Instance == null)
    {
        return;
    }

    inst.BumpVersion();

    inst.World.CollectDirtyEntityIds(scratchEntityIds);
    if (scratchEntityIds.Count == 0)
    {
        inst.World.ClearDirty();
        return;
    }

    var rpcParams = BuildClientRpcParams(inst.PlayerIds);

    scratchCommands.Clear();
    for (int i = 0; i < scratchEntityIds.Count; i++)
    {
        var entityId = scratchEntityIds[i];

        inst.World.GetEntityDataById(entityId,
            out var prefabType,
            out var ownerClientId,
            out var ownerClientUid,
            out var displayName,
            out var colorIndex,
            out var position,
            out var rotation);

        // Incremental update: only transform is required (identity is sent on SpawnEntity).
        var cmd = new GameCommandDto
        {
            Type = GameCommandType.UpdateEntity,
            Version = inst.Version,
            SessionUid = inst.SessionUid,
            EntityId = ToFixedString(entityId),
            Position = position,
            Rotation = rotation
        };

        scratchCommands.Add(cmd);
    }

    SessionRpcHub.Instance.SendGameCommandBatchClientRpc(scratchCommands.ToArray(), rpcParams);

    inst.World.ClearDirty();
}



internal static FixedString64Bytes ToFixedString(int value)
{
    FixedString64Bytes fs = default;
    fs.Append(value);
    return fs;
}

    private static ClientRpcParams BuildClientRpcParams(IReadOnlyList<ulong> targets)
    {
        var sendParams = new ClientRpcSendParams
        {
            TargetClientIds = targets
        };

        return new ClientRpcParams
        {
            Send = sendParams
        };
    }

    private static int ComputeSeed(string sessionUid, Vector3 worldOffset)
    {
        unchecked
        {
            // FNV-1a 32-bit hash
            uint hash = 2166136261;

            if (!string.IsNullOrEmpty(sessionUid))
            {
                for (int i = 0; i < sessionUid.Length; i++)
                {
                    hash ^= sessionUid[i];
                    hash *= 16777619;
                }
            }

            hash ^= (uint)Mathf.RoundToInt(worldOffset.x * 10f);
            hash *= 16777619;
            hash ^= (uint)Mathf.RoundToInt(worldOffset.z * 10f);
            hash *= 16777619;

            return (int)hash;
        }
    }
}

/// <summary>
/// Server-side game instance state.
/// </summary>
public sealed class GameInstance
{
    public string SessionName { get; }
    public string SessionUid { get; }
    public string GameId { get; }
    public IGameDefinition GameDefinition { get; }
    public MapConfigData MapConfig { get; }

    public SimWorld World { get; } = new SimWorld();

    public List<ulong> PlayerIds { get; } = new List<ulong>(16);

    public int Version { get; private set; } = 1;

    public GameInstance(string sessionName, string sessionUid, string gameId, IGameDefinition gameDefinition, MapConfigData mapConfig)
    {
        SessionName = sessionName;
        SessionUid = sessionUid;
        GameId = gameId;
        GameDefinition = gameDefinition;
        MapConfig = mapConfig;
    }

    public void Step(float dt)
    {
        World.Step(dt, GameDefinition.MoveSpeed, MapConfig);
    }

    public int AddPlayer(ulong clientId, string playerName, string clientUid, Vector3 spawnPos, int colorIndex)
    {
        PlayerIds.Add(clientId);

        var ownerUid = new FixedString64Bytes(clientUid ?? string.Empty);
        var displayName = new FixedString64Bytes(string.IsNullOrEmpty(playerName) ? $"Player {clientId}" : playerName);
        var prefabType = (byte)GameDefinition.PawnPrefabType;

        var entityId = World.SpawnPlayerEntity(
            ownerClientId: clientId,
            ownerClientUid: ownerUid,
            displayName: displayName,
            colorIndex: colorIndex,
            prefabType: prefabType,
            position: spawnPos,
            rotation: Quaternion.identity);

        return entityId;
    }

    public void BumpVersion()
    {
        Version++;
    }

    public GameCommandDto BuildSpawnCommand(int entityId, int version)
    {
        World.GetEntityDataById(entityId,
            out var prefabType,
            out var ownerClientId,
            out var ownerClientUid,
            out var displayName,
            out var colorIndex,
            out var position,
            out var rotation);

        return new GameCommandDto
        {
            Type = GameCommandType.SpawnEntity,
            Version = version,
            SessionUid = SessionUid,
            EntityId = GameInstanceManager.ToFixedString(entityId),
            EntityType = "player",
            PrefabType = prefabType,
            OwnerClientId = ownerClientId,
            OwnerClientUid = ownerClientUid,
            DisplayName = displayName,
            ColorIndex = colorIndex,
            Position = position,
            Rotation = rotation
        };
    }

    public void Cleanup()
    {
        GameDefinition?.CleanupGame();
        PlayerIds.Clear();
        World.ClearDirty();
    }
}
