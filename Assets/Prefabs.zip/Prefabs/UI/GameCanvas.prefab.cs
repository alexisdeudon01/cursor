using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Canvas))]
public class GameCanvasRoot : MonoBehaviour
{
    // Ce script sert juste à identifier le GameCanvas dans la scène/préfab
    private void Awake()
    {
        if (Application.isPlaying)
        {
            EnsureLayout();
        }
    }

    private void EnsureLayout()
    {
        var rect = GetComponent<RectTransform>();
        if (rect != null)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = Vector2.zero;
            rect.localScale = Vector3.one;
            rect.pivot = new Vector2(0.5f, 0.5f);
        }

        var canvas = GetComponent<Canvas>();
        if (canvas != null)
        {
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.worldCamera = null;
        }

        var scaler = GetComponent<CanvasScaler>();
        if (scaler != null)
        {
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
        }

        var childCamera = GetComponentInChildren<Camera>();
        if (childCamera != null)
        {
            Debug.LogWarning("[GameCanvasRoot] Camera should not be a child of GameCanvas. Reparenting to scene root.", this);
            childCamera.transform.SetParent(null, true);
        }
    }
}
