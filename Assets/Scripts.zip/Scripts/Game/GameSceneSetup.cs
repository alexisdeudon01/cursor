using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Sets up the game scene when loaded.
/// Creates camera, background, and boundaries for a 2D top-down game.
/// Attach to an empty GameObject in the Game scene.
/// </summary>
public class GameSceneSetup : MonoBehaviour
{
    [Header("Map Settings")]
    [SerializeField] private Vector2 mapSize = new Vector2(20f, 15f);
    [SerializeField] private Color backgroundColor = new Color(0.15f, 0.15f, 0.2f);
    [SerializeField] private Color borderColor = new Color(0.3f, 0.3f, 0.4f);
    [SerializeField] private float borderWidth = 0.5f;

    [Header("Camera Settings")]
    [SerializeField] private float cameraHeight = 15f;
    [SerializeField] private bool orthographic = true;
    [SerializeField] private float orthographicSize = 10f;
    [SerializeField] private bool autoFitMap = true;
    [SerializeField] private bool enableCameraFollow = false;

    [Header("Random Elements")]
    [SerializeField] private bool generateRandomObstacles = true;
    [SerializeField] private int obstacleCount = 5;
    [SerializeField] private Vector2 obstacleMinSize = new Vector2(1f, 1f);
    [SerializeField] private Vector2 obstacleMaxSize = new Vector2(3f, 3f);
    [SerializeField] private Color obstacleColor = new Color(0.4f, 0.4f, 0.5f);

    private void Start()
    {
        // LOCAL ONLY: Scene setup creates local visual elements
        // Each client sets up their own camera, background, etc.
        // These are NOT networked - purely client-side visuals
        
        SetupCamera();
        CreateBackground();
        CreateBorders();

        if (generateRandomObstacles)
        {
            GenerateRandomObstacles();
        }

        Debug.Log("[GameSceneSetup] Game scene initialized (local visuals)");
    }

    private void SetupCamera()
    {
        Camera mainCam = Camera.main;
        if (mainCam == null)
        {
            var camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            mainCam = camGO.AddComponent<Camera>();
            if (Object.FindFirstObjectByType<AudioListener>() == null)
            {
                camGO.AddComponent<AudioListener>();
            }
        }
        else if (Object.FindFirstObjectByType<AudioListener>() == null)
        {
            mainCam.gameObject.AddComponent<AudioListener>();
        }

        // Position camera for top-down view
        mainCam.transform.position = new Vector3(0, cameraHeight, 0);
        mainCam.transform.rotation = Quaternion.Euler(90, 0, 0);

        mainCam.orthographic = orthographic;
        if (orthographic)
        {
            mainCam.orthographicSize = autoFitMap
                ? ComputeOrthoSize(mainCam, mapSize, borderWidth)
                : orthographicSize;
        }

        mainCam.backgroundColor = backgroundColor;
        mainCam.clearFlags = CameraClearFlags.SolidColor;

        var follow = mainCam.GetComponent<CameraFollowPawn>();
        if (enableCameraFollow)
        {
            if (follow == null)
            {
                follow = mainCam.gameObject.AddComponent<CameraFollowPawn>();
            }
            follow.enabled = true;
        }
        else if (follow != null)
        {
            follow.enabled = false;
        }
    }

    private static float ComputeOrthoSize(Camera camera, Vector2 mapSize, float padding)
    {
        float halfHeight = mapSize.y / 2f;
        float halfWidth = mapSize.x / 2f;
        float aspect = camera != null && camera.aspect > 0.01f ? camera.aspect : 16f / 9f;

        float sizeByWidth = halfWidth / aspect;
        float baseSize = Mathf.Max(halfHeight, sizeByWidth);
        return Mathf.Max(1f, baseSize + Mathf.Max(0f, padding) + 1f);
    }

    private void CreateBackground()
    {
        var bgGO = new GameObject("Background");
        bgGO.transform.position = new Vector3(0, -0.1f, 0);
        bgGO.transform.rotation = Quaternion.identity;

        var meshFilter = bgGO.AddComponent<MeshFilter>();
        var meshRenderer = bgGO.AddComponent<MeshRenderer>();

        // Create a simple quad mesh
        meshFilter.mesh = CreateQuadMesh(mapSize.x, mapSize.y);

        // Create material
        meshRenderer.material = CreateSolidColorMaterial(backgroundColor);
    }

    private void CreateBorders()
    {
        float halfW = mapSize.x / 2f;
        float halfH = mapSize.y / 2f;

        // Top border
        CreateBorder("BorderTop", new Vector3(0, 0, halfH + borderWidth / 2f), new Vector2(mapSize.x + borderWidth * 2, borderWidth));
        // Bottom border
        CreateBorder("BorderBottom", new Vector3(0, 0, -halfH - borderWidth / 2f), new Vector2(mapSize.x + borderWidth * 2, borderWidth));
        // Left border
        CreateBorder("BorderLeft", new Vector3(-halfW - borderWidth / 2f, 0, 0), new Vector2(borderWidth, mapSize.y));
        // Right border
        CreateBorder("BorderRight", new Vector3(halfW + borderWidth / 2f, 0, 0), new Vector2(borderWidth, mapSize.y));
    }

    private void CreateBorder(string name, Vector3 position, Vector2 size)
    {
        var borderGO = new GameObject(name);
        borderGO.transform.position = position;
        borderGO.layer = LayerMask.NameToLayer("Default");

        // Visual
        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.transform.SetParent(borderGO.transform);
        cube.transform.localPosition = Vector3.zero;
        cube.transform.localScale = new Vector3(size.x, 1f, size.y);

        var renderer = cube.GetComponent<MeshRenderer>();
        renderer.material = CreateSolidColorMaterial(borderColor);

        // Collider for physics
        var collider = borderGO.AddComponent<BoxCollider>();
        collider.size = new Vector3(size.x, 2f, size.y);
    }

    private void GenerateRandomObstacles()
    {
        float halfW = mapSize.x / 2f - 2f;
        float halfH = mapSize.y / 2f - 2f;

        for (int i = 0; i < obstacleCount; i++)
        {
            Vector3 pos = new Vector3(
                Random.Range(-halfW, halfW),
                0,
                Random.Range(-halfH, halfH)
            );

            Vector2 size = new Vector2(
                Random.Range(obstacleMinSize.x, obstacleMaxSize.x),
                Random.Range(obstacleMinSize.y, obstacleMaxSize.y)
            );

            CreateObstacle($"Obstacle_{i}", pos, size);
        }
    }

    private void CreateObstacle(string name, Vector3 position, Vector2 size)
    {
        var obstacleGO = new GameObject(name);
        obstacleGO.transform.position = position;

        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.transform.SetParent(obstacleGO.transform);
        cube.transform.localPosition = Vector3.zero;
        cube.transform.localScale = new Vector3(size.x, 0.5f, size.y);

        var renderer = cube.GetComponent<MeshRenderer>();
        renderer.material = CreateSolidColorMaterial(obstacleColor);

        // Collider
        var collider = obstacleGO.AddComponent<BoxCollider>();
        collider.size = new Vector3(size.x, 1f, size.y);
    }

    private Mesh CreateQuadMesh(float width, float height)
    {
        var mesh = new Mesh();

        float halfW = width / 2f;
        float halfH = height / 2f;

        Vector3[] vertices = new Vector3[]
        {
            new Vector3(-halfW, 0, -halfH),
            new Vector3(halfW, 0, -halfH),
            new Vector3(halfW, 0, halfH),
            new Vector3(-halfW, 0, halfH)
        };

        int[] triangles = new int[] { 0, 2, 1, 0, 3, 2 };

        Vector2[] uvs = new Vector2[]
        {
            new Vector2(0, 0),
            new Vector2(1, 0),
            new Vector2(1, 1),
            new Vector2(0, 1)
        };

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.uv = uvs;
        mesh.RecalculateNormals();

        return mesh;
    }

    private static Material CreateSolidColorMaterial(Color color)
    {
        var shader = FindSolidColorShader();
        var material = shader != null ? new Material(shader) : new Material(Shader.Find("Standard"));
        ApplyMaterialColor(material, color);
        return material;
    }

    private static Shader FindSolidColorShader()
    {
        return Shader.Find("Universal Render Pipeline/2D/Sprite-Unlit-Default")
               ?? Shader.Find("Sprites/Default")
               ?? Shader.Find("Universal Render Pipeline/Unlit")
               ?? Shader.Find("Unlit/Color");
    }

    private static void ApplyMaterialColor(Material material, Color color)
    {
        if (material == null)
        {
            return;
        }

        if (material.HasProperty("_BaseColor"))
        {
            material.SetColor("_BaseColor", color);
        }

        if (material.HasProperty("_Color"))
        {
            material.SetColor("_Color", color);
        }

        if (material.HasProperty("_TintColor"))
        {
            material.SetColor("_TintColor", color);
        }

        if (material.HasProperty("_Cull"))
        {
            material.SetInt("_Cull", 0);
        }

        if (material.HasProperty("_CullMode"))
        {
            material.SetInt("_CullMode", 0);
        }
    }

    /// <summary>
    /// Get a random spawn position within the map bounds.
    /// </summary>
    public Vector3 GetRandomSpawnPosition()
    {
        float halfW = mapSize.x / 2f - 2f;
        float halfH = mapSize.y / 2f - 2f;

        return new Vector3(
            Random.Range(-halfW, halfW),
            0,
            Random.Range(-halfH, halfH)
        );
    }

    /// <summary>
    /// Get spawn position for a specific player index.
    /// </summary>
    public Vector3 GetSpawnPositionForPlayer(int playerIndex, int totalPlayers)
    {
        float halfW = mapSize.x / 2f - 2f;
        float halfH = mapSize.y / 2f - 2f;

        // Distribute players in a circle or line
        if (totalPlayers <= 4)
        {
            // Corners for 4 or less players
            switch (playerIndex % 4)
            {
                case 0: return new Vector3(-halfW + 1, 0, -halfH + 1);
                case 1: return new Vector3(halfW - 1, 0, -halfH + 1);
                case 2: return new Vector3(-halfW + 1, 0, halfH - 1);
                case 3: return new Vector3(halfW - 1, 0, halfH - 1);
            }
        }

        // Circle distribution for more players
        float angle = (playerIndex / (float)totalPlayers) * Mathf.PI * 2f;
        float radius = Mathf.Min(halfW, halfH) * 0.7f;
        return new Vector3(
            Mathf.Cos(angle) * radius,
            0,
            Mathf.Sin(angle) * radius
        );
    }
}
