using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Makes the camera follow the local player's pawn.
/// This ensures each client sees only their session's play area.
/// Attach to Main Camera or create via code.
/// </summary>
public class CameraFollowPawn : MonoBehaviour
{
    [Header("Follow Settings")]
    [SerializeField] private float height = 15f;
    [SerializeField] private float smoothSpeed = 5f;
    [SerializeField] private bool snapOnStart = true;
    [SerializeField] private float recheckSeconds = 1.5f;

    private Transform targetPawn;
    private bool initialized;
    private float nextRecheckTime;

    private void LateUpdate()
    {
        // CLIENT ONLY: Camera follow only makes sense on clients
        if (NetworkManager.Singleton == null || NetworkManager.Singleton.IsServer && !NetworkManager.Singleton.IsHost)
            return;

        if (!initialized)
        {
            TryFindLocalPawn();
            return;
        }

        if (targetPawn == null)
        {
            // Pawn may have been destroyed, try to find again
            initialized = false;
            return;
        }

        FollowTarget();
    }

    private void TryFindLocalPawn()
    {
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsClient)
            return;

        if (Time.time < nextRecheckTime)
            return;

        nextRecheckTime = Time.time + recheckSeconds;
        ulong localClientId = NetworkManager.Singleton.LocalClientId;

        // Find all PlayerPawn objects and look for ours
        targetPawn = FindLocalPawnTransform(FindObjectsByType<PlayerPawn>(FindObjectsSortMode.None), localClientId)
                     ?? FindLocalPawnTransform(FindObjectsByType<CirclePawn>(FindObjectsSortMode.None), localClientId)
                     ?? FindLocalNetworkObjectOwner(localClientId);

        if (targetPawn != null)
        {
            initialized = true;

            if (snapOnStart)
            {
                // Immediately snap camera to pawn position
                SnapToTarget();
            }

            Debug.Log($"[CameraFollowPawn] Found local pawn at {targetPawn.position}");
        }
        else
        {
            Debug.Log($"[CameraFollowPawn] No pawn found for client {localClientId}, retrying...");
        }
    }

    private void FollowTarget()
    {
        // Keep camera above the pawn (top-down view)
        Vector3 targetPos = new Vector3(targetPawn.position.x, height, targetPawn.position.z);
        
        // Smooth follow
        transform.position = Vector3.Lerp(transform.position, targetPos, smoothSpeed * Time.deltaTime);
    }

    private void SnapToTarget()
    {
        if (targetPawn != null)
        {
            transform.position = new Vector3(targetPawn.position.x, height, targetPawn.position.z);
        }
    }

    /// <summary>
    /// Manually set the target pawn (alternative to auto-find).
    /// </summary>
    public void SetTarget(Transform pawn)
    {
        targetPawn = pawn;
        initialized = true;
        if (snapOnStart)
        {
            SnapToTarget();
        }
    }

    private Transform FindLocalPawnTransform<T>(T[] pawns, ulong clientId) where T : NetworkBehaviour
    {
        foreach (var pawn in pawns)
        {
            if (pawn != null && pawn.OwnerClientId == clientId)
            {
                return pawn.transform;
            }
        }

        return null;
    }

    private Transform FindLocalNetworkObjectOwner(ulong clientId)
    {
        if (NetworkManager.Singleton == null || NetworkManager.Singleton.SpawnManager == null)
            return null;

        foreach (var pair in NetworkManager.Singleton.SpawnManager.SpawnedObjectsList)
        {
            var netObj = pair;
            if (netObj != null && netObj.OwnerClientId == clientId)
            {
                return netObj.transform;
            }
        }

        return null;
    }
}
