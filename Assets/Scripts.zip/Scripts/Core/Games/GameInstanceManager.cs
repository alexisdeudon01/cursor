using System;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Manages active game instances.
/// Each session can have one game running.
/// Supports multiple concurrent games (different sessions).
/// </summary>
public class GameInstanceManager : MonoBehaviour
{
    public static GameInstanceManager Instance { get; private set; }

    /// <summary>
    /// Event fired when a game instance is created.
    /// </summary>
    public static event Action<string, string> GameCreated; // sessionName, gameId

    /// <summary>
    /// Event fired when a game instance is destroyed.
    /// </summary>
    public static event Action<string> GameDestroyed; // sessionName

    // Active games: sessionName -> GameInstance
    private readonly Dictionary<string, GameInstance> activeGames = new Dictionary<string, GameInstance>();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    /// <summary>
    /// [SERVER] Create a new game instance for a session.
    /// </summary>
    /// <param name="sessionName">The session name</param>
    /// <param name="gameId">The game type ID from GameRegistry</param>
    /// <param name="playerData">List of (clientId, playerName) for all players</param>
    /// <param name="worldOffset">Offset for this session's isolated world</param>
    /// <returns>True if created successfully</returns>
    public bool CreateGame(string sessionName, string gameId, List<(ulong clientId, string name)> playerData, Vector3 worldOffset)
    {
        // SERVER ONLY
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsServer)
        {
            Debug.LogError("[GameInstanceManager] CreateGame called on client!");
            return false;
        }

        if (activeGames.ContainsKey(sessionName))
        {
            Debug.LogWarning($"[GameInstanceManager] Session '{sessionName}' already has an active game");
            return false;
        }

        var gameDef = GameRegistry.GetGame(gameId);
        if (gameDef == null)
        {
            Debug.LogError($"[GameInstanceManager] Game '{gameId}' not found in registry");
            return false;
        }

        Debug.Log($"[GameInstanceManager] CreateGame session='{sessionName}' gameId='{gameId}' players={playerData.Count} offset={worldOffset}");
        // Create game instance
        var instance = new GameInstance(sessionName, gameDef, worldOffset);
        activeGames[sessionName] = instance;

        // Setup game world
        gameDef.SetupGame(worldOffset);

        // Spawn pawns for all players
        instance.SpawnPlayers(playerData);

        Debug.Log($"[GameInstanceManager] Created game '{gameId}' for session '{sessionName}' with {playerData.Count} players");
        GameCreated?.Invoke(sessionName, gameId);

        return true;
    }

    /// <summary>
    /// [SERVER] Destroy a game instance.
    /// </summary>
    public void DestroyGame(string sessionName)
    {
        if (!NetworkManager.Singleton?.IsServer ?? true)
            return;

        if (activeGames.TryGetValue(sessionName, out var instance))
        {
            instance.Cleanup();
            activeGames.Remove(sessionName);
            Debug.Log($"[GameInstanceManager] Destroyed game for session '{sessionName}'");
            GameDestroyed?.Invoke(sessionName);

            var registryHub = Networking.StateSync.GlobalRegistryHub.Instance;
            if (registryHub != null)
            {
                var sessionEntry = registryHub.SessionRegistry.GetByName(sessionName);
                if (sessionEntry != null)
                {
                    registryHub.GameInstanceRegister.RemoveBySessionUid(sessionEntry.SessionUid);
                }
            }
        }
    }

    /// <summary>
    /// [SERVER] Add a player to an existing game (late joiner).
    /// </summary>
    public bool AddPlayerToGame(string sessionName, ulong clientId, string playerName)
    {
        if (!NetworkManager.Singleton?.IsServer ?? true)
            return false;

        if (!activeGames.TryGetValue(sessionName, out var instance))
        {
            Debug.LogWarning($"[GameInstanceManager] No active game for session '{sessionName}'");
            return false;
        }

        return instance.AddPlayer(clientId, playerName);
    }

    /// <summary>
    /// [SERVER] Get the game ID for an active session.
    /// </summary>
    public string GetGameId(string sessionName)
    {
        if (activeGames.TryGetValue(sessionName, out var instance))
            return instance.GameDefinition.GameId;
        return null;
    }

    /// <summary>
    /// [SERVER] Handle movement request from a player.
    /// </summary>
    public bool HandleMovement(string sessionName, ulong clientId, Vector2 direction, 
        out ulong pawnNetworkId, out Vector3 newPosition)
    {
        pawnNetworkId = 0;
        newPosition = Vector3.zero;

        if (!NetworkManager.Singleton?.IsServer ?? true)
            return false;

        if (!activeGames.TryGetValue(sessionName, out var instance))
            return false;

        return instance.HandleMovement(clientId, direction, out pawnNetworkId, out newPosition);
    }

    /// <summary>
    /// Get all player IDs in a session's game.
    /// </summary>
    public IReadOnlyList<ulong> GetPlayerIds(string sessionName)
    {
        if (activeGames.TryGetValue(sessionName, out var instance))
            return instance.GetPlayerIds();

        return Array.Empty<ulong>();
    }

    /// <summary>
    /// Get the game definition for a session.
    /// </summary>
    public IGameDefinition GetGameDefinition(string sessionName)
    {
        if (activeGames.TryGetValue(sessionName, out var instance))
            return instance.GameDefinition;
        return null;
    }

    /// <summary>
    /// Get a running game instance by session name.
    /// </summary>
    public bool TryGetInstance(string sessionName, out GameInstance instance)
    {
        return activeGames.TryGetValue(sessionName, out instance);
    }

    /// <summary>
    /// Check if a session has an active game.
    /// </summary>
    public bool HasActiveGame(string sessionName) => activeGames.ContainsKey(sessionName);

    /// <summary>
    /// Get the world offset for a session's active game.
    /// </summary>
    public bool TryGetWorldOffset(string sessionName, out Vector3 worldOffset)
    {
        if (activeGames.TryGetValue(sessionName, out var instance))
        {
            worldOffset = instance.WorldOffset;
            return true;
        }

        worldOffset = Vector3.zero;
        return false;
    }
}

/// <summary>
/// Represents a single running game instance.
/// </summary>
public class GameInstance
{
    public string SessionName { get; }
    public IGameDefinition GameDefinition { get; }
    public Vector3 WorldOffset { get; }

    private readonly Dictionary<ulong, PlayerGameState> players = new Dictionary<ulong, PlayerGameState>();

    public GameInstance(string sessionName, IGameDefinition gameDefinition, Vector3 worldOffset)
    {
        SessionName = sessionName;
        GameDefinition = gameDefinition;
        WorldOffset = worldOffset;
    }

    public void SpawnPlayers(List<(ulong clientId, string name)> playerData)
    {
        if (GameDefinition.PawnPrefab == null)
        {
            Debug.LogError($"[GameInstance] No pawn prefab for game {GameDefinition.GameId}");
            return;
        }

        Debug.Log($"[GameInstance] Spawning {playerData.Count} pawns for session '{SessionName}' using prefab='{GameDefinition.PawnPrefab.name}' offset={WorldOffset}");
        int totalPlayers = playerData.Count;
        for (int i = 0; i < playerData.Count; i++)
        {
            var (clientId, playerName) = playerData[i];

            // Get spawn position from game definition
            Vector3 spawnPos = GameDefinition.GetSpawnPosition(i, totalPlayers, WorldOffset);

            // Instantiate and spawn
            var instance = UnityEngine.Object.Instantiate(GameDefinition.PawnPrefab, spawnPos, Quaternion.identity);
            var netObj = instance.GetComponent<NetworkObject>();

            if (netObj == null)
            {
                Debug.LogError("[GameInstance] Pawn prefab missing NetworkObject!");
                UnityEngine.Object.Destroy(instance.gameObject);
                continue;
            }

            netObj.SpawnWithOwnership(clientId);
            Debug.Log($"[GameInstance] Spawned netObj={netObj.NetworkObjectId} owner={clientId} pos={spawnPos} scene={instance.gameObject.scene.name}");

            // Initialize via game definition
            GameDefinition.InitializePawn(netObj, playerName, i, WorldOffset);

            var container = GameSessionManager.Instance?.GetSecureContainer(SessionName);
            if (container != null)
            {
                container.RegisterPawn(clientId, netObj, playerName);
            }

            // Track player state
            players[clientId] = new PlayerGameState
            {
                ClientId = clientId,
                PlayerName = playerName,
                Pawn = netObj
            };
            
            // Notify all clients about pawn's session association for visibility filtering
            NotifyPawnSession(netObj.NetworkObjectId);

            Debug.Log($"[GameInstance] Spawned pawn for {playerName} at {spawnPos}");
        }
    }
    
    /// <summary>
    /// Notify clients about a pawn's session for visibility filtering.
    /// </summary>
    private void NotifyPawnSession(ulong pawnNetworkId)
    {
        if (SessionRpcHub.Instance != null && SessionRpcHub.Instance.IsSpawned)
        {
            SessionRpcHub.Instance.RegisterPawnSessionClientRpc(pawnNetworkId, SessionName);
        }
    }

    /// <summary>
    /// Add a late-joining player to the game.
    /// </summary>
    public bool AddPlayer(ulong clientId, string playerName)
    {
        if (players.ContainsKey(clientId))
        {
            Debug.Log($"[GameInstance] Player {clientId} already in game");
            return true; // Already in game
        }

        if (GameDefinition.PawnPrefab == null)
        {
            Debug.LogError($"[GameInstance] No pawn prefab for game {GameDefinition.GameId}");
            return false;
        }

        int playerIndex = players.Count;
        int totalPlayers = players.Count + 1;

        // Get spawn position for the new player
        Vector3 spawnPos = GameDefinition.GetSpawnPosition(playerIndex, totalPlayers, WorldOffset);

        // Instantiate and spawn
        var instance = UnityEngine.Object.Instantiate(GameDefinition.PawnPrefab, spawnPos, Quaternion.identity);
        var netObj = instance.GetComponent<NetworkObject>();

        if (netObj == null)
        {
            Debug.LogError("[GameInstance] Pawn prefab missing NetworkObject!");
            UnityEngine.Object.Destroy(instance.gameObject);
            return false;
        }

        netObj.SpawnWithOwnership(clientId);

        // Initialize via game definition
        GameDefinition.InitializePawn(netObj, playerName, playerIndex, WorldOffset);

        var container = GameSessionManager.Instance?.GetSecureContainer(SessionName);
        if (container != null)
        {
            container.RegisterPawn(clientId, netObj, playerName);
        }

        // Track player state
        players[clientId] = new PlayerGameState
        {
            ClientId = clientId,
            PlayerName = playerName,
            Pawn = netObj
        };
        
        // Notify all clients about pawn's session association for visibility filtering
        NotifyPawnSession(netObj.NetworkObjectId);

        Debug.Log($"[GameInstance] Added late joiner {playerName} (client {clientId}) at {spawnPos}");
        return true;
    }

    public bool HandleMovement(ulong clientId, Vector2 direction, out ulong pawnNetworkId, out Vector3 newPosition)
    {
        pawnNetworkId = 0;
        newPosition = Vector3.zero;

        if (!players.TryGetValue(clientId, out var state) || state.Pawn == null)
            return false;

        // Delegate to game definition
        GameDefinition.HandleMovement(state.Pawn, direction);

        pawnNetworkId = state.Pawn.NetworkObjectId;
        newPosition = state.Pawn.transform.position;
        return true;
    }

    public IReadOnlyList<ulong> GetPlayerIds()
    {
        return new List<ulong>(players.Keys);
    }

    public void Cleanup()
    {
        // Despawn all pawns
        foreach (var state in players.Values)
        {
            if (state.Pawn != null && state.Pawn.IsSpawned)
            {
                state.Pawn.Despawn();
            }
        }
        players.Clear();

        // Cleanup game definition
        GameDefinition.CleanupGame();
    }

    public IReadOnlyCollection<PlayerGameState> GetPlayerStates()
    {
        return players.Values;
    }
}

/// <summary>
/// Per-player state within a game instance.
/// </summary>
public class PlayerGameState
{
    public ulong ClientId;
    public string PlayerName;
    public NetworkObject Pawn;
}
