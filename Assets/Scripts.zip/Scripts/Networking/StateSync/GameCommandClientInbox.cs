using System;
using System.Collections.Generic;

namespace Networking.StateSync
{
    /// <summary>
    /// Unidirectional inbox for server->client GameCommandDto delivery.
    /// Keeps StateSync decoupled from the network hub implementation.
    /// </summary>
    public static class GameCommandClientInbox
    {
        public static event Action<GameCommandDto> CommandReceived;

        private static readonly Queue<GameCommandDto> pending = new Queue<GameCommandDto>();
        private const int PendingLimit = 128;

        public static void Publish(GameCommandDto command)
        {
            var handler = CommandReceived;
            if (handler == null)
            {
                Enqueue(command);
                return;
            }

            handler.Invoke(command);
        }

        public static void DrainPendingTo(Action<GameCommandDto> receiver)
        {
            if (receiver == null)
            {
                return;
            }

            while (pending.Count > 0)
            {
                receiver(pending.Dequeue());
            }
        }

        private static void Enqueue(GameCommandDto command)
        {
            if (pending.Count >= PendingLimit)
            {
                pending.Dequeue();
            }

            pending.Enqueue(command);
        }
    }
}

