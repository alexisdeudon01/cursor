using System;
using System.Collections.Generic;

namespace Networking.StateSync
{
    /// <summary>
    /// Unidirectional outbox for client->server GameCommandDto requests.
    /// A network layer adapter (e.g. SessionRpcHub) is responsible for listening and sending the RPC.
    /// </summary>
    public static class GameCommandServerOutbox
    {
        public static event Action<GameCommandDto> CommandRequested;

        private static readonly Queue<GameCommandDto> pending = new Queue<GameCommandDto>();
        private const int PendingLimit = 128;

        public static void RequestSend(GameCommandDto command)
        {
            var handler = CommandRequested;
            if (handler == null)
            {
                Enqueue(command);
                return;
            }

            handler.Invoke(command);
        }

        public static void DrainPendingTo(Action<GameCommandDto> sender)
        {
            if (sender == null)
            {
                return;
            }

            while (pending.Count > 0)
            {
                sender(pending.Dequeue());
            }
        }

        private static void Enqueue(GameCommandDto command)
        {
            if (pending.Count >= PendingLimit)
            {
                pending.Dequeue();
            }

            pending.Enqueue(command);
        }
    }
}

