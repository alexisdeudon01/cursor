using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;
using System.IO;

/// <summary>
/// Repair tool to fix Menu.unity scene corruption.
/// This script removes broken prefab references and rebuilds the scene structure.
/// Menu: Tools > Repair Menu Scene
/// </summary>
public class RepairMenuScene : EditorWindow
{
    [MenuItem("Tools/Repair Menu Scene", priority = 100)]
    public static void RepairMenu()
    {
        if (!EditorUtility.DisplayDialog("Repair Menu Scene",
            "This will fix broken prefab references in Menu.unity.\n\n" +
            "The scene will be rebuilt with:\n" +
            "- Main Camera\n" +
            "- NetworkManagerRoot prefab\n" +
            "- NetworkBootstrapUI prefab\n" +
            "- Menu prefab (with ConnectionUI)\n\n" +
            "Continue?",
            "Yes, Repair", "Cancel"))
        {
            return;
        }

        string scenePath = "Assets/Scenes/Menu.unity";
        
        // Save current work
        EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();

        try
        {
            // Create new empty scene
            var newScene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            
            Debug.Log("[RepairMenuScene] Creating fresh Menu scene...");

            // 1. Add Main Camera
            var cameraGO = new GameObject("Main Camera");
            cameraGO.tag = "MainCamera";
            var camera = cameraGO.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.white;
            camera.orthographic = false;
            camera.fieldOfView = 60f;
            camera.nearClipPlane = 0.3f;
            camera.farClipPlane = 1000f;
            cameraGO.AddComponent<AudioListener>();
            cameraGO.transform.position = new Vector3(0, 0, -10);
            Debug.Log("  ✓ Created Main Camera");

            // 2. Add NetworkManagerRoot prefab
            var networkManagerPrefab = FindPrefab("NetworkManagerRoot");
            if (networkManagerPrefab != null)
            {
                PrefabUtility.InstantiatePrefab(networkManagerPrefab);
                Debug.Log("  ✓ Added NetworkManagerRoot");
            }
            else
            {
                Debug.LogWarning("  ⚠️ NetworkManagerRoot prefab not found");
            }

            // 3. Add NetworkBootstrapUI prefab
            var bootstrapUIPrefab = FindPrefab("NetworkBootstrapUI");
            if (bootstrapUIPrefab != null)
            {
                PrefabUtility.InstantiatePrefab(bootstrapUIPrefab);
                Debug.Log("  ✓ Added NetworkBootstrapUI");
            }
            else
            {
                Debug.LogWarning("  ⚠️ NetworkBootstrapUI prefab not found");
            }

            // 4. Add Menu prefab (ConnectionUI)
            var menuPrefab = FindPrefab("Menu");
            if (menuPrefab != null)
            {
                PrefabUtility.InstantiatePrefab(menuPrefab);
                Debug.Log("  ✓ Added Menu prefab (ConnectionUI)");
            }
            else
            {
                Debug.LogWarning("  ⚠️ Menu prefab not found - creating manually");
                CreateMenuUIManually();
            }

            // 5. Add ClientBootstrap GameObject (not a prefab)
            var clientBootstrap = new GameObject("ClientBootstrap");
            clientBootstrap.AddComponent<ClientBootstrap>();
            Debug.Log("  ✓ Created ClientBootstrap");

            // Save the repaired scene
            EditorSceneManager.SaveScene(newScene, scenePath);
            Debug.Log($"[RepairMenuScene] ✅ Scene saved to: {scenePath}");

            EditorUtility.DisplayDialog("Repair Complete",
                "Menu.unity has been successfully repaired!\n\n" +
                "Components added:\n" +
                "- Main Camera\n" +
                "- NetworkManagerRoot\n" +
                "- NetworkBootstrapUI\n" +
                "- Menu (ConnectionUI)\n" +
                "- ClientBootstrap\n\n" +
                "The scene is now ready to use.",
                "OK");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"[RepairMenuScene] Error: {ex.Message}\n{ex.StackTrace}");
            EditorUtility.DisplayDialog("Repair Failed",
                $"Failed to repair scene:\n{ex.Message}",
                "OK");
        }
    }

    private static void CreateMenuUIManually()
    {
        var menuUI = new GameObject("Menu");
        menuUI.tag = "Menu";
        
        var uiDoc = menuUI.AddComponent<UIDocument>();
        
        // Find ConnectionUI.uxml
        var connectionUxml = FindUxml("ConnectionUI");
        if (connectionUxml != null)
        {
            uiDoc.visualTreeAsset = connectionUxml;
            Debug.Log("    - Assigned ConnectionUI.uxml");
        }
        
        // Find PanelSettings
        var panelSettings = FindPanelSettings();
        if (panelSettings != null)
        {
            uiDoc.panelSettings = panelSettings;
            Debug.Log("    - Assigned PanelSettings");
        }
        
        // Add ConnectionUIController
        menuUI.AddComponent<ConnectionUIController>();
        Debug.Log("    - Added ConnectionUIController");
    }

    private static GameObject FindPrefab(string name)
    {
        string[] guids = AssetDatabase.FindAssets($"t:Prefab {name}");
        foreach (var guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab != null && prefab.name == name)
                return prefab;
        }
        return null;
    }

    private static VisualTreeAsset FindUxml(string name)
    {
        string[] guids = AssetDatabase.FindAssets($"t:VisualTreeAsset {name}");
        foreach (var guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var uxml = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(path);
            if (uxml != null && uxml.name == name)
                return uxml;
        }
        return null;
    }

    private static PanelSettings FindPanelSettings()
    {
        string[] guids = AssetDatabase.FindAssets("t:PanelSettings");
        foreach (var guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var settings = AssetDatabase.LoadAssetAtPath<PanelSettings>(path);
            if (settings != null)
                return settings;
        }
        return null;
    }
}
