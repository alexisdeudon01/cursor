using System;
using System.Collections;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;

/// <summary>
/// Server-only bootstrap. This script should only exist in the Server scene.
/// Automatically starts the dedicated server on scene load.
/// </summary>
public class ServerBootstrap : MonoBehaviour
{
    public static ServerBootstrap Instance { get; private set; }

    [Header("Server Settings")]
    [SerializeField] private ushort defaultPort = 7777;
    [SerializeField] private int maxPlayers = 16;

    [Header("Network Prefabs")]
    [SerializeField] private NetworkObject sessionRpcHubPrefab;

    private NetworkManager networkManager;
    private UnityTransport transport;
    private ushort serverPort;
    private float startTime;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        ParseCommandLine();
        InitializeLogging();
    }

    private void Start()
    {
        startTime = Time.realtimeSinceStartup;
        StartCoroutine(StartServerDelayed());
    }

    private void ParseCommandLine()
    {
        serverPort = defaultPort;

        string[] args = Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length; i++)
        {
            string arg = args[i].ToLower();
            if ((arg == "-port" || arg == "--port") && i + 1 < args.Length)
            {
                if (ushort.TryParse(args[i + 1], out ushort port))
                {
                    serverPort = port;
                }
            }
            else if ((arg == "-maxplayers" || arg == "--maxplayers") && i + 1 < args.Length)
            {
                if (int.TryParse(args[i + 1], out int max))
                {
                    maxPlayers = max;
                }
            }
        }
    }

    private void InitializeLogging()
    {
        // Disable stack traces for cleaner console output
        Application.SetStackTraceLogType(LogType.Log, StackTraceLogType.None);
        Application.SetStackTraceLogType(LogType.Warning, StackTraceLogType.None);
        Application.SetStackTraceLogType(LogType.Error, StackTraceLogType.ScriptOnly);
        Application.SetStackTraceLogType(LogType.Exception, StackTraceLogType.ScriptOnly);

        Log("========================================");
        Log("  DEDICATED SERVER");
        Log("========================================");
        Log($"Unity Version: {Application.unityVersion}");
        Log($"Platform: {Application.platform}");
        Log($"Port: {serverPort}");
        Log($"Max Players: {maxPlayers}");
        Log("========================================");
    }

    private IEnumerator StartServerDelayed()
    {
        yield return new WaitForSeconds(0.5f);

        // Get or create NetworkManager
        networkManager = NetworkManager.Singleton;
        if (networkManager == null)
        {
            LogError("NetworkManager.Singleton is null!");
            yield break;
        }

        transport = networkManager.GetComponent<UnityTransport>();
        if (transport == null)
        {
            LogError("UnityTransport not found!");
            yield break;
        }

        // Force UDP (no WebSockets/TLS) for the game transport.
        transport.UseWebSockets = false;
        transport.UseEncryption = false;

        // Configure transport for server listening
        transport.ConnectionData.Port = serverPort;
        transport.ConnectionData.ServerListenAddress = "0.0.0.0"; // Listen on all interfaces
        
        Log($"Server will listen on 0.0.0.0:{serverPort}");

        // Create GameSessionManager
        EnsureGameSessionManager();
        Networking.StateSync.GlobalRegistryHub.EnsureInstance();

        // Start server
        Log($"Starting server on port {serverPort}...");
        
        if (!networkManager.StartServer())
        {
            LogError("Failed to start server!");
            yield break;
        }

        Log("SERVER STARTED");

        // Spawn SessionRpcHub
        yield return new WaitForSeconds(0.2f);
        SpawnSessionRpcHub();

        // Subscribe to events
        networkManager.OnClientConnectedCallback += OnClientConnected;
        networkManager.OnClientDisconnectCallback += OnClientDisconnected;

        // Start stats logging
        StartCoroutine(LogStats());
    }

    private void EnsureGameSessionManager()
    {
        if (GameSessionManager.Instance == null)
        {
            var go = new GameObject("GameSessionManager");
            go.AddComponent<GameSessionManager>();
            Log("Created GameSessionManager");
        }
    }

    private void SpawnSessionRpcHub()
    {
        if (SessionRpcHub.Instance != null)
        {
            Log("SessionRpcHub already exists");
            return;
        }

        if (sessionRpcHubPrefab == null)
        {
            LogError("SessionRpcHub prefab not assigned!");
            return;
        }

        var hub = Instantiate(sessionRpcHubPrefab);
        hub.Spawn();
        Log("✅ SessionRpcHub spawned");
    }

    private void OnClientConnected(ulong clientId)
    {
        int count = networkManager.ConnectedClientsIds.Count;
        Log($"[+] Client {clientId} connected (Total: {count}/{maxPlayers})");
    }

    private void OnClientDisconnected(ulong clientId)
    {
        int count = networkManager.ConnectedClientsIds.Count - 1;
        Log($"[-] Client {clientId} disconnected (Total: {count}/{maxPlayers})");
    }

    private IEnumerator LogStats()
    {
        while (true)
        {
            yield return new WaitForSeconds(60f);

            if (networkManager == null || !networkManager.IsServer)
                continue;

            int players = networkManager.ConnectedClientsIds?.Count ?? 0;
            int sessions = GameSessionManager.Instance?.GetSessionsSnapshot()?.Length ?? 0;
            float uptime = Time.realtimeSinceStartup - startTime;

            Log($"[STATS] Players: {players}/{maxPlayers} | Sessions: {sessions} | Uptime: {FormatTime(uptime)}");
        }
    }

    private string FormatTime(float seconds)
    {
        TimeSpan ts = TimeSpan.FromSeconds(seconds);
        if (ts.TotalHours >= 1)
            return $"{(int)ts.TotalHours}h {ts.Minutes}m";
        return $"{ts.Minutes}m {ts.Seconds}s";
    }

    private void OnApplicationQuit()
    {
        float uptime = Time.realtimeSinceStartup - startTime;
        Log("========================================");
        Log($"  SERVER SHUTDOWN (Uptime: {FormatTime(uptime)})");
        Log("========================================");
    }

    #region Logging

    public static void Log(string message)
    {
        string timestamp = DateTime.Now.ToString("HH:mm:ss");
        string formatted = $"[{timestamp}] {message}";
        Debug.Log(formatted);
    }

    public static void LogWarning(string message)
    {
        string timestamp = DateTime.Now.ToString("HH:mm:ss");
        string formatted = $"[{timestamp}] [WARN] {message}";
        Debug.LogWarning(formatted);
    }

    public static void LogError(string message)
    {
        string timestamp = DateTime.Now.ToString("HH:mm:ss");
        string formatted = $"[{timestamp}] [ERROR] {message}";
        Debug.LogError(formatted);
    }

    // For other scripts to log to server
    public static void LogSession(string action, string sessionName, ulong clientId = 0)
    {
        if (clientId > 0)
            Log($"[SESSION] {action}: {sessionName} (Client {clientId})");
        else
            Log($"[SESSION] {action}: {sessionName}");
    }

    public static void LogGame(string action, string sessionName, int playerCount = 0)
    {
        if (playerCount > 0)
            Log($"[GAME] {action}: {sessionName} ({playerCount} players)");
        else
            Log($"[GAME] {action}: {sessionName}");
    }

    #endregion
}
