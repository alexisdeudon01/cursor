using System;
using System.Collections.Generic;
using UnityEngine;

namespace Core.Games
{
    /// <summary>
    /// Isolated container for a single game session.
    /// Ensures complete data isolation between sessions.
    ///
    /// Data-oriented refactor (Option 1):
    /// - SessionContainer no longer tracks per-player NetworkObjects.
    /// - The authoritative simulation state lives in GameInstanceManager.
    /// </summary>
    public class SessionContainer : IDisposable
    {
        // ============================================
        //   IDENTIFICATION
        // ============================================

        public string SessionName { get; }
        public string SessionId { get; }
        public Vector3 WorldOffset { get; }
        public DateTime CreatedAt { get; }

        // ============================================
        //   PLAYER MANAGEMENT (Isolated)
        // ============================================

        private readonly Dictionary<ulong, SessionPlayer> players = new Dictionary<ulong, SessionPlayer>();
        private readonly object playerLock = new object();

        public ulong HostClientId { get; private set; }
        public int PlayerCount => players.Count;
        public int MaxPlayers { get; set; } = 8;

        // ============================================
        //   GAME STATE (Isolated)
        // ============================================

        public enum SessionState { Lobby, Starting, InGame, Ended }
        public SessionState State { get; private set; } = SessionState.Lobby;

        public string GameId { get; private set; }
        public IGameDefinition GameDefinition { get; private set; }

        // ============================================
        //   CONSTRUCTOR
        // ============================================

        public SessionContainer(string sessionName, Vector3 worldOffset)
        {
            SessionName = sessionName;
            SessionId = Guid.NewGuid().ToString();
            WorldOffset = worldOffset;
            CreatedAt = DateTime.Now;

            Debug.Log($"[SessionContainer] Created session '{sessionName}' at offset {worldOffset}");
        }

        public void Dispose()
        {
            EndGame();
            lock (playerLock)
            {
                players.Clear();
            }
        }

        // ============================================
        //   PLAYER METHODS
        // ============================================

        public bool AddPlayer(ulong clientId, string playerName, bool isHost = false)
        {
            lock (playerLock)
            {
                if (players.ContainsKey(clientId))
                    return false;

                if (players.Count >= MaxPlayers)
                    return false;

                players[clientId] = new SessionPlayer(clientId, playerName);

                if (isHost || players.Count == 1)
                    HostClientId = clientId;

                Debug.Log($"[SessionContainer] Player '{playerName}' ({clientId}) joined session '{SessionName}'");
                return true;
            }
        }

        public bool RemovePlayer(ulong clientId)
        {
            lock (playerLock)
            {
                if (!players.TryGetValue(clientId, out var player))
                    return false;

                players.Remove(clientId);
                Debug.Log($"[SessionContainer] Player '{player.PlayerName}' ({clientId}) left session '{SessionName}'");

                // If host left, transfer to first remaining player.
                if (HostClientId == clientId)
                {
                    HostClientId = 0;
                    foreach (var kvp in players)
                    {
                        HostClientId = kvp.Key;
                        Debug.Log($"[SessionContainer] Host transferred to client {HostClientId} in session '{SessionName}'");
                        break;
                    }
                }

                return true;
            }
        }

        public bool HasPlayer(ulong clientId)
        {
            lock (playerLock)
                return players.ContainsKey(clientId);
        }

        public SessionPlayer GetPlayer(ulong clientId)
        {
            lock (playerLock)
            {
                players.TryGetValue(clientId, out var player);
                return player;
            }
        }

        public List<ulong> GetPlayerIds()
        {
            lock (playerLock)
                return new List<ulong>(players.Keys);
        }

        public List<SessionPlayer> GetAllPlayers()
        {
            lock (playerLock)
                return new List<SessionPlayer>(players.Values);
        }

        // ============================================
        //   GAME CONTROL METHODS
        // ============================================

        public bool StartGame(string gameId, IGameDefinition gameDef)
        {
            if (State != SessionState.Lobby)
            {
                Debug.LogWarning($"[SessionContainer] Cannot start game: session '{SessionName}' is not in Lobby state.");
                return false;
            }

            GameId = gameId;
            GameDefinition = gameDef;
            State = SessionState.Starting;

            Debug.Log($"[SessionContainer] Starting game '{gameId}' in session '{SessionName}'");
            return true;
        }

        public void SetGameRunning()
        {
            if (State == SessionState.Starting)
            {
                State = SessionState.InGame;
                Debug.Log($"[SessionContainer] Session '{SessionName}' is now InGame");
            }
        }

        public void EndGame()
        {
            if (State == SessionState.Lobby)
                return;

            try
            {
                GameDefinition?.CleanupGame();
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[SessionContainer] CleanupGame exception for session '{SessionName}': {ex.Message}");
            }

            GameId = null;
            GameDefinition = null;
            State = SessionState.Ended;

            Debug.Log($"[SessionContainer] Game ended in session '{SessionName}'");
        }

        // ============================================
        //   BOUNDS / SAFETY
        // ============================================

        public bool ValidatePositionInBounds(Vector3 position)
        {
            // NOTE: This validation is about session world partitioning, NOT map bounds.
            // It can be used as a coarse-grained safety check when many sessions exist in one world.
            float halfSpace = 25f;
            float padding = 2f;

            Vector3 min = WorldOffset + new Vector3(-halfSpace + padding, -10f, -halfSpace + padding);
            Vector3 max = WorldOffset + new Vector3(halfSpace - padding, 10f, halfSpace - padding);

            return position.x >= min.x && position.x <= max.x &&
                   position.z >= min.z && position.z <= max.z;
        }
    }
}
