using System.Collections.Generic;
using Networking.StateSync;
using Unity.Collections;
using UnityEngine;

namespace Core.Simulation
{
    /// <summary>
    /// Simple SoA-style world used by the server-authoritative simulation.
    /// 
    /// Entities are dense (swap-remove) and indexed by an int id.
    /// </summary>
    public sealed class SimWorld
    {
        private int nextEntityId = 1;

        // Dense entity storage (SoA)
        private readonly List<int> entityIds = new List<int>(16);
        private readonly List<byte> prefabTypes = new List<byte>(16);
        private readonly List<ulong> ownerClientIds = new List<ulong>(16);
        private readonly List<FixedString64Bytes> ownerClientUids = new List<FixedString64Bytes>(16);
        private readonly List<FixedString64Bytes> displayNames = new List<FixedString64Bytes>(16);
        private readonly List<int> colorIndices = new List<int>(16);
        private readonly List<Vector3> positions = new List<Vector3>(16);
        private readonly List<Quaternion> rotations = new List<Quaternion>(16);
        private readonly List<Vector2> inputs = new List<Vector2>(16);

        // Lookups
        private readonly Dictionary<int, int> idToIndex = new Dictionary<int, int>(16);
        private readonly Dictionary<ulong, int> ownerToEntityId = new Dictionary<ulong, int>(16);

        // Dirty tracking (entity id)
        private readonly HashSet<int> dirty = new HashSet<int>();

        public int Count => entityIds.Count;

        public bool IsDirty => dirty.Count > 0;

        public void ClearDirty()
        {
            dirty.Clear();
        }

        public bool TryGetEntityIdForOwner(ulong ownerClientId, out int entityId)
        {
            return ownerToEntityId.TryGetValue(ownerClientId, out entityId);
        }

        public int SpawnPlayerEntity(
            ulong ownerClientId,
            FixedString64Bytes ownerClientUid,
            FixedString64Bytes displayName,
            int colorIndex,
            byte prefabType,
            Vector3 position,
            Quaternion rotation)
        {
            var entityId = nextEntityId++;
            var index = entityIds.Count;

            entityIds.Add(entityId);
            prefabTypes.Add(prefabType);
            ownerClientIds.Add(ownerClientId);
            ownerClientUids.Add(ownerClientUid);
            displayNames.Add(displayName);
            colorIndices.Add(colorIndex);
            positions.Add(position);
            rotations.Add(rotation);
            inputs.Add(Vector2.zero);

            idToIndex[entityId] = index;
            ownerToEntityId[ownerClientId] = entityId;

            return entityId;
        }

        public bool RemoveEntity(int entityId)
        {
            if (!idToIndex.TryGetValue(entityId, out var index))
            {
                return false;
            }

            // Remove owner mapping
            var owner = ownerClientIds[index];
            if (ownerToEntityId.TryGetValue(owner, out var mappedId) && mappedId == entityId)
            {
                ownerToEntityId.Remove(owner);
            }

            var lastIndex = entityIds.Count - 1;
            if (index != lastIndex)
            {
                // Swap last -> index
                entityIds[index] = entityIds[lastIndex];
                prefabTypes[index] = prefabTypes[lastIndex];
                ownerClientIds[index] = ownerClientIds[lastIndex];
                ownerClientUids[index] = ownerClientUids[lastIndex];
                displayNames[index] = displayNames[lastIndex];
                colorIndices[index] = colorIndices[lastIndex];
                positions[index] = positions[lastIndex];
                rotations[index] = rotations[lastIndex];
                inputs[index] = inputs[lastIndex];

                // Fix lookup for swapped entity
                var swappedEntityId = entityIds[index];
                idToIndex[swappedEntityId] = index;

                // Fix owner mapping for swapped entity
                var swappedOwner = ownerClientIds[index];
                ownerToEntityId[swappedOwner] = swappedEntityId;
            }

            // Remove last
            entityIds.RemoveAt(lastIndex);
            prefabTypes.RemoveAt(lastIndex);
            ownerClientIds.RemoveAt(lastIndex);
            ownerClientUids.RemoveAt(lastIndex);
            displayNames.RemoveAt(lastIndex);
            colorIndices.RemoveAt(lastIndex);
            positions.RemoveAt(lastIndex);
            rotations.RemoveAt(lastIndex);
            inputs.RemoveAt(lastIndex);

            idToIndex.Remove(entityId);
            dirty.Remove(entityId);

            return true;
        }

        public void SetInput(ulong ownerClientId, Vector2 direction)
        {
            if (!ownerToEntityId.TryGetValue(ownerClientId, out var entityId))
            {
                return;
            }

            if (!idToIndex.TryGetValue(entityId, out var index))
            {
                return;
            }

            inputs[index] = direction;
        }

        public void Step(float dt, float moveSpeed, MapConfigData mapConfig, float clampMargin = 0.6f)
        {
            if (mapConfig == null)
            {
                return;
            }

            for (int i = 0; i < positions.Count; i++)
            {
                var dir = inputs[i];
                if (dir.sqrMagnitude < 0.0001f)
                {
                    continue;
                }

                // Normalize to avoid faster diagonal movement
                if (dir.sqrMagnitude > 1f)
                {
                    dir = dir.normalized;
                }

                var delta = new Vector3(dir.x, 0f, dir.y) * moveSpeed * dt;
                var current = positions[i];
                var next = current + delta;

                next = ClampToMap(next, mapConfig, clampMargin);

                if ((next - current).sqrMagnitude > 0.000001f)
                {
                    positions[i] = next;
                    dirty.Add(entityIds[i]);

                    // Optional: rotate to face movement direction (kept for completeness)
                    // rotations[i] = Quaternion.LookRotation(new Vector3(dir.x, 0f, dir.y), Vector3.up);
                }
            }
        }

        public void GetEntityDataById(int entityId,
            out byte prefabType,
            out ulong ownerClientId,
            out FixedString64Bytes ownerClientUid,
            out FixedString64Bytes displayName,
            out int colorIndex,
            out Vector3 position,
            out Quaternion rotation)
        {
            if (!idToIndex.TryGetValue(entityId, out var index))
            {
                prefabType = 0;
                ownerClientId = 0;
                ownerClientUid = default;
                displayName = default;
                colorIndex = 0;
                position = Vector3.zero;
                rotation = Quaternion.identity;
                return;
            }

            prefabType = prefabTypes[index];
            ownerClientId = ownerClientIds[index];
            ownerClientUid = ownerClientUids[index];
            displayName = displayNames[index];
            colorIndex = colorIndices[index];
            position = positions[index];
            rotation = rotations[index];
        }

        public void CollectDirtyEntityIds(List<int> results)
        {
            results.Clear();
            foreach (var entityId in dirty)
            {
                results.Add(entityId);
            }
        }

        public void CollectAllEntityIds(List<int> results)
        {
            results.Clear();
            for (int i = 0; i < entityIds.Count; i++)
            {
                results.Add(entityIds[i]);
            }
        }

        public static Vector3 ClampToMap(Vector3 position, MapConfigData mapConfig, float margin)
        {
            if (mapConfig == null)
            {
                return position;
            }

            var offset = mapConfig.worldOffset;

            if ((MapShape)mapConfig.shape == MapShape.Circle)
            {
                var radius = Mathf.Max(0f, mapConfig.circleRadius - margin);
                var dx = position.x - offset.x;
                var dz = position.z - offset.z;
                var dist = Mathf.Sqrt((dx * dx) + (dz * dz));

                if (dist > radius && dist > 0.0001f)
                {
                    var scale = radius / dist;
                    position.x = offset.x + (dx * scale);
                    position.z = offset.z + (dz * scale);
                }

                position.y = offset.y;
                return position;
            }

            // Rect (default)
            var size = mapConfig.mapSize;
            var halfW = Mathf.Max(0f, Mathf.Abs(size.x) * 0.5f - margin);
            var halfH = Mathf.Max(0f, Mathf.Abs(size.z) * 0.5f - margin);

            position.x = Mathf.Clamp(position.x, offset.x - halfW, offset.x + halfW);
            position.z = Mathf.Clamp(position.z, offset.z - halfH, offset.z + halfH);
            position.y = offset.y;
            return position;
        }
    }
}
