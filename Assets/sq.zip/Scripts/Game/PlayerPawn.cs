using TMPro;
using Unity.Collections;
using UnityEngine;

/// <summary>
/// Square pawn view.
/// 
/// Data-oriented refactor (Option 1): this is a pure client-side visual.
/// The server simulates movement and replicates the transform via DTO commands.
/// </summary>
public class PlayerPawn : MonoBehaviour
{
    [Header("Visual Settings")]
    [SerializeField] private float pawnSize = 1.0f;

    [SerializeField]
    private Color[] playerColors =
    {
        Color.red,
        Color.blue,
        Color.green,
        Color.yellow,
        Color.magenta,
        Color.cyan,
        new Color(1f, 0.5f, 0f),
        Color.white
    };

    [Header("Name Display")]
    [SerializeField] private Vector3 nameOffset = new Vector3(0f, 1.5f, 0f);
    [SerializeField] private float nameFontSize = 3f;
    [SerializeField] private Color nameColor = Color.white;

    public ulong OwnerClientId { get; private set; }
    public FixedString64Bytes PlayerName { get; private set; }
    public int ColorIndex { get; private set; }

    private MeshRenderer meshRenderer;
    private TextMeshPro nameLabel;

    private void Awake()
    {
        EnsureVisuals();
    }

    public void ApplySpawnData(ulong ownerClientId, FixedString64Bytes playerName, int colorIndex)
    {
        OwnerClientId = ownerClientId;
        PlayerName = playerName;
        ColorIndex = colorIndex;

        EnsureVisuals();
        ApplyColor();
        UpdateNameDisplay();
    }

    private void EnsureVisuals()
    {
        if (meshRenderer == null)
            CreateSquareVisual();

        if (nameLabel == null)
            CreateNameLabel();
    }

    private void CreateSquareVisual()
    {
        var squareObj = new GameObject("SquareVisual");
        squareObj.transform.SetParent(transform, false);
        squareObj.transform.localPosition = Vector3.up * 0.01f; // slight lift to avoid z-fighting

        var meshFilter = squareObj.AddComponent<MeshFilter>();
        meshRenderer = squareObj.AddComponent<MeshRenderer>();
        meshFilter.mesh = BuildQuadMesh(pawnSize);

        var shader = Shader.Find("Unlit/Color") ?? Shader.Find("Standard");
        meshRenderer.material = new Material(shader);
    }

    private static Mesh BuildQuadMesh(float size)
    {
        float half = size * 0.5f;

        var mesh = new Mesh
        {
            vertices = new[]
            {
                new Vector3(-half, 0f, -half),
                new Vector3( half, 0f, -half),
                new Vector3( half, 0f,  half),
                new Vector3(-half, 0f,  half)
            },
            uv = new[]
            {
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(1f, 1f),
                new Vector2(0f, 1f)
            },
            triangles = new[] { 0, 2, 1, 0, 3, 2 }
        };

        mesh.RecalculateNormals();
        return mesh;
    }

    private void CreateNameLabel()
    {
        var nameObj = new GameObject("NameLabel");
        nameObj.transform.SetParent(transform, false);
        nameObj.transform.localPosition = nameOffset;

        nameLabel = nameObj.AddComponent<TextMeshPro>();
        nameLabel.alignment = TextAlignmentOptions.Center;
        nameLabel.fontSize = nameFontSize;
        nameLabel.color = nameColor;
        nameLabel.sortingOrder = 10;

        UpdateNameDisplay();
    }

    private void ApplyColor()
    {
        if (meshRenderer == null)
            return;

        if (playerColors != null && playerColors.Length > 0)
        {
            var color = playerColors[Mathf.Abs(ColorIndex) % playerColors.Length];
            meshRenderer.material.color = color;
        }
    }

    private void UpdateNameDisplay()
    {
        if (nameLabel != null)
            nameLabel.text = PlayerName.ToString();
    }

    private void LateUpdate()
    {
        // Billboard the name toward the camera.
        if (nameLabel != null && Camera.main != null)
        {
            var toCam = Camera.main.transform.position - nameLabel.transform.position;
            if (toCam.sqrMagnitude > 0.0001f)
                nameLabel.transform.rotation = Quaternion.LookRotation(toCam);
        }
    }
}
