```mermaid
%% Diagramme ER - Données serveur (sessions, états, commandes)
erDiagram
    PLAYER_REGISTRY {
        string PlayerEntityId PK
        ulong NetworkClientId
        string DisplayName
    }

    SESSION {
        string SessionUid PK
        string Name
        string GameTypeUid FK
        string State
        Vector3 WorldOffset
        datetime CreatedAt
    }

    SESSION_MEMBER {
        string SessionUid PK
        string PlayerEntityId PK
        bool IsReady
        bool IsHost
        datetime JoinedAt
    }

    SESSION_COMMAND_QUEUE {
        string SessionUid PK
        int OrderIndex PK
        string CommandType
        string PayloadJson
        string EnqueuedByPlayerEntityId FK
        datetime EnqueuedAt
    }

    GAME_DEFINITION {
        string GameTypeUid PK
        string DisplayName
        int MinPlayers
        int MaxPlayers
        json Config
    }

    GAME_INSTANCE {
        string GameInstanceUid PK
        string SessionUid FK
        int CurrentVersion
    }

    GAME_ENTITY_STATE {
        string GameInstanceUid PK
        string EntityId PK
        int Version PK
        string OwnerPlayerEntityId FK
        string EntityType
        Vector3 Position
        Quaternion Rotation
    }

    GAME_STATE_SNAPSHOT {
        string GameInstanceUid PK
        int Version PK
        datetime CapturedAt
    }

    GAME_STATE_DIFF {
        string GameInstanceUid PK
        int FromVersion PK
        int ToVersion PK
        datetime CapturedAt
    }

    %% Relations principales
    PLAYER_REGISTRY ||--o{ SESSION_MEMBER : joins
    SESSION ||--o{ SESSION_MEMBER : contains

    SESSION ||--|{ SESSION_COMMAND_QUEUE : buffers
    PLAYER_REGISTRY ||--o{ SESSION_COMMAND_QUEUE : enqueues

    SESSION }o--|| GAME_DEFINITION : selects
    SESSION ||--|| GAME_INSTANCE : runs

    GAME_INSTANCE ||--o{ GAME_STATE_SNAPSHOT : checkpoints
    GAME_INSTANCE ||--o{ GAME_STATE_DIFF : deltas

    GAME_STATE_SNAPSHOT ||--o{ GAME_ENTITY_STATE : contains
    GAME_STATE_DIFF ||--o{ GAME_ENTITY_STATE : updates

    %% Notes:
    %% - SESSION.State valeurs: Lobby | Starting | InGame | Ended
    %% - SESSION_COMMAND_QUEUE.CommandType exemples: MovePlayerCommand, etc.
    %% - PayloadJson contient le GameCommandDto sérialisé
    %% - PLAYER_REGISTRY.PlayerEntityId correspond au ClientUid (ClientRegistry) et dérive de NetworkClient (ClientNode : NetworkClient)
```
