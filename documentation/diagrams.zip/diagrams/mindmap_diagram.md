```mermaid
%% Mindmap - Cycle de Jeu
mindmap
  root((Session de Jeu))
    Lobby
      Creation
      Rejoindre
      Pret
    Demarrage
      Validation
      ChargementScene
      SpawnPions
    EnJeu
      Commandes
      SyncEtat
      Deplacement
    Fin
      Scores
      RetourLobby
```
