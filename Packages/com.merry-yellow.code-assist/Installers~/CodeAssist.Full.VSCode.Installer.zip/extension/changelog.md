# Change Log

## [1.4.19]
* AGENTS.md support for AI coding agents, copilot-instructions.md support is deprecated
* Visual Studio 2026 compatibility
* Bugfix for completions and inline visuals for sorting layer related members
* Can unspecify max_tokens,temperature and top_p in the gpt request options
* Gpt libraries and models are updated

## [1.4.18]
* New code completions: Material/Shader
* New inline visuals: Material/Shader
* Bugfix for inline text visuals when document is edited
* Bugfix for completions for constructor method arguments
* Hotfix for InputManager data fetching with custom tags
* Gpt models are updated

## [1.4.17]
* Hotfix for Unity compile error

## [1.4.16]
* New code completions: RenderingLayerMask (Unity 6 and newer only)
* New inline visuals: RenderingLayerMask (Unity 6 and newer only), and LayerMask
* Hotfix for Unity editor freezes
* Hotfix for inline visuals not showing properly when changing document in Visual Studio
* Category SortingLayer removed, its items are now under category Layer
* Minor fix for output window in Visual Studio
* Gpt libraries and models are updated

## [1.4.15]
* Hotfix for code completion for attributes

## [1.4.14]
* New code completions: Attributes and preprocessor directives (#if, #elif)
* New gpt feature: Add mode, gpt can add new files to the project
* New gpt feature: For CodeLens, follow-up question and custom prompt
* Gpt responses are logged to Visual Studio output window

## [1.4.13]
* Hotfix for gpt requests of OpenAI-API-Compatible platforms

## [1.4.12]
* Additional properties options added for gpt requests
* Version number mistype fix for Unity asset package

## [1.4.11]
* Hotfix for gpt options page
* Fix for applying transformers for newer versions of Visual Studio
* Arm64 architecture support

## [1.4.10]
* Animations added to context aware instructions
* Hotfix for context aware integrations (for GitHub Copilot)

## [1.4.9]
* Hotfix for gpt options page

## [1.4.8]
* Version bump for sister Visual Studio extensions

## [1.4.7]
* New gpt feature: Integration into GitHub Copilot. Can now feed GitHub Copilot with project/scene/game-object details.
* Auto updater for itch.io builds

## [1.4.6]
* Updated binaries with new build parameters

## [1.4.5]
* Version skipped by mistake ^-^

## [1.4.4]
* Hotfix for Unity package compile error

## [1.4.3]
* New gpt provider: OpenAI API Compatible, for web/cloud services that supports OpenAI SDK standards

## [1.4.2]

* Bugfix for formatting and title of logging
* Bugfix for CodeLens2Gpt when closing document

## [1.4.1]

* New gpt provider: Ollama, can use LLMs from local machine or private network

## [1.4.0]

* Gpt backend has been reimplemented for latest models and LLM trends
* New gpt provider: Anthropic (Claude), can be used as an alternative to OpenAI ChatGPT and Google Gemini
* New gpt provider: DeepSeek, can be used as an alternative to OpenAI ChatGPT and Google Gemini
* New code completions: Scene management classes can be auto completed
* New inline visuals: Scene management classes can display inline information

## [1.3.12]

* Hotfix for Microsoft Marketplace manifest file

## [1.3.11]

* Hotfix for Microsoft Marketplace manifest file

## [1.3.10]

* Hotfix for type resolving
* Usability improvements for VSCode exporter
* More filters for expected error logs

## [1.3.9]

* Hotfix for Unity sink

## [1.3.8]

* Hotfix for Unity sink

## [1.3.7]

* Bugfix for exporter/updater
* Bugfix for logging options

## [1.3.6]

* VSCode readme updated

## [1.3.5]

* JSON library switched back to Newtonsoft.JSON
* Rule xml files removed from Unity asset
* Unnessary analyzer binaries are removed from Roslyn Analyzer

## [1.3.4]

* Stability improvements for network (mqttnet)
* Hotfix for JSON mapping

## [1.3.3]

* Full version for VSCode is released!
* Fix for VSCode adorments when document is modified
* Binary files removed from Unity asset
* Bugfix for network (mqttnet server)
* VSCode extension stability improvements
* VSCode roslyn analyzer stability improvements

## [1.3.2]

* Fixed cross-platform issues for Linux and macOS

## [1.3.1]

* Updated VSCode manifest and readme

## [1.3.0]

* Initial release for VSCode