
![Header](https://raw.githubusercontent.com/merryyellow/Unity-Code-Assist/refs/heads/main/media/asset-store-social-2a.jpg) 

### [🔗 Store](https://unitycodeassist.netlify.app/purchase.html?utm_content=store_link_1&utm_source=vsclite-msmarketplace) | [🌐 Website](https://unitycodeassist.netlify.app/) | [💬 Discord](https://discord.gg/2CgKHDq)

**Unity Code Assist** improves your coding experience with Visual Studio Code. Coding for Unity projects becomes easier and more efficient with fewer bugs. 

Connect your game editor and code editor, let Unity and Visual Studio Code share data between each other. Enrich your coding experience with the new data available.

## ✨ Features 

*  **🧠 Code Completion:** More content for code completion (aka IntelliSense) which is specialized for common Unity APIs and your own projects.

![code completion](https://merryyellow.gallerycdn.vsassets.io/extensions/merryyellow/uca-lite/1.2.6/1724363925708/code-completion-cropped-bordered-b-gif.gif)

  

*  **👁️‍🗨️ Inline Visuals:** Displays visual information about your scene data and assets.

![inline visuals](https://merryyellow.gallerycdn.vsassets.io/extensions/merryyellow/uca-lite/1.2.6/1724363925708/inline-b-gif-bordered.gif)

  

*  **🧪 Code Analyzers:** Additional analyzers on top of the default ones (Microsoft.Unity.Analyzers), which are focused on memory and CPU utilization.

![enter image description here](https://merryyellow.gallerycdn.vsassets.io/extensions/merryyellow/uca-lite/1.2.6/1724363925708/analyzer-gif-bordered.gif)



* **🤖 Generative AI:** Integrates into GitHub Copilot and also CLI coding agents such as Claude Code, Gemini CLI etc. for more accurate results.

**🧩 Requirements:** Unity 2021.2 and newer.

**🐞 Bug/error report & suggestions:** Either use [💌 e-mail](mailto:merryyellow@outlook.com), [🐙 GitHub](https://github.com/merryyellow/Unity-Code-Assist/issues/new), [💬 Discord](https://discord.gg/2CgKHDq) or Q&A here  

### [🔗 Store](https://unitycodeassist.netlify.app/purchase.html?utm_content=store_link_1&utm_source=vsclite-msmarketplace) | [🌐 Website](https://unitycodeassist.netlify.app/) | [💬 Discord](https://discord.gg/2CgKHDq)

## ⚠️ Known issues

* If code completion/IntelliSense is not working (but inline visuals/inlay hints are working), try switching C# extension's version from pre-release to release or vice versa [*](https://github.com/dotnet/vscode-csharp/issues/7676)